package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.EvaluationBean;
import bean.ProductBean;
import bean.SpecificationBean;
import bean.UserBean;
import dao.EvaluationDao;
import dao.OrderDao;
import dao.OrderDetailDao;

/**
 * Servlet implementation class EvaluationServlet
 */
@WebServlet("/EvaluationServlet")
public class EvaluationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EvaluationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings({ "unused" })
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String msg = "";
		String remark = request.getParameter("remark");
		if (remark.equals("getEvaluationListByProductId")) {
			int productId = Integer.parseInt(request.getParameter("productId"));
			List<EvaluationBean> evaluationList = new ArrayList<>();
			evaluationList = new EvaluationDao().getEvaluationByproductId(productId);
			for (EvaluationBean evaluation:evaluationList) {
				msg = msg + evaluation.toString() + "。";
			}
			System.out.print("评价"+msg);
			response.getWriter().append(msg);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
