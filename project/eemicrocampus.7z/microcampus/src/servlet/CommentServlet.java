package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.CommentBean;
import bean.EvaluationBean;
import bean.UserBean;
import dao.CommentDao;

/**
 * Servlet implementation class CommentServlet
 */
@WebServlet("/CommentServlet")
public class CommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CommentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		int evaluationId=Integer.parseInt(request.getParameter("evaluationId"));
		System.out.print(evaluationId);
		List<CommentBean> commentList=new ArrayList<>();
		JSONArray array=new JSONArray();
		commentList=new CommentDao().getCommentListByEvaluationId(evaluationId);
		for(int i=0;i<commentList.size();i++) {
			JSONObject obj=new JSONObject();
			Date commentTime=commentList.get(i).getCommentTime();
			String time=commentTime.toString();
			UserBean user=commentList.get(i).getUser();
			obj.put("userName",user.getUserName());
			obj.put("userImage",user.getUserImage());
			obj.put("commentContent", commentList.get(i).getCommentContent());
			obj.put("commentTime", time);
			array.put(obj);
			System.out.print(obj.toString());
		}
		response.getWriter().append(array.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
