package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;
import dao.UserDao;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String msg = "";
		String remark = request.getParameter("remark");
		if (remark.equals("getImageByUserName")) {
			// 通过用户名获取图片。
			String userName = request.getParameter("userName");
			int image = new UserDao().getImageByUserName(userName);
			if (image == 0) {
				msg = "用户名错误";
				System.out.print(msg);
				response.setCharacterEncoding("utf-8");
				response.getWriter().append(msg);
			} else {
				msg = "" + image;
				response.getWriter().append(msg);
			}
		} else if (remark.equals("isTelAccount")) {
			// 判断手机号是否注册注册过则返回true，否则返回false
			String tel = request.getParameter("tel");
			msg = new UserDao().isTelAccount(tel);
			response.getWriter().append(msg);
		} else if (remark.equals("account")) {
			String tel = request.getParameter("tel");
			try {
				UserDao userDao = new UserDao();
				userDao.addUser(tel);
				UserBean user = userDao.getUserByTel(tel);
				msg = user.toString();
				System.out.print(msg);
				response.getWriter().append(msg);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(remark.equals("changeUser")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			String userName = request.getParameter("userName");
			String userEmail = request.getParameter("userEmail");
			new UserDao().changeUserEmail(userId, userEmail);
			msg = new UserDao().changeUser(userId, userName).toString();
			response.getWriter().append(msg);
		}else if(remark.equals("changeTel")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			String userTel = request.getParameter("userTel");
			msg = new UserDao().changeTel(userId, userTel).toString();
			response.getWriter().append(msg);
		}else if(remark.equals("changePassword")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			String userPassword = request.getParameter("userPassword");
			msg = new UserDao().changePassword(userId, userPassword).toString();
			response.getWriter().append(msg);
		}else if(remark.equals("changeAddress")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			String userAddress = request.getParameter("userAddress");
			msg = new UserDao().changeAddress(userId,userAddress).toString();
			response.getWriter().append(msg);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
