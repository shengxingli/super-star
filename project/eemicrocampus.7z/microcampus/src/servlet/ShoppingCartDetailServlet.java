package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ShoppingCartDetailBean;
import dao.ShoppingCartDetailDao;

/**
 * Servlet implementation class ShoppingCartDetailServlet
 */
@WebServlet("/ShoppingCartDetailServlet")
public class ShoppingCartDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCartDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String msg = "";
		String remark = request.getParameter("remark");
		System.out.print(remark);
		if(remark.equals("getShoppingCartDetailByUserId")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			System.out.print(userId+"");
			List<ShoppingCartDetailBean> shoppingCartDetailList 
			= new ShoppingCartDetailDao().getShoppingCartDetailListByUserId(userId);
			for(ShoppingCartDetailBean shoppingCartDetail : shoppingCartDetailList) {
				msg = msg + shoppingCartDetail.toString() + "。";
			}
			System.out.print(msg);
			response.getWriter().append(msg);
		}else if(remark.equals("add")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			int productId = Integer.parseInt(request.getParameter("productId"));
			int productCount = Integer.parseInt(request.getParameter("productCount"));
			int specificationId = Integer.parseInt(request.getParameter("specificationId"));
			msg = new ShoppingCartDetailDao().addShoppingCart(userId, productId, productCount, specificationId);
			response.getWriter().append(msg);
		}else if(remark.equals("changeShoppingCartDetail")) {
			int shoppingCartDetailId = Integer.parseInt(request.getParameter("shoppingCartDetailId"));
			int productCount = Integer.parseInt(request.getParameter("productCount"));
			new ShoppingCartDetailDao().changShoppingCartDetail(shoppingCartDetailId, productCount);
			response.getWriter().append(msg);
		}else if(remark.equals("changeShoppingCartDetailSpe")){
			int specificationId = Integer.parseInt(request.getParameter("specificationId"));
			int shoppingCartDetailId = Integer.parseInt(request.getParameter("shoppingCartDetailId"));
			new ShoppingCartDetailDao().changShoppingCartDetailSpe(shoppingCartDetailId, specificationId);
			response.getWriter().append(msg);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
