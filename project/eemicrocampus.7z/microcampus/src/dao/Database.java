package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {

	/**
	 * 获取对数据库的连接
	 */
	public static Connection getConnection() {
		Connection conn = null;
		try {
			//1加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			//2建立连接
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/microcampus?useUnicode=true&characterEncoding=utf-8","root","");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
}
