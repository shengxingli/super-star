package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

import bean.UserBean;

public class UserDao {

	/*
	 * 利用手机号注册新用户,无返回值
	 */
	public void addUser(String tel) throws SQLException {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "insert into user(user_image,user_tel) values(?,?)";
		ResultSet rs = null;
		pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		pstmt.setString(1, "2131099734");
		pstmt.setString(2, tel);
		pstmt.executeUpdate();
	}

	/*
	 * 修改信息系列
	 */
	public UserBean changeUser(int userId,String userName) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update user set user_name=? where user_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			pstmt.setInt(2, userId);
			pstmt.executeUpdate();
			user = getUserByUserName(userName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	public String changeUserEmail(int userId,String userEmail) {
		String result = "false";
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update user set user_email=? where user_id=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userEmail);
			pstmt.setInt(2, userId);
			pstmt.executeUpdate();
			result = "true";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public String changeUserImage(int userId,int userImage) {
		String result = "false";
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update user set user_image=? where user_id=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userImage);
			pstmt.setInt(2, userId);
			pstmt.executeUpdate();
			result = "true";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public UserBean changeTel(int userId,String userTel) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update user set user_tel=? where user_id=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userTel);
			pstmt.setInt(2, userId);
			pstmt.executeUpdate();
			user = getUserByTel(userTel);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	public UserBean changePassword(int userId,String userPassword) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update user set user_password=? where user_id=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userPassword);
			pstmt.setInt(2, userId);
			pstmt.executeUpdate();
			user = getUserById(userId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	public UserBean changeAddress(int userId,String userAddress) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update user set user_address=? where user_id=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userAddress);
			pstmt.setInt(2, userId);
			pstmt.executeUpdate();
			user = getUserById(userId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	/*
	 * getImageByUserName通过用户名查询图片地址
	 */
	public int getImageByUserName(String name) {
		int image = 0;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select user_image from user where user_name=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				image = rs.getInt(1);
				return image;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return image;
	}

	/*
	 * 验证密码是否正确，正确返回userBean
	 */
	public UserBean isPasswordTrue(String name, String password) {
		UserBean user = null;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select user_password from user where user_name=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String pwd = rs.getString(1);
				if (password.equals(pwd)) {
					user = getUserByUserName(name);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	/*
	 * 通过用户名获取用户
	 */
	public UserBean getUserByUserName(String name) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from user where user_name=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				user.setUserId(rs.getInt(1));
				user.setUserTel(rs.getString(2));
				user.setUserImage(rs.getInt(3));
				user.setUserName(rs.getString(4));
				user.setUserPassword(rs.getString(5));
				user.setUserAddress(rs.getString(6));
				user.setUserEmail(rs.getString(7));
				if (rs.getInt(8) == 0) {
					user.setShop(null);
				} else {
					user.setShop(new ShopDao().getShopById(rs.getInt(8)));
				}
				user.setUserELogin(rs.getInt(9));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	/*
	 * 根据手机号判断是否注册
	 */
	public String isTelAccount(String tel) {
		String msg = "false";
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select user_id from user where user_tel=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, tel);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				msg = "true";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}

	/*
	 * 通过手机号获取User
	 */
	public UserBean getUserByTel(String tel) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from user where user_tel=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, tel);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				user.setUserId(rs.getInt(1));
				user.setUserTel(rs.getString(2));
				user.setUserImage(rs.getInt(3));
				user.setUserName(rs.getString(4));
				user.setUserPassword(rs.getString(5));
				user.setUserAddress(rs.getString(6));
				user.setUserEmail(rs.getString(7));
				if (rs.getInt(8) == 0) {
					user.setShop(null);
				} else {
					user.setShop(new ShopDao().getShopById(rs.getInt(8)));
				}
				user.setUserELogin(rs.getInt(9));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	/*
	 * 通过userId获取User
	 */
	public UserBean getUserById(int userId) {
		UserBean user = new UserBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from user where user_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				user.setUserId(rs.getInt(1));
				user.setUserTel(rs.getString(2));
				user.setUserImage(rs.getInt(3));
				user.setUserName(rs.getString(4));
				user.setUserPassword(rs.getString(5));
				user.setUserAddress(rs.getString(6));
				user.setUserEmail(rs.getString(7));
				if (rs.getInt(8) == 0) {
					user.setShop(null);
				} else {
					user.setShop(new ShopDao().getShopById(rs.getInt(8)));
				}
				user.setUserELogin(rs.getInt(9));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
}
