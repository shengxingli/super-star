package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.ShopBean;

public class ShopDao {

	/*
	 * 通过shopID获取shop
	 */
	public ShopBean getShopById(int shopId) {
		ShopBean shop = new ShopBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from shop where shop_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shopId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				shop.setShopId(rs.getInt(1));
				shop.setShopName(rs.getString(2));
				shop.setShopImage(rs.getInt(3));
				shop.setShopDescription(rs.getString(4));
				shop.setShopAddress(rs.getString(5));
				shop.setIdentyImage(rs.getInt(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return shop;
	}
	
}
