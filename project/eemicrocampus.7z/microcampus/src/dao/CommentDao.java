package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CommentBean;

public class CommentDao {
	public List<CommentBean> getCommentListByEvaluationId(int i){
		List<CommentBean> commentList=new ArrayList<>();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select comment_id,comment_content,comment_time,user_id from comment where evaluation_id=?";
		ResultSet rs = null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, i);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				CommentBean comment=new CommentBean();
				comment.setCommentId(rs.getInt(1));
				comment.setEvaluation(new EvaluationDao().getEvaluationById(i));
				comment.setCommentContent(rs.getString(2));
				comment.setCommentTime(rs.getDate(3));
				comment.setUser(new UserDao().getUserById(rs.getInt(4)));
				commentList.add(comment);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return commentList;
	}
}
