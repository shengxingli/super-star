package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.MsgBean;
import bean.MsgDetailBean;

public class MsgDetailDao {

	/*
	 * 通过msgId获取MsgList
	 */
	public List<MsgDetailBean> getMsgDetailListByMsgId(int msgId) {
		List<MsgDetailBean> msgDetailList = new ArrayList<>();
		MsgDetailBean msgDetail = null;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from msg_detail where msg_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, msgId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				msgDetail = new MsgDetailBean();
				msgDetail.setMsgDetailId(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msgDetailList;
	}
	
}
