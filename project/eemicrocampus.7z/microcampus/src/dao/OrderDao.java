package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.mysql.jdbc.Statement;

import bean.OrderBean;
import bean.ShoppingCartDetailBean;


public class OrderDao {

	/*
	 * 通过orderId获取Order
	 */
	public OrderBean getOrderById(int orderId) {
		OrderBean order = new OrderBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from order1 where order_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, orderId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				order.setOrderId(rs.getInt(1));
				order.setUser(new UserDao().getUserById(rs.getInt(2)));
				order.setOrderState(rs.getString(3));
				order.setOrderTime(rs.getDate(4));
				order.setOrderPrice(rs.getDouble(5));
				order.setShop(new ShopDao().getShopById(rs.getInt(6)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return order;
	}
	
	public int getOrderIdByUserId(int userId) {
		int orderId=0;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select order_id from order1 where user_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				orderId=rs.getInt(1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orderId;
	}
	
	/*
	 * 添加order
	 */
	public int addOrder(ShoppingCartDetailBean shoppingCartDetail) {
		int orderId = 0;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "insert into order1(user_id,order_state,order_time,order_price,shop_id) values(?,?,?,?,?)";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, shoppingCartDetail.getUserId());
			pstmt.setString(2, "待发货");
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			pstmt.setString(3, df.format(new Date()));
			pstmt.setDouble(4, shoppingCartDetail.getProductCount()*
					shoppingCartDetail.getSpecification().getProductPrice());
			pstmt.setInt(5, shoppingCartDetail.getProduct().getShop().getShopId());
			pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			orderId = rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orderId;
	}
}
