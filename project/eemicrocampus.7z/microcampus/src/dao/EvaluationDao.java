package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.EvaluationBean;

public class EvaluationDao {

	/*
	 * 根据evaluationId获取EavaluationBean
	 */
	public EvaluationBean getEvaluationById(int evaluationId) {
		EvaluationBean evaluation = new EvaluationBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from evaluation where evaluation_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, evaluationId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				evaluation.setEvaluationId(rs.getInt(1));
				evaluation.setUser(new UserDao().getUserById(rs.getInt(2)));
				evaluation.setEvaluationContent(rs.getString(3));
				evaluation.setEvaluationImage(rs.getInt(4));
				evaluation.setEvaluaionTime(rs.getDate(5));
				evaluation.setProduct(new ProductDao().getProductById(rs.getInt(6)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return evaluation;
	}
	/*
	 * 根据productId获取EavaluationList
	 */
	public List<EvaluationBean> getEvaluationByproductId(int productId) {
		List<EvaluationBean> list=new ArrayList<>();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from evaluation where product_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, productId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				EvaluationBean evaluation = new EvaluationBean();
				evaluation.setEvaluationId(rs.getInt(1));
				evaluation.setUser(new UserDao().getUserById(rs.getInt(2)));
				evaluation.setEvaluationContent(rs.getString(3));
				evaluation.setEvaluationImage(rs.getInt(4));
				evaluation.setEvaluaionTime(rs.getDate(5));
				evaluation.setProduct(new ProductDao().getProductById(rs.getInt(6)));
				list.add(evaluation);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
