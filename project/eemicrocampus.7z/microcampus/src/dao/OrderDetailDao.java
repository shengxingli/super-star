package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

import bean.ShoppingCartDetailBean;
import bean.SpecificationBean;

public class OrderDetailDao {
	public SpecificationBean getSpecificationByOrderId(int orderId) {
		SpecificationBean sp=new SpecificationBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select specification_id from order_detail where order_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, orderId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				sp=new SpecificationDao().getSecificationById(rs.getInt(1));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sp;
	}
	
	public void addOrderDetail(ShoppingCartDetailBean shoppingCartDetail , int orderId , String msg) {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "insert into order_detail(order_id,product_id,product_count,order_detail_msg,specification_id) values(?,?,?,?,?)";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, orderId);
			pstmt.setInt(2, shoppingCartDetail.getProduct().getProductId());
			pstmt.setInt(3, shoppingCartDetail.getProductCount());
			pstmt.setString(4, msg);
			pstmt.setInt(5, shoppingCartDetail.getSpecification().getSpecificationId());
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
