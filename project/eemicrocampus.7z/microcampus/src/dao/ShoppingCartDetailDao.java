package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import bean.ShoppingCartDetailBean;

public class ShoppingCartDetailDao {

	/*
	 * 通过userId获取ShoppingCartDetailList
	 */
	public List<ShoppingCartDetailBean> getShoppingCartDetailListByUserId(int userId) {
		List<ShoppingCartDetailBean> shoppingCartDetailList = new ArrayList<>();
		ShoppingCartDetailBean shoppingCartDetail = null;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from shoppingcart_detail where user_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				shoppingCartDetail = new ShoppingCartDetailBean();
				shoppingCartDetail.setShoppingCartDetailId(rs.getInt(1));
				shoppingCartDetail.setUserId(rs.getInt(2));
				shoppingCartDetail.setProduct(new ProductDao().getProductById(rs.getInt(3)));
				shoppingCartDetail.setProductCount(rs.getInt(4));
				shoppingCartDetail.setSpecification(new SpecificationDao().getSecificationById(rs.getInt(5)));
				shoppingCartDetailList.add(shoppingCartDetail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return shoppingCartDetailList;
	}

	/*
	 * 加入购物车
	 */
	public String addShoppingCart(int userId, int productId, int productCount, int specificationId) {
		String result = "false";
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "insert into shoppingcart_detail(user_id,product_id,product_count,specification_id) values(?,?,?,?)";
		try {
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, userId);
			pstmt.setInt(2, productId);
			pstmt.setInt(3, productCount);
			pstmt.setInt(4, specificationId);
			pstmt.executeUpdate();
			result = "true";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * 通过id查询shoppingCartDetailBean
	 */
	public ShoppingCartDetailBean getShoppingCartDetailById(int shoppingCartDetailId) {
		ShoppingCartDetailBean shoppingCartDetail = null;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from shoppingcart_detail where shoppingcart_detail_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shoppingCartDetailId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				shoppingCartDetail = new ShoppingCartDetailBean();
				shoppingCartDetail.setShoppingCartDetailId(rs.getInt(1));
				shoppingCartDetail.setUserId(rs.getInt(2));
				shoppingCartDetail.setProduct(new ProductDao().getProductById(rs.getInt(3)));
				shoppingCartDetail.setProductCount(rs.getInt(4));
				shoppingCartDetail.setSpecification(new SpecificationDao().getSecificationById(rs.getInt(5)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return shoppingCartDetail;
	}

	/*
	 * 删除购物车
	 */
	public void delete(int shoppingCartDetailId) {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "delete from shoppingcart_detail where shoppingcart_detail_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shoppingCartDetailId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/*
	 * 修改购物车
	 */
	public void changShoppingCartDetail (int shoppingCartDetailId,int productCount) {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update shoppingcart_detail set product_count=? where shoppingcart_detail_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, productCount);
			pstmt.setInt(2, shoppingCartDetailId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void changShoppingCartDetailSpe(int shoppingCartDetailId, int specificationId) {
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update shoppingcart_detail set specification_id=? where shoppingcart_detail_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, specificationId);
			pstmt.setInt(2, shoppingCartDetailId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
