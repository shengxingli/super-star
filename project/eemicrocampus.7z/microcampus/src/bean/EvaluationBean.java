package bean;

import java.util.Date;

/*
 *评价表
 */

public class EvaluationBean {

	private int evaluationId;
	private UserBean user;
	private String evaluationContent;
	private int evaluationImage;
	private Date evaluaionTime;
	private ProductBean product;

	public int getEvaluationId() {
		return evaluationId;
	}

	public void setEvaluationId(int evaluationId) {
		this.evaluationId = evaluationId;
	}

	public UserBean getUser() {
		return user;
	}

	public void setUser(UserBean user) {
		this.user = user;
	}

	public String getEvaluationContent() {
		return evaluationContent;
	}

	public void setEvaluationContent(String evaluationContent) {
		this.evaluationContent = evaluationContent;
	}

	public int getEvaluationImage() {
		return evaluationImage;
	}

	public void setEvaluationImage(int evaluationImage) {
		this.evaluationImage = evaluationImage;
	}

	public Date getEvaluaionTime() {
		return evaluaionTime;
	}

	public void setEvaluaionTime(Date evaluaionTime) {
		this.evaluaionTime = evaluaionTime;
	}

	public ProductBean getProduct() {
		return product;
	}

	public void setProduct(ProductBean product) {
		this.product = product;
	}

	@Override
	public String toString() {

		//用户和商品不可能为空
		return evaluationId + "," + user.toString() + "," + evaluationContent + "," + evaluationImage + ","
				+ evaluaionTime + "," + product.toString();

	}

}
