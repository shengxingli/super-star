package bean;

/*
 *订单详情表
 */

public class OrderDetaliBean {

	private int orderDetailId;
	private OrderBean order;
	private ProductBean product;
	private int productCount;
	private String orderDetailMsg;
	private SpecificationBean specification;
	
	public SpecificationBean getSpecification() {
		return specification;
	}
	public void setSpecification(SpecificationBean specification) {
		this.specification = specification;
	}
	public String getOrderDetailMsg() {
		return orderDetailMsg;
	}
	public void setOrderDetailMsg(String orderDetailMsg) {
		this.orderDetailMsg = orderDetailMsg;
	}
	public int getOrderDetailId() {
		return orderDetailId;
	}
	public void setOrderDetailId(int orderDetailId) {
		this.orderDetailId = orderDetailId;
	}
	public OrderBean getOrder() {
		return order;
	}
	public void setOrder(OrderBean order) {
		this.order = order;
	}
	public ProductBean getProduct() {
		return product;
	}
	public void setProduct(ProductBean product) {
		this.product = product;
	}
	public int getProductCount() {
		return productCount;
	}
	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}
	
	@Override
	public String toString() {
		return orderDetailId + "," + order.toString() + "," + product.toString()
				+ "," + productCount + "," + orderDetailMsg + ","
				+ specification.toString();
	}
	
}
