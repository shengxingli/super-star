package bean;

import java.util.Date;

/*
 *信息表
 */

public class MsgBean {

	private int msgId;
	private ShopBean shop;
	private UserBean user;
	private int sender;
	private String msgLastContent;
	private Date msgLastTime;

	public String getMsgLastContent() {
		return msgLastContent;
	}

	public void setMsgLastContent(String msgLastContent) {
		this.msgLastContent = msgLastContent;
	}

	public Date getMsgLastTime() {
		return msgLastTime;
	}

	public void setMsgLastTime(Date msgLastTime) {
		this.msgLastTime = msgLastTime;
	}

	public int getMsgId() {
		return msgId;
	}

	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}

	public ShopBean getShop() {
		return shop;
	}

	public void setShop(ShopBean shop) {
		this.shop = shop;
	}

	public UserBean getUser() {
		return user;
	}

	public void setUser(UserBean user) {
		this.user = user;
	}

	public int getSender() {
		return sender;
	}

	public void setSender(int sender) {
		this.sender = sender;
	}

	@Override
	public String toString() {
		// 用户商家不可能为空
		return msgId + "," + "user" + "," + shop.toString() + "," + sender
				 + "," + msgLastContent + "," + msgLastTime;
	}

}
