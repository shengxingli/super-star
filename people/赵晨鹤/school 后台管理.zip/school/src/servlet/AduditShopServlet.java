package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AduditBean;
import dao.AduditDao;
import dao.ShopDao;
import dao.UserDao;

/**
 * Servlet implementation class AduditShopServlet
 */
@WebServlet("/AduditShopServlet")
public class AduditShopServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AduditShopServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String mark=request.getParameter("mark");
		if(mark.equals("select")) {
			select(request,response);
		}else if(mark.equals("update")) {
			update(request,response);
		}else if(mark.equals("delete")) {
			delete(request,response);
		}
		
	}
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		int aduditId = Integer.parseInt(request.getParameter("aduditId"));
		int shopId = Integer.parseInt(request.getParameter("shopId"));
		int userId = Integer.parseInt(request.getParameter("userId"));
		AduditDao aduditDao = new AduditDao();
		aduditDao.update("success",aduditId);
		UserDao userDao = new UserDao();
		userDao.updateShop(shopId, userId);
		request.getRequestDispatcher("AduditShopServlet?mark=select").forward(request, response);
	}
	protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		int aduditId = Integer.parseInt(request.getParameter("aduditId"));
		int shopId = Integer.parseInt(request.getParameter("shopId"));
		AduditDao aduditDao = new AduditDao();
		ShopDao shopDao = new ShopDao();
		shopDao.deleteShop(shopId);
		aduditDao.delete(aduditId);
		request.getRequestDispatcher("AduditShopServlet?mark=select").forward(request, response);
	}
	protected void select(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		List<AduditBean> aduditList=new ArrayList<>();
		AduditDao aduditDao=new AduditDao();
		String state = "daishenhe";
		aduditList=aduditDao.getAllAdudit(state);
		request.setAttribute("aduditList", aduditList);
		request.getRequestDispatcher("PageServlet?mark=adudit").forward(request, response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
