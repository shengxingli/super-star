package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.AdminBean;
import bean.SuperAdminBean;
import dao.AdminDao;
import dao.SuperAdminDao;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginCheckServlet")
public class LoginCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String mark = request.getParameter("mark");	
		if(mark.equals("admin")) {
			String adminName=request.getParameter("adminName");
			String adminPassword=request.getParameter("adminPassword");
			AdminBean admin=new AdminBean();
			admin.setAdminName(adminName);
			admin.setAdminPassword(adminPassword);
			if(!"".equals(adminName) && !"".equals(adminPassword)) {
				AdminDao adminDao = new AdminDao(); 
				boolean a = adminDao.loginCheck1(admin);
				if(a) {
					boolean b=adminDao.loginCheck(admin);
					if(b) {
						HttpSession session = request.getSession();
						session.setAttribute("adminName",adminName);
						request.getRequestDispatcher("index1.jsp").forward(request, response);
					}else {
						String msg = "此管理员登录密码错误";
						request.setAttribute("msg", msg);
						request.getRequestDispatcher("login.jsp").forward(request, response);
					}
				}else {
					String msg1 = "此管理员不存在，请先注册";
					request.setAttribute("msg", msg1);
					request.getRequestDispatcher("login.jsp").forward(request, response);
				}
				
			}else {
			String msg = "用户名或密码没填写";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		}else if(mark.equals("sAdmin")) {
			String sAdminName=request.getParameter("sAdminName");
			String sAdminPassword=request.getParameter("sAdminPassword");
			SuperAdminBean sAdmin=new SuperAdminBean();
			sAdmin.setSuperAdminName(sAdminName);
			sAdmin.setSuperAdminPassword(sAdminPassword);
			if(!"".equals(sAdminName) && !"".equals(sAdminPassword)) {
				SuperAdminDao sAdminDao = new SuperAdminDao(); 
				boolean a = sAdminDao.loginCheck1(sAdmin);
				if(a) {
					boolean b = sAdminDao.loginCheck(sAdmin);
					if(b) {
						HttpSession session = request.getSession();
						session.setAttribute("sAdminName",sAdminName);
						request.getRequestDispatcher("index.jsp").forward(request, response);
					}else {
						String msg = "此管理员密码错误";
						request.setAttribute("msg", msg);
						request.getRequestDispatcher("loginSuper.jsp").forward(request, response);
					}
				}else {
					String msg1 = "此管理员不存在";
					request.setAttribute("msg", msg1);
					request.getRequestDispatcher("loginSuper.jsp").forward(request, response);
				}
			}else {
				String msg = "用户名或密码没填写";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("loginSuper.jsp").forward(request, response);
			}
			
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
