package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AdminBean;
import bean.AduditBean;
import bean.ShopBean;
import dao.AdminDao;
import dao.AduditDao;
import dao.ShopDao;

/**
 * Servlet implementation class ShopServlet
 */
@WebServlet("/ShopServlet")
public class ShopServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShopServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String mark=request.getParameter("mark");
		if(mark.equals("select")) {
			select(request,response);
		}else if(mark.equals("selectAllShop")) {
			selectAllShop(request,response);
		}
	}
	
	protected void select(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		ShopDao shopDao = new ShopDao();
		String shopName = request.getParameter("shopName");
		if(!shopName.equals("")) {
			ShopBean shopBean = shopDao.selectShopByShopName(shopName);
			List<ShopBean> list = new ArrayList<>();
			list.add(shopBean);
			request.setAttribute("list", list);
			request.getRequestDispatcher("PageServlet?mark=shop").forward(request, response);
		}else {
			String msg = "查无此店铺";
			request.getAttribute(msg);
			request.getRequestDispatcher("shop.jsp").forward(request, response);
		}
		
	}
	protected void selectAllShop(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		AduditDao aduditDao = new AduditDao();
		List<AduditBean> list = new ArrayList<>();
		String state = "success";
		List<ShopBean> list1 = new ArrayList<>();
		list = aduditDao.getAllAdudit(state);
		for(int i = 0;i<list.size();++i) {
			ShopDao shopDao = new ShopDao();
			int shopId = list.get(i).getShopId();
			ShopBean shopBean = new ShopBean();
			shopBean = shopDao.getShopByShopId(shopId);
			list1.add(shopBean);
		}
		request.setAttribute("list1", list1);
		request.getRequestDispatcher("PageServlet?mark=shop").forward(request, response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
