package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.AdminBean;
import bean.AduditBean;
import bean.ShopBean;
import common.Page;
import dao.AdminDao;
import dao.AduditDao;
import dao.ShopDao;

/**
 * Servlet implementation class PageServlet
 */
@WebServlet("/PageServlet")
public class PageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PageServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String mark = request.getParameter("mark");
		if (mark.equals("admin")) {
			admin(request, response);
		}else if(mark.equals("shop")) {
			shop(request,response);
		}else if(mark.equals("adudit")) {
			adudit(request,response);
		}else if(mark.equals("punishShop")) {
			punishShop(request,response);
		}
	}
	@SuppressWarnings("unchecked")
	private void punishShop(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ShopDao shopDao = new ShopDao();
		String currentPageStr = request.getParameter("currentPage");
		String adminName=request.getParameter("adminName");
		System.out.println(adminName+"222");
		int currentPage = 1;
		if (currentPageStr != null && !currentPageStr.equals("")) {
			currentPage = Integer.parseInt(currentPageStr);
		}
		HttpSession session = request.getSession();
		List<ShopBean> shopList = null;
		if (session.getAttribute("list1") == null) {// 创建数据
			AduditDao aduditDao = new AduditDao();
			List<AduditBean> list = new ArrayList<>();
			String state = "success";
			List<ShopBean> list1 = new ArrayList<>();
			list = aduditDao.getAllAdudit(state);
			for(int i = 0;i<list.size();++i) {
				int shopId = list.get(i).getShopId();
				ShopBean shopBean = new ShopBean();
				shopBean = shopDao.getShopByShopId(shopId);
				list1.add(shopBean);
			}
			shopList = list1;
		} else {
			shopList = (List<ShopBean>) session.getAttribute("list1");
		}
		session.setAttribute("adminName",  adminName);
		session.setAttribute("shopList", shopList);
		Page page = new Page();
		page.setColumnCount(shopList.size());
		page.setCurrentPage(currentPage);
		List<ShopBean> subShopList = new ArrayList<ShopBean>();
		int fromIndex = (currentPage - 1) * page.getColomnPage();
		int yuShu = page.getColumnCount() % page.getColomnPage();
		int toIndex = (currentPage < page.getPageCount()) ? (fromIndex + page.getColomnPage()) : (fromIndex + yuShu);
		subShopList = shopList.subList(fromIndex, toIndex);
		request.setAttribute("fromIndex", fromIndex);
		request.setAttribute("toIndex", toIndex);
		request.setAttribute("subShopList", subShopList);
		request.setAttribute("page", page);
		request.getRequestDispatcher("punishShop.jsp?").forward(request, response);
	}

	@SuppressWarnings("unchecked")
	private void shop(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ShopDao shopDao = new ShopDao();
		String currentPageStr = request.getParameter("currentPage");
		int currentPage = 1;
		if (currentPageStr != null && !currentPageStr.equals("")) {
			currentPage = Integer.parseInt(currentPageStr);
		}
		HttpSession session = request.getSession();
		List<ShopBean> shopList = null;
		if (session.getAttribute("list1") == null) {// 创建数据
			AduditDao aduditDao = new AduditDao();
			List<AduditBean> list = new ArrayList<>();
			String state = "success";
			List<ShopBean> list1 = new ArrayList<>();
			list = aduditDao.getAllAdudit(state);
			for(int i = 0;i<list.size();++i) {
				int shopId = list.get(i).getShopId();
				ShopBean shopBean = new ShopBean();
				shopBean = shopDao.getShopByShopId(shopId);
				list1.add(shopBean);
			}
			shopList = list1;
		} else {
			shopList = (List<ShopBean>) session.getAttribute("list1");
		}
		session.setAttribute("shopList", shopList);
		Page page = new Page();
		page.setColumnCount(shopList.size());
		page.setCurrentPage(currentPage);
		List<ShopBean> subShopList = new ArrayList<ShopBean>();
		int fromIndex = (currentPage - 1) * page.getColomnPage();
		int yuShu = page.getColumnCount() % page.getColomnPage();
		int toIndex = (currentPage < page.getPageCount()) ? (fromIndex + page.getColomnPage()) : (fromIndex + yuShu);
		subShopList = shopList.subList(fromIndex, toIndex);
		request.setAttribute("fromIndex", fromIndex);
		request.setAttribute("toIndex", toIndex);
		request.setAttribute("subShopList", subShopList);
		request.setAttribute("page", page);
		request.getRequestDispatcher("shop.jsp").forward(request, response);
	}
	@SuppressWarnings("unchecked")
	private void admin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		AdminDao adminDao = new AdminDao();
		String currentPageStr = request.getParameter("currentPage");
		int currentPage = 1;
		if (currentPageStr != null && !currentPageStr.equals("")) {
			currentPage = Integer.parseInt(currentPageStr);
		}
		HttpSession session = request.getSession();
		List<AdminBean> adminList = null;
		if (session.getAttribute("list") == null) {// 创建数据
			adminList = adminDao.getAllAdmin();
		} else {
			adminList = (List<AdminBean>) session.getAttribute("list");
		}
		session.setAttribute("adminList", adminList);
		Page page = new Page();
		page.setColumnCount(adminList.size());
		page.setCurrentPage(currentPage);
		List<AdminBean> subAdminList = new ArrayList<AdminBean>();
		int fromIndex = (currentPage - 1) * page.getColomnPage();
		int yuShu = page.getColumnCount() % page.getColomnPage();
		int toIndex = (currentPage < page.getPageCount()) ? (fromIndex + page.getColomnPage()) : (fromIndex + yuShu);
		subAdminList = adminList.subList(fromIndex, toIndex);
		request.setAttribute("fromIndex", fromIndex);
		request.setAttribute("toIndex", toIndex);
		request.setAttribute("subAdminList", subAdminList);
		request.setAttribute("page", page);
		request.getRequestDispatcher("admin.jsp").forward(request, response);

	}
	@SuppressWarnings("unchecked")
	private void adudit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AduditDao aduditDao = new AduditDao();
		String currentPageStr = request.getParameter("currentPage");
		int currentPage = 1;
		if (currentPageStr != null && !currentPageStr.equals("")) {
			currentPage = Integer.parseInt(currentPageStr);
		}
		HttpSession session = request.getSession();
		List<AduditBean> aduditList = null;
		if (session.getAttribute("aduditList") == null) {// 创建数据
			aduditList = aduditDao.getAllAdudit("daishenhe");
		} else {
			aduditList = (List<AduditBean>) session.getAttribute("aduditList");
		}
		session.setAttribute("aduditList", aduditList);
		Page page = new Page();
		page.setColumnCount(aduditList.size());
		page.setCurrentPage(currentPage);
		List<AduditBean> subAduditList = new ArrayList<AduditBean>();
		int fromIndex = (currentPage - 1) * page.getColomnPage();
		int yuShu = page.getColumnCount() % page.getColomnPage();
		int toIndex = (currentPage < page.getPageCount()) ? (fromIndex + page.getColomnPage()) : (fromIndex + yuShu);
		subAduditList = aduditList.subList(fromIndex, toIndex);
		request.setAttribute("fromIndex", fromIndex);
		request.setAttribute("toIndex", toIndex);
		request.setAttribute("subAduditList", subAduditList);
		request.setAttribute("page", page);
		request.getRequestDispatcher("aduditShop.jsp").forward(request, response);
	}

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
