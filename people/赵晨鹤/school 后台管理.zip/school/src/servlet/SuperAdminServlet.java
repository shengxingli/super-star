package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AdminBean;
import bean.SuperAdminBean;
import dao.AdminDao;
import dao.SuperAdminDao;

/**
 * Servlet implementation class SuperAdminServlet
 */
@WebServlet("/SuperAdminServlet")
public class SuperAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SuperAdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String mark=request.getParameter("mark");
		if(mark.equals("delete")) {
			deleteSuperAdmin(request,response);
		}
	}
	protected void deleteSuperAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sAdminName=request.getParameter("sAdminName");
		SuperAdminDao sAdminDao=new SuperAdminDao();
		SuperAdminBean sAdmin=new SuperAdminBean();
		sAdmin=sAdminDao.selectSuperAdminByName(sAdminName);
		sAdminDao.deleteSuperAdminByName(sAdmin.getSuperAdminName());
		request.getRequestDispatcher("loginSuper.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
