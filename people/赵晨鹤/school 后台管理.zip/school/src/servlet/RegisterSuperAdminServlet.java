package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SuperAdminBean;
import dao.SuperAdminDao;

/**
 * Servlet implementation class RegisterSuperAdminServlet
 */
@WebServlet("/RegisterSuperAdminServlet")
public class RegisterSuperAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterSuperAdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("UTF-8");
		String mark = request.getParameter("mark");
		String sAdminName = request.getParameter("sAdminName");
		String sAdminPassword = request.getParameter("sAdminPassword");
		String sAdminPassword1 = request.getParameter("sAdminPassword1");
		String sAdminEmail = request.getParameter("sAdminEmail");
		if(mark.equals("register")) {
			SuperAdminBean sAdminBean = new SuperAdminBean();
			SuperAdminDao sAdminDao = new SuperAdminDao();
			if(!sAdminName.equals("")&&!sAdminPassword.equals("")&&!sAdminPassword1.equals("")&&!sAdminEmail.equals("")) {
				if(sAdminPassword.equals(sAdminPassword1)) {
					sAdminBean.setSuperAdminName(sAdminName);
					sAdminBean.setSuperAdminPassword(sAdminPassword);
					sAdminBean.setSuperAdminEmail(sAdminEmail);
					sAdminDao.addSuperAdmin(sAdminBean);
				}else {
					String msg1 = "两次密码不统一,请重新输入";
					request.setAttribute("msg1", msg1);
					request.getRequestDispatcher("register.jsp").forward(request, response);
				}
			}else {
				String msg = "用户名、密码、确认密码或邮箱为空";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("register.jsp").forward(request, response);
			}
		}
		request.getRequestDispatcher("loginSuper.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
