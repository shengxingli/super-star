package servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import bean.AduditBean;
import bean.MsgBean;
import bean.MsgDetailBean;
import bean.ShopBean;
import dao.AdminDao;
import dao.AduditDao;
import dao.MsgDao;
import dao.MsgDetailDao;
import dao.ShopDao;
import dao.SuperAdminDao;

/**
 * Servlet implementation class PunishShopServlet
 */
@WebServlet("/PunishShopServlet")
public class PunishShopServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PunishShopServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String mark=request.getParameter("mark");
		if(mark.equals("select")) {
			select(request,response);
		}else if(mark.equals("yujing")) {
			yujing(request,response);
		}
	}
	protected void yujing(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		int shopId=Integer.parseInt(request.getParameter("shopId"));
		String shopName=request.getParameter("shopName");
		String msgContent=request.getParameter("msgContent");
		String adminName=request.getParameter("adminName");
		System.out.print(adminName);
		int adminId=new AdminDao().getAdminIdByName(adminName);
		MsgBean msg=new MsgBean();
		msg.setShopId(shopId);
		msg.setUserId(adminId);
		msg.setSender(2);
		new MsgDao().addMsg(msg);
		MsgDetailBean msgDetail=new MsgDetailBean();
		msgDetail.setMsgId(new MsgDao().getMsgId(adminId, shopId, 2));
		msgDetail.setMsgContent(msgContent);
		msgDetail.setMsgTime(new Date());
		msgDetail.setSender(1);
		new MsgDetailDao().addMsgDetail(msgDetail);
	}
	protected void select(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		String adminName=request.getParameter("name");
		System.out.print(adminName+"12345678");
		AduditDao aduditDao = new AduditDao();
		List<AduditBean> list = new ArrayList<>();
		String state = "success";
		List<ShopBean> list1 = new ArrayList<>();
		list = aduditDao.getAllAdudit(state);
		for(int i = 0;i<list.size();++i) {
			ShopDao shopDao = new ShopDao();
			int shopId = list.get(i).getShopId();
			ShopBean shopBean = new ShopBean();
			shopBean = shopDao.getShopByShopId(shopId);
			list1.add(shopBean);
		}
		//request.setAttribute("adminName",adminName);
		request.setAttribute("list1", list1);
		request.getRequestDispatcher("PageServlet?mark=punishShop&adminName="+adminName).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
