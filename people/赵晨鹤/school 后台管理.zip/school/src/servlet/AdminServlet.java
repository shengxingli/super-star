package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AdminBean;
import dao.AdminDao;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String mark=request.getParameter("mark");
		if(mark.equals("addAdmin")) {
			add(request,response);
		}else if(mark.equals("updateAdminPassword")) {
			updatePassword(request,response);
		}else if(mark.equals("deleteAdmin")) {
			delete(request,response);
		}else if(mark.equals("updateAdminEmail")) {
			updateEmail(request,response);
		}else if(mark.equals("select")) {
			select(request,response);
		}else if(mark.equals("selectAllAdmin")){
			selectAllAdmin(request,response);
		}else if(mark.equals("update")) {
			update(request,response);
		}
		
	}
    protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String adminName=request.getParameter("adminName");
		String adminPassword=request.getParameter("adminPassword");
		String adminNewPassword=request.getParameter("adminNewPassword");
		String adminEmail=request.getParameter("adminEmail");
		String adminNewEmail=request.getParameter("adminNewEmail");
		AdminDao adminDao=new AdminDao();
		AdminBean admin=adminDao.selectAdminByName(adminName);
		if(adminEmail.equals(adminNewEmail)){
			if(adminDao.loginCheck(admin)) {
				adminDao.updateAdminById(admin.getAdminId(), adminNewEmail,adminNewPassword);
				request.getRequestDispatcher("updateAdmin.jsp").forward(request, response);
			}
		}else {
			String msg = "当前输入有错，请重新输入";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("updateAdmin.jsp").forward(request, response);
		}
    }
    
    protected void selectAllAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		AdminDao adminDao = new AdminDao();
		List<AdminBean> list = new ArrayList<>();
		list = adminDao.getAllAdmin();
		request.setAttribute("list", list);
		request.getRequestDispatcher("PageServlet?mark=admin").forward(request, response);
    }
    protected void select(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		AdminDao adminDao = new AdminDao();
		String adminName = request.getParameter("selectCondition");
		if(!adminName.equals("")) {
			AdminBean adminBean = adminDao.selectAdminByName(adminName);
			List<AdminBean> list = new ArrayList<>();
			list.add(adminBean);
			request.setAttribute("adminBean", list);
			request.getRequestDispatcher("admin.jsp").forward(request, response);
		}else {
			String msg = "查无此人";
			request.getAttribute(msg);
			request.getRequestDispatcher("admin.jsp").forward(request, response);
		}
		
    }
	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		String adminName=request.getParameter("adminName");
		String adminPassword=request.getParameter("adminPassword");
		String adminEmail = request.getParameter("adminEmail");
		if(!"".equals(adminName) && !"".equals(adminPassword)&&!"".equals(adminEmail)) {
			AdminBean admin=new AdminBean();
			admin.setAdminName(adminName);
			admin.setAdminPassword(adminPassword);
			admin.setAdminEmail(adminEmail);
			String image = "images/login/ok7.png";
			new AdminDao().addAdmin(admin,image);
			request.getRequestDispatcher("admin.jsp").forward(request, response);
		}else if("".equals(adminName)) {
			String msg = "管理员姓名不能为空";
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("addAdmin.jsp").forward(request, response);
		}else if("".equals(adminPassword)) {
			String msg1 = "密码不能为空";
			request.setAttribute("msg1", msg1);
			request.getRequestDispatcher("addAdmin.jsp").forward(request, response);
		}else if("".equals(adminEmail)) {
			String msg1 = "邮箱不能为空";
			request.setAttribute("msg1", msg1);
			request.getRequestDispatcher("addAdmin.jsp").forward(request, response);
		}
		
		
		
	}
	protected void updatePassword(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String adminName=request.getParameter("adminName");
		String adminPassword=request.getParameter("adminPassword");
		String adminNewPassword=request.getParameter("adminNewPassword");
		AdminDao adminDao=new AdminDao();
		AdminBean admin=adminDao.selectAdminByName(adminName);
		if(!admin.getAdminPassword().equals(adminPassword)) {
			String msg1 = "当前密码不正确";
			request.setAttribute("msg1", msg1);
			request.getRequestDispatcher("updateAdmin.jsp").forward(request, response);
		}else if("".equals(adminNewPassword)) {
				String msg1 = "新密码不能为空";
				request.setAttribute("msg1", msg1);
				request.getRequestDispatcher("updateAdmin.jsp").forward(request, response);
		}else {
			adminDao.updateAdminPasswordById(admin.getAdminId(), adminNewPassword);
		}
	}
	protected void updateEmail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String adminName=request.getParameter("adminName");
		String adminEmail=request.getParameter("adminEmail");
		String adminNewEmail=request.getParameter("adminNewEmail");
		AdminDao adminDao=new AdminDao();
		AdminBean admin=adminDao.selectAdminByName(adminName);
		if(!admin.getAdminEmail().equals(adminEmail)) {
			String msg1 = "当前邮箱账号不正确";
			request.setAttribute("msg1", msg1);
			request.getRequestDispatcher("updateAdminEmail.jsp").forward(request, response);
		}else if("".equals(adminNewEmail)) {
				String msg1 = "新邮箱不能为空";
				request.setAttribute("msg1", msg1);
				request.getRequestDispatcher("updateAdminEmail.jsp").forward(request, response);
		}else {
			adminDao.updateAdminEmailById(admin.getAdminId(), adminNewEmail);
		}
	}
	
	protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String adminName=request.getParameter("adminName");
		AdminDao adminDao=new AdminDao();
		AdminBean admin=new AdminBean();
		admin=adminDao.selectAdminByName(adminName);
		adminDao.deleteAdminById(admin.getAdminId());
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
