package common;

public class Page {
	private int currentPage;//当前页
	private int colomnPage = 10;//每页多少条
	private int columnCount; //一共多少条数据
	private int pageCount; //一共多少页
	
	public Page() {
		super();
		currentPage = 1;
		colomnPage = 10;
		columnCount = 0;
		pageCount = 0;  
		// TODO Auto-generated constructor stub
	}
	public Page(int currentPage, int colomnPage, int columnCount, int pageCount) {
		super();
		this.currentPage = currentPage;
		this.colomnPage = colomnPage;
		this.columnCount = columnCount;
		this.pageCount = pageCount;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getColomnPage() {
		return colomnPage;
	}
	public void setColomnPage(int colomnPage) {
		this.colomnPage = colomnPage;
	}
	public int getColumnCount() {
		return columnCount;
	}
	public void setColumnCount(int columnCount) {
		this.columnCount = columnCount;
		int i = (this.columnCount % this.colomnPage == 0) ? 0 : 1;
		this.pageCount = this.columnCount / this.colomnPage + i;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + colomnPage;
		result = prime * result + columnCount;
		result = prime * result + currentPage;
		result = prime * result + pageCount;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Page other = (Page) obj;
		if (colomnPage != other.colomnPage)
			return false;
		if (columnCount != other.columnCount)
			return false;
		if (currentPage != other.currentPage)
			return false;
		if (pageCount != other.pageCount)
			return false;
		return true;
	}
	
}
