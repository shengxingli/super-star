package bean;

public class ShopBean {
	private int shopId;
	private String shopName;
	private int shopImage;
	private int shopIdentityImage;
	private String shopDescription;
	private String shopAddress;
	
	
	public ShopBean(int shopId, String shopName, int shopImage, int shopIdentityImage, String shopDescription,
			String shopAddress) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.shopImage = shopImage;
		this.shopIdentityImage = shopIdentityImage;
		this.shopDescription = shopDescription;
		this.shopAddress = shopAddress;
	}
	public String getShopAddress() {
		return shopAddress;
	}
	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}
	public int getShopIdentityImage() {
		return shopIdentityImage;
	}
	public void setShopIdentityImage(int shopIdentityImage) {
		this.shopIdentityImage = shopIdentityImage;
	}
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public int getShopImage() {
		return shopImage;
	}
	public void setShopImage(int shopImage) {
		this.shopImage = shopImage;
	}
	public String getShopDescription() {
		return shopDescription;
	}
	public void setShopDescription(String shopDescription) {
		this.shopDescription = shopDescription;
	}
	public ShopBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
