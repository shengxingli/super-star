package bean;

import java.util.List;

public class MsgBean {
	private int msgId;
	private int userId;
	private int shopId;
	private int sender;//1.user 2.admin 3.sAdmin
	private UserBean user;
	private ShopBean shop;
	
	public int getSender() {
		return sender;
	}
	public void setSender(int sender) {
		this.sender = sender;
	}
	public MsgBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MsgBean(int msgId, int userId, int shopId, int msgDetailId, UserBean user, ShopBean shop,
			MsgDetailBean msgDetail) {
		super();
		this.msgId = msgId;
		this.userId = userId;
		this.shopId = shopId;
		this.user = user;
		this.shop = shop;
	}
	public int getMsgId() {
		return msgId;
	}
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public UserBean getUser() {
		return user;
	}
	public void setUser(UserBean user) {
		this.user = user;
	}
	public ShopBean getShop() {
		return shop;
	}
	public void setShop(ShopBean shop) {
		this.shop = shop;
	}

	
}
