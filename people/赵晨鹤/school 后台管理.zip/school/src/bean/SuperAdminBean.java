package bean;

public class SuperAdminBean {
	private int superAdminId;
	private String superAdminName;
	private String superAdminPassword;
	private String superAdminEmail;
	public int getSuperAdminId() {
		return superAdminId;
	}
	public void setSuperAdminId(int superAdminId) {
		this.superAdminId = superAdminId;
	}
	public String getSuperAdminName() {
		return superAdminName;
	}
	public void setSuperAdminName(String superAdminName) {
		this.superAdminName = superAdminName;
	}
	public String getSuperAdminPassword() {
		return superAdminPassword;
	}
	public void setSuperAdminPassword(String superAdminPassword) {
		this.superAdminPassword = superAdminPassword;
	}
	public String getSuperAdminEmail() {
		return superAdminEmail;
	}
	public void setSuperAdminEmail(String superAdminEmail) {
		this.superAdminEmail = superAdminEmail;
	}
	public SuperAdminBean(int superAdminId, String superAdminName, String superAdminPassword, String superAdminEmail) {
		super();
		this.superAdminId = superAdminId;
		this.superAdminName = superAdminName;
		this.superAdminPassword = superAdminPassword;
		this.superAdminEmail = superAdminEmail;
	}
	public SuperAdminBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
