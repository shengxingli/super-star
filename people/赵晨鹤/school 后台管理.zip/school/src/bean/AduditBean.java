package bean;

public class AduditBean {
	private int aduditId;
	private int userId;
	private int shopId;
	private UserBean user;
	private ShopBean shop;
	private String shopState;
	public String getShopState() {
		return shopState;
	}
	public void setShopState(String shopState) {
		this.shopState = shopState;
	}
	public int getAduditId() {
		return aduditId;
	}
	public void setAduditId(int aduditId) {
		this.aduditId = aduditId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public UserBean getUser() {
		return user;
	}
	public void setUser(UserBean user) {
		this.user = user;
	}
	public ShopBean getShop() {
		return shop;
	}
	public void setShop(ShopBean shop) {
		this.shop = shop;
	}
	public AduditBean(int aduditId, int userId, int shopId, UserBean user, ShopBean shop) {
		super();
		this.aduditId = aduditId;
		this.userId = userId;
		this.shopId = shopId;
		this.user = user;
		this.shop = shop;
	}
	public AduditBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
