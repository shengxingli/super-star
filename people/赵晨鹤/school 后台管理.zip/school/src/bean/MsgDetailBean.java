package bean;

import java.util.Date;

public class MsgDetailBean {
	private int msgDetailId;
	private int msgId;
	private String msgContent;
	private Date msgTime;
	private int sender;//发送人，商家0，其他1
	
	public MsgDetailBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public MsgDetailBean(int msgDetailId, int msgId, String msgContent, Date msgTime, int sender) {
		super();
		this.msgDetailId = msgDetailId;
		this.msgId = msgId;
		this.msgContent = msgContent;
		this.msgTime = msgTime;
		this.sender = sender;
	}

	public int getMsgDetailId() {
		return msgDetailId;
	}
	public void setMsgDetailId(int msgDetailId) {
		this.msgDetailId = msgDetailId;
	}
	public int getMsgId() {
		return msgId;
	}
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	public String getMsgContent() {
		return msgContent;
	}
	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}
	public Date getMsgTime() {
		return msgTime;
	}
	public void setMsgTime(Date msgTime) {
		this.msgTime = msgTime;
	}

	public int getSender() {
		return sender;
	}

	public void setSender(int sender) {
		this.sender = sender;
	}
	
	
}
