package bean;

public class SuperManagerBean {
	private int superManagerId;
	private String superManagerName;
	private String superManagerPassword;
	private String superManagerEmail;
	public int getSuperManagerId() {
		return superManagerId;
	}
	public void setSuperManagerId(int superManagerId) {
		this.superManagerId = superManagerId;
	}
	public String getSuperManagerName() {
		return superManagerName;
	}
	public void setSuperManagerName(String superManagerName) {
		this.superManagerName = superManagerName;
	}
	public String getSuperManagerPassword() {
		return superManagerPassword;
	}
	public void setSuperManagerPassword(String superManagerPassword) {
		this.superManagerPassword = superManagerPassword;
	}
	public String getSuperManagerEmail() {
		return superManagerEmail;
	}
	public void setSuperManagerEmail(String superManagerEmail) {
		this.superManagerEmail = superManagerEmail;
	}
	public SuperManagerBean(int superManagerId, String superManagerName, String superManagerPassword,
			String superManagerEmail) {
		super();
		this.superManagerId = superManagerId;
		this.superManagerName = superManagerName;
		this.superManagerPassword = superManagerPassword;
		this.superManagerEmail = superManagerEmail;
	}
	public SuperManagerBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
