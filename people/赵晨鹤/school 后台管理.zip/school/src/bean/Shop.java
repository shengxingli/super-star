package bean;

public class Shop {
	private ShopBean shopBean;
	private String userName;
	public ShopBean getShopBean() {
		return shopBean;
	}
	public void setShopBean(ShopBean shopBean) {
		this.shopBean = shopBean;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String string) {
		this.userName = string;
	}
	public Shop(ShopBean shopBean, String userName) {
		super();
		this.shopBean = shopBean;
		this.userName = userName;
	}
	public Shop() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
