package bean;

public class UserBean {
	private int userId;
	private String userTel;
	private int userImage;
	private String userName;
	private String userPassword;
	private String userAddress;
	private String userEmail;
	private int shopId;
	private int userElogin;
	private int shopCartId;
	
	public UserBean(int userId, String userTel, int userImage, String userName, String userPassword, String userAddress,
			String userEmail, int shopId, int userElogin, int shopCartId) {
		super();
		this.userId = userId;
		this.userTel = userTel;
		this.userImage = userImage;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAddress = userAddress;
		this.userEmail = userEmail;
		this.shopId = shopId;
		this.userElogin = userElogin;
		this.shopCartId = shopCartId;
	}
	public int getShopCartId() {
		return shopCartId;
	}
	public void setShopCartId(int shopCartId) {
		this.shopCartId = shopCartId;
	}
	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserTel() {
		return userTel;
	}
	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}
	public int getUserImage() {
		return userImage;
	}
	public void setUserImage(int userImage) {
		this.userImage = userImage;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public int getUserElogin() {
		return userElogin;
	}
	public void setUserElogin(int userElogin) {
		this.userElogin = userElogin;
	}
	
}