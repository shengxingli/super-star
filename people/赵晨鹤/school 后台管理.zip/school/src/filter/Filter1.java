package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class Filter1
 */
@WebFilter("/Filter1")
public class Filter1 implements Filter {

    /**
     * Default constructor. 
     */
    public Filter1() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		HttpSession session = req.getSession();

		String url = req.getRequestURL().toString();
		if (url.contains("LoginCheckServlet")) {
				chain.doFilter(req, resp);
		} else if (req.getParameter("adminName") == null) {
			if (session.getAttribute("admin") == null) {// 没有登录过
				req.getRequestDispatcher("login.jsp").forward(req, resp);
			} else {
				chain.doFilter(req, resp);
			}	
		}else if(req.getParameter("sAdminName") == null) {
			if (session.getAttribute("admin") == null) {// 没有登录过
				req.getRequestDispatcher("loginSuper.jsp").forward(req, resp);
			} else {
				chain.doFilter(req, resp);
			}
		}

	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
