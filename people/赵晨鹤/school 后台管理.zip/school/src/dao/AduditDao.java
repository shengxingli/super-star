package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.AduditBean;


public class AduditDao {
	public List<AduditBean> getAllAdudit(String state){
		List<AduditBean> aduditList=new ArrayList<AduditBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select adudit_id,user_id,shop_id from adudit where shop_state=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, state);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				AduditBean adudit=new AduditBean(); 
				adudit.setAduditId(rs.getInt(1));
				adudit.setUserId(rs.getInt(2));
				adudit.setShopId(rs.getInt(3));
				adudit.setUser(new UserDao().getUserByUserId(adudit.getUserId()));
				adudit.setShop(new ShopDao().getShopByShopId(adudit.getShopId()));
				aduditList.add(adudit);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return aduditList;
	}
	public void update(String state,int aduditId) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql = "update adudit set shop_state=? where adudit_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, state);
			pstmt.setInt(2,aduditId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void delete(int aduditId) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql = "delete from adudit where adudit_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,aduditId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}