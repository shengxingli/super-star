package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.AdminBean;
import bean.SuperAdminBean;


public class AdminDao {
	public void addAdmin(AdminBean admin,String image) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into admin(admin_name,admin_password,admin_email,admin_image) values(?,?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, admin.getAdminName());
			pstmt.setString(2, admin.getAdminPassword());
			pstmt.setString(3, admin.getAdminEmail());
			pstmt.setString(4, image);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 
		public void deleteAdminById(int adminId) {
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="delete from admin where admin_id=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setInt(1, adminId);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

		public AdminBean selectAdminByName(String adminName) {
			AdminBean admin=new AdminBean();
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			String sql="select admin_id,admin_name,admin_password,admin_email from admin where admin_name=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, adminName);
				rs=pstmt.executeQuery();
				while(rs.next()) {
					admin.setAdminId(rs.getInt(1));
					admin.setAdminName(rs.getString(2));
					admin.setAdminPassword(rs.getString(3));
					admin.setAdminEmail(rs.getString(4));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return admin;
		}
		
		public AdminBean selectAdminById(String adminId1) {
			AdminBean admin=new AdminBean();
			Connection conn=DataBase.getConnection();
			int adminId = Integer.parseInt(adminId1);
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			String sql="select admin_id,admin_name,admin_password,admin_email from admin where admin_id=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setInt(1, adminId);
				rs=pstmt.executeQuery();
				while(rs.next()) {
					admin.setAdminId(rs.getInt(1));
					admin.setAdminName(rs.getString(2));
					admin.setAdminPassword(rs.getString(3));
					admin.setAdminEmail(rs.getString(4));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return admin;
		}
		public void updateAdminPasswordById(int adminId,String adminPassword) {
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="update admin set admin_password=? where admin_id=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, adminPassword);
				pstmt.setInt(2, adminId);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public void updateAdminById(int adminId,String adminPassword,String adminEmail) {
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="update admin set admin_password=?,admin_email=? where admin_id=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, adminPassword);
				pstmt.setString(2, adminEmail);
				pstmt.setInt(3, adminId);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public void updateAdminEmailById(int adminId,String adminEmail) {
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="update admin set admin_email=? where admin_id=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, adminEmail);
				pstmt.setInt(2, adminId);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public int getAdminIdByName(String name){
			int id = 0;
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="select admin_id from admin where admin_name=?";
			ResultSet rs=null;
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, name);
				rs = pstmt.executeQuery();
				while(rs.next()) {
				id=rs.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return id;
		}
		public List<AdminBean> getAllAdmin(){
			List<AdminBean> adminList=new ArrayList<AdminBean>();
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="select admin_id,admin_name,admin_password,admin_email from admin";
			ResultSet rs=null;
			try {
				pstmt=conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while(rs.next()) {
					AdminBean admin=new AdminBean(); 
					admin.setAdminId(rs.getInt(1));
					admin.setAdminName(rs.getString(2));
					admin.setAdminPassword(rs.getString(3));
					admin.setAdminEmail(rs.getString(4));
					adminList.add(admin);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return adminList;
		}
		public boolean loginCheck(AdminBean admin) {
			AdminBean admin1=new AdminBean();
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="select admin_name,admin_password from admin where admin_name=?";
			ResultSet rs=null;
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, admin.getAdminName());
				rs=pstmt.executeQuery();
				while(rs.next()) {
					admin1.setAdminName(rs.getString(1));
					admin1.setAdminPassword(rs.getString(2));
				} 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(admin1.getAdminPassword().equals(admin.getAdminPassword())){
				return true;
			}else {
				return false;
			}
			
		}
		public boolean loginCheck1(AdminBean admin) {
			AdminBean admin1=new AdminBean();
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="select admin_name from admin where admin_name=?";
			ResultSet rs=null;
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, admin.getAdminName());
				rs = pstmt.executeQuery();
				while(rs.next()) {
					admin1.setAdminName(rs.getString(1));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(!(admin1.getAdminName() == null)){
				return true;
			}else {
				return false;
			}
		
		}
}
