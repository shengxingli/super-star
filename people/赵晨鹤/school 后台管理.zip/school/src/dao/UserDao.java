package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.ShopBean;
import bean.UserBean;

public class UserDao {
	public void updateShop(int shopId,int userId) {
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		String sql = "update user set shop_id=? where user_id =?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shopId);
			pstmt.setInt(2, userId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public UserBean getUserByShopId(int shopId) {
		UserBean userBean = new UserBean();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select user_id,user_name,user_tel,user_image,user_password,user_address,user_email,user_elogin,shoppcart_id from user where shop_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shopId);
			rs = pstmt.executeQuery();
			while(rs.next()){
				userBean.setUserId(rs.getInt(1));
				userBean.setUserName(rs.getString(2));
				userBean.setUserTel(rs.getString(3));
				userBean.setUserImage(rs.getInt(4));
				userBean.setUserPassword(rs.getString(5));
				userBean.setUserAddress(rs.getString(6));
				userBean.setUserEmail(rs.getString(7));
				userBean.setUserElogin(rs.getInt(8));
				userBean.setShopCartId(rs.getInt(9));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userBean;
		
	}
	public UserBean getUserByUserId(int userId) {
		UserBean userBean = new UserBean();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select user_id,user_name,user_tel,user_image,user_password,user_address,user_email,user_elogin,shoppcart_id from user where user_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				userBean.setUserId(rs.getInt(1));
				userBean.setUserName(rs.getString(2));
				userBean.setUserTel(rs.getString(3));
				userBean.setUserImage(rs.getInt(4));
				userBean.setUserPassword(rs.getString(5));
				userBean.setUserAddress(rs.getString(6));
				userBean.setUserEmail(rs.getString(7));
				userBean.setUserElogin(rs.getInt(8));
				userBean.setShopCartId(rs.getInt(9));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userBean;
	}
}
