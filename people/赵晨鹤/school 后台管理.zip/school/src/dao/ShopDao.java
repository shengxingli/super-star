package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.ShopBean;

public class ShopDao {
	public List<ShopBean> getAllShop() {
		List<ShopBean> list = new ArrayList<>();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select shop_id,shop_name,shop_address,shop_image,shop_description from shop";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ShopBean shopBean = new ShopBean();
				shopBean.setShopId(rs.getInt(1));
				shopBean.setShopName(rs.getString(2));
				shopBean.setShopAddress(rs.getString(3));
				shopBean.setShopImage(rs.getInt(4));
				shopBean.setShopDescription(rs.getString(5));
				list.add(shopBean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	public ShopBean getShopById(int i) {
		ShopBean shopBean = new ShopBean();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select shop_id,shop_name,shop_address,shop_image,shop_description from shop where shop_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, i);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				shopBean.setShopId(rs.getInt(1));
				shopBean.setShopName(rs.getString(2));
				shopBean.setShopAddress(rs.getString(3));
				shopBean.setShopImage(rs.getInt(4));
				shopBean.setShopDescription(rs.getString(5));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return shopBean;
		
	}
	public ShopBean selectShopByShopName(String shopName) {
		ShopBean shopBean = new ShopBean();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select shop_name,shop_address,shop_image,shop_description from shop where shop_name=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, shopName);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				shopBean.setShopName(rs.getString(1));
				shopBean.setShopAddress(rs.getString(2));
				shopBean.setShopImage(rs.getInt(3));
				shopBean.setShopDescription(rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return shopBean;
		
	}
	public ShopBean getShopByShopId(int shopId) {
		ShopBean shopBean = new ShopBean();
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select shop_id,shop_name,shop_address,shop_image,shop_description from shop where shop_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shopId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				shopBean.setShopId(shopId);
				shopBean.setShopName(rs.getString(2));
				shopBean.setShopAddress(rs.getString(3));
				shopBean.setShopImage(rs.getInt(4));
				shopBean.setShopDescription(rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return shopBean;
	}
	public void deleteShop(int shopId) {
		Connection conn = DataBase.getConnection();
		PreparedStatement pstmt = null;
		String sql = "delete from shop where shop_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, shopId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
