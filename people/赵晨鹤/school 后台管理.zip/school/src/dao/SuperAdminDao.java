package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.SuperAdminBean;


public class SuperAdminDao {
	public void addSuperAdmin(SuperAdminBean sAdmin) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into super_admin(super_admin_name,super_admin_password,super_admin_email) values(?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1,sAdmin.getSuperAdminName());
			pstmt.setString(2, sAdmin.getSuperAdminPassword());
			pstmt.setString(3, sAdmin.getSuperAdminEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 
	public void deleteSuperAdminById(int sAdminId) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from super_admin where super_admin_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, sAdminId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void deleteSuperAdminByName(String sAdminName) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from super_admin where super_admin_name=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sAdminName);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

	public SuperAdminBean selectSuperAdminByName(String sAdminName) {
		SuperAdminBean sAdmin=new SuperAdminBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select super_admin_id,super_admin_name,super_admin_password,super_admin_email from super_admin where super_admin_name=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sAdminName);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				sAdmin.setSuperAdminId(rs.getInt(1));
				sAdmin.setSuperAdminName(rs.getString(2));
				sAdmin.setSuperAdminPassword(rs.getString(3));
				sAdmin.setSuperAdminEmail(rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sAdmin;
	}
	public void updateSuperAdminPasswordById(int sAdminId,String sAdminPassword) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="update super_admin set super_admin_password=? where super_admin_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sAdminPassword);
			pstmt.setInt(2, sAdminId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void updateSuperAdminEmailById(int sAdminId,String sAdminEmail) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="update super_admin set super_admin_email=? where super_admin_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sAdminEmail);
			pstmt.setInt(2, sAdminId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public List<SuperAdminBean> getAllSuperAdmin(){
		SuperAdminBean sAdmin=new SuperAdminBean(); 
		List<SuperAdminBean> sAdminList=new ArrayList<SuperAdminBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select super_admin_id,super_admin_name,super_admin_password,super_admin_email from super_admin";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				sAdmin.setSuperAdminId(rs.getInt(1));
				sAdmin.setSuperAdminName(rs.getString(2));
				sAdmin.setSuperAdminPassword(rs.getString(3));
				sAdmin.setSuperAdminEmail(rs.getString(4));
				sAdminList.add(sAdmin);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sAdminList;
	}
	public int getSuperAdminIdByName(String name){
		int id=0;

		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select super_admin_id from super_admin where super_admin_name=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				id=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}
	public boolean loginCheck1(SuperAdminBean sAdmin) {
		SuperAdminBean sAdmin1=new SuperAdminBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select super_admin_name from super_admin where super_admin_name=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sAdmin.getSuperAdminName());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				sAdmin1.setSuperAdminName(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!(sAdmin1.getSuperAdminName() == null)){
			return true;
		}else {
			return false;
		}
	}
	public boolean loginCheck(SuperAdminBean sAdmin) {
		SuperAdminBean sAdmin1=new SuperAdminBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select super_admin_name,super_admin_password from super_admin where super_admin_name=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sAdmin.getSuperAdminName());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				sAdmin1.setSuperAdminName(rs.getString(1));
				sAdmin1.setSuperAdminPassword(rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(sAdmin1.getSuperAdminPassword().equals(sAdmin.getSuperAdminPassword())){
			return true;
		}else {
			return false;
		}
	}
}
