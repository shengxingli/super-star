package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bean.MsgDetailBean;

public class MsgDetailDao {

	public MsgDetailBean getMsgDetailById(int i){
		MsgDetailBean msgDetail=new MsgDetailBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select msg_detail_id,msg_id,msg_content,msg_time,sender from msg_detail where msg_detail_id=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, i);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				msgDetail.setMsgDetailId(rs.getInt(1));
				msgDetail.setMsgId(rs.getInt(2));
				msgDetail.setMsgContent(rs.getString(3));
				msgDetail.setMsgTime(rs.getDate(4));
				msgDetail.setSender(rs.getInt(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msgDetail;
	}
	public void addMsgDetail(MsgDetailBean msgDetail) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into msg_detail(msg_id,msg_content,msg_time,sender) values(?,?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, msgDetail.getMsgId());
			pstmt.setString(2, msgDetail.getMsgContent());
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			pstmt.setString(3, df.format(new Date()));
			pstmt.setInt(4, msgDetail.getSender());
			pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleteMsgDetailById(int i) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from msg_detail where msg_detail_id=?";
		try {
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, i);
			pstmt.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public List<MsgDetailBean> getMsgDetailListByMsgId(int i){
		List<MsgDetailBean> subMsgDetailList=new ArrayList<MsgDetailBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select msg_detail_id,msg_id,msg_content,msg_time,sender from msg_detail where msg_id=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, i);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				MsgDetailBean msgDetail=new MsgDetailBean();
				msgDetail.setMsgDetailId(rs.getInt(1));
				msgDetail.setMsgId(rs.getInt(2));
				msgDetail.setMsgContent(rs.getString(3));
				msgDetail.setMsgTime(rs.getDate(4));
				msgDetail.setSender(rs.getInt(5));
				subMsgDetailList.add(msgDetail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return subMsgDetailList;
	}
}
