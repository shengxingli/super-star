package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.MsgBean;

public class MsgDao {
	public List<MsgBean> getAllMsg(){
		List<MsgBean> msgList=new ArrayList<MsgBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select msg_id,user_id,shop_id,sender from msg";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				MsgBean msg=new MsgBean();
				msg.setMsgId(rs.getInt(1));
				msg.setUserId(rs.getInt(2));
				msg.setShopId(rs.getInt(3));
				msg.setSender(rs.getInt(4));
				msg.setUser(new UserDao().getUserByUserId(rs.getInt(2)));
				msg.setShop(new ShopDao().getShopById(rs.getInt(3)));
				msgList.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msgList;
	}
	public int getMsgId(int userId,int shopId,int sender){
		int id=0;
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select msg_id from msg where user_id=? and shop_id=? and sender=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			pstmt.setInt(2, shopId);
			pstmt.setInt(3, sender);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				id=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}
	public MsgBean getMsgById(int i){
		MsgBean msg=new MsgBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select msg_id,user_id,shop_id,sender from msg where msg_id=?";
		ResultSet rs=null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, i);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				msg.setMsgId(rs.getInt(1));
				msg.setUserId(rs.getInt(2));
				msg.setShopId(rs.getInt(3));
				msg.setSender(rs.getInt(4));
				msg.setUser(new UserDao().getUserByUserId(rs.getInt(2)));
				msg.setShop(new ShopDao().getShopById(rs.getInt(3)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}
	public void addMsg(MsgBean msg) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into msg(user_id,shop_id,sender) values(?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, msg.getUserId());
			pstmt.setInt(2, msg.getShopId());
			pstmt.setInt(3, msg.getSender());
			pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void deleteMsgById(int i) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from msg where msg_id=?";
		try {
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1, i);
			pstmt.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
