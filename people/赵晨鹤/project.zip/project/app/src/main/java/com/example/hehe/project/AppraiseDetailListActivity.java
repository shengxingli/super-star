package com.example.hehe.project;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppraiseDetailListActivity extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appraisedetail);
        initAppraiseDetail();
    }

    private void initAppraiseDetail() {
        // 1. 获取数据
        List<Map<String, Object>> listData = getDataList();
        // 2. 创建Adapter
        CustomAdapter adapter = new CustomAdapter(this,
                R.layout.appraisedetail, listData);
        // 3. 给ListView设置Adapter
        ListView listView = findViewById(R.id.list_appraise_detail);
        listView.setAdapter(adapter);
        // 4. 绑定监听器
    }
    private class CustomAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutId;
        private List<Map<String, Object>> data;

        public CustomAdapter(Context context,   // 上下文环境
                             int itemLayoutId,  // item的View模板布局
                             List<Map<String, Object>> data) {  // 数据
            this.context = context;
            this.itemLayoutId = itemLayoutId;
            this.data = data;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position,       // 位置
                            View convertView,   // 转换View
                            ViewGroup parent) { // 新生成的View的父容器
            LayoutInflater inflater = LayoutInflater.from(context);
            View viewNew = inflater.inflate(itemLayoutId, null);
            TextView userName = viewNew.findViewById(R.id.text_view_name);
            ImageView headImage = viewNew.findViewById(R.id.image_view_touxiang);
            TextView appraise = viewNew.findViewById(R.id.appraise);
            TextView repaly = viewNew.findViewById(R.id.replay);
            // 根据Item位置，获取data（List）中对应位置的数据map
            Map<String, Object> map = data.get(position);
            // 从map中根据[键]找到对应的[值]，并设置到相应控件
            userName.setText((String)map.get("name"));
            headImage.setImageResource((int)map.get("image"));
            appraise.setText((String)map.get("appraise"));
            repaly.setText((String)map.get("replay"));
            // 返回创建好的View（已经设置完数据）
            return viewNew;
        }
    }
    private List<Map<String, Object>> getDataList() {
        List<Map<String, Object>> list = new ArrayList();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("name","呵呵呵呵呵");
        map1.put("image",R.drawable.touxiang);
        map1.put("appraise","众老忧添岁，余衰喜入春。年开第七秩，屈指几多人。”每每读到白居易的这首诗，总是让人心生感慨。大多数人越老越怕添新岁，诗人却与众不同，面对新春欢喜雀跃，因为他觉得，年纪开始了第七个10年的人，屈指算来，并不多见，故此值得高兴。可见，拥有好的心境，面对世事就能乐观处之。");
        map1.put("replay","众老忧添岁，余衰喜入春。年开第七秩，屈指几多人。”每每读到白居易的这首诗，总是让人心生感慨。大多数人越老越怕添新岁，诗人却与众不同，面对新春欢喜雀跃，因为他觉得，年纪开始了第七个10年的人，屈指算来，并不多见，故此值得高兴。可见，拥有好的心境，面对世事就能乐观处之。");
        Map<String, Object> map2 = new HashMap<>();
        map2.put("name","呵哈哈哈");
        map2.put("image",R.drawable.touxiang);
        map2.put("appraise","众老忧添岁，余衰喜入春。年开第七秩，屈指几多人。”每每读到白居易的这首诗，总是让人心生感慨。大多数人越老越怕添新岁，诗人却与众不同，面对新春欢喜雀跃，因为他觉得，年纪开始了第七个10年的人，屈指算来，并不多见，故此值得高兴。可见，拥有好的心境，面对世事就能乐观处之。");
        map2.put("replay","众老忧添岁，余衰喜入春。年开第七秩，屈指几多人。”每每读到白居易的这首诗，总是让人心生感慨。大多数人越老越怕添新岁，诗人却与众不同，面对新春欢喜雀跃，因为他觉得，年纪开始了第七个10年的人，屈指算来，并不多见，故此值得高兴。可见，拥有好的心境，面对世事就能乐观处之。");
        Map<String, Object> map3 = new HashMap<>();
        map3.put("name","呵呵呵哈哈哈");
        map3.put("image",R.drawable.touxiang);
        map3.put("appraise","众老忧添岁，余衰喜入春。年开第七秩，屈指几多人。”每每读到白居易的这首诗，总是让人心生感慨。大多数人越老越怕添新岁，诗人却与众不同，面对新春欢喜雀跃，因为他觉得，年纪开始了第七个10年的人，屈指算来，并不多见，故此值得高兴。可见，拥有好的心境，面对世事就能乐观处之。");
        map3.put("replay","众老忧添岁，余衰喜入春。年开第七秩，屈指几多人。”每每读到白居易的这首诗，总是让人心生感慨。大多数人越老越怕添新岁，诗人却与众不同，面对新春欢喜雀跃，因为他觉得，年纪开始了第七个10年的人，屈指算来，并不多见，故此值得高兴。可见，拥有好的心境，面对世事就能乐观处之。");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        return  list;
    }
}
