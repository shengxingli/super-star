package com.example.hehe.registershopdemo;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MoneyTask extends AsyncTask{
    List<Order> allorderList=new ArrayList<>();
    List<Order> morderList=new ArrayList<>();
    List<Order> lmorderList=new ArrayList<>();
    List<Order> yorderList=new ArrayList<>();
    @Override
    protected Object doInBackground(Object[] objects) {
        URL url = null;
        try {
            url = new URL("http://10.7.88.213:8080/shop/MoneyServlet?shopId=1");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //设置请求参数
            connection.setRequestProperty("contentType", "utf-8");
            InputStream is = connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(is);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);//字符流
            String res = bufferedReader.readLine();
            JSONArray array = new JSONArray(res);
            for(int i=0;i<array.length();i++){
                Order order=new Order();
                JSONObject obj=array.getJSONObject(i);
                order.setOrderId(obj.getInt("orderId"));
                order.setOrderPrice(obj.getDouble("orderPrice"));
                order.setOrderTime(obj.getString("orderTime"));
                allorderList.add(order);
                String[] str=order.getOrderTime().split(".");
                Calendar c = Calendar.getInstance();

                if(str[0].equals(c.get(Calendar.YEAR))) {
                    yorderList.add(order);
                    if (str[1].equals(c.get(Calendar.MONTH))) {
                        morderList.add(order);
                    }else if (str[1].equals(c.get(Calendar.MONTH) - 1)) {
                        lmorderList.add(order);
                    }
                }
            }
            setAllorderList(allorderList);
            setYorderList(yorderList);
            setLmorderList(lmorderList);
            setMorderList(morderList);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Order> getAllorderList() {
        return allorderList;
    }

    public void setAllorderList(List<Order> allorderList) {
        this.allorderList = allorderList;
    }

    public List<Order> getMorderList() {
        return morderList;
    }

    public void setMorderList(List<Order> morderList) {
        this.morderList = morderList;
    }

    public List<Order> getLmorderList() {
        return lmorderList;
    }

    public void setLmorderList(List<Order> lmorderList) {
        this.lmorderList = lmorderList;
    }

    public List<Order> getYorderList() {
        return yorderList;
    }

    public void setYorderList(List<Order> yorderList) {
        this.yorderList = yorderList;
    }
}
