package com.example.hehe.registershopdemo;

public class Shop {
    private int shopIdentityImage;
    private String shopName;
    private String shopDescription;
    private String shopAddress;
    private int shopImage;

    public int getShopIdentityImage() {
        return shopIdentityImage;
    }

    public void setShopIdentityImage(int shopIdentityImage) {
        this.shopIdentityImage = shopIdentityImage;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getShopDescription() {
        return shopDescription;
    }

    public void setShopDescription(String shopDescription) {
        this.shopDescription = shopDescription;
    }

    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }

    public int getShopImage() {
        return shopImage;
    }

    public void setShopImage(int shopImage) {
        this.shopImage = shopImage;
    }
}
