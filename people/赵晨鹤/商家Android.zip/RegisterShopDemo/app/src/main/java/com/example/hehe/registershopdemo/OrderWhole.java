package com.example.hehe.registershopdemo;

public class OrderWhole {
    private String userName;
    private String orderTime;
    private double orderPrice;
    private String productName;
    private int productImage;
    private int productCount;
    private String specificationContent;
    private int orderDetailId;
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public OrderWhole(String userName, String message, String orderTime, double orderPrice, String productName, int productImage, int productCount, String specificationContent, int orderDetailId) {
        this.userName = userName;
        this.orderTime = orderTime;
        this.message = message;
        this.orderPrice = orderPrice;
        this.productName = productName;
        this.productImage = productImage;
        this.productCount = productCount;
        this.specificationContent = specificationContent;
        this.orderDetailId = orderDetailId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public double getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductImage() {
        return productImage;
    }

    public void setProductImage(int productImage) {
        this.productImage = productImage;
    }

    public int getProductCount() {
        return productCount;
    }

    public void setProductCount(int productCount) {
        this.productCount = productCount;
    }

    public String getSpecificationContent() {
        return specificationContent;
    }

    public void setSpecificationContent(String specificationContent) {
        this.specificationContent = specificationContent;
    }

    public int getOrderDetailId() {
        return orderDetailId;
    }

    public void setOrderDetailId(int orderDetailId) {
        this.orderDetailId = orderDetailId;
    }

    public OrderWhole() {
    }
}
