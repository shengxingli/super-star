package com.example.hehe.registershopdemo;

import java.util.List;

public class Msg {
    private int msgId;
    private int userId;
    private int shopId;
    private String sender;
    private User user;
    private Shop shop;
    private List<MsgDetail> subMsgDetailList;
    public Msg() {}
    public Msg(int msgId, int userId, int shopId, User user, Shop shop) {
        this.msgId = msgId;
        this.userId = userId;
        this.shopId = shopId;
        this.user = user;
        this.shop = shop;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public int getMsgId() {
        return msgId;
    }

    public void setMsgId(int msgId) {
        this.msgId = msgId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public List<MsgDetail> getSubMsgDetailList() {
        return subMsgDetailList;
    }

    public void setSubMsgDetailList(List<MsgDetail> subMsgDetailList) {
        this.subMsgDetailList = subMsgDetailList;
    }

    @Override
    public String toString() {
        return "Msg{" +
                "msgId=" + msgId +
                ", userId=" + userId +
                ", shopId=" + shopId +
                ", user=" + user +
                ", shop=" + shop +
                ", subMsgDetailList=" + subMsgDetailList +
                '}';
    }
}
