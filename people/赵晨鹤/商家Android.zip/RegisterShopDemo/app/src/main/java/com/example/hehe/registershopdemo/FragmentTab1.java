package com.example.hehe.registershopdemo;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FragmentTab1 extends Fragment{
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_page1,
                container,
                false);
        ProductTask productTask=new ProductTask();
        int allNum=productTask.getAllNum();
        int allSaleNum=productTask.getAllSaleNum();
        productTask.execute();
        SystemClock.sleep(1000);
        TextView tvallNum=view.findViewById(R.id.tv_allnum);
        TextView tvSaleNum=view.findViewById(R.id.tv_salenum);
        tvallNum.setText(40+"");
        tvSaleNum.setText(30+"");

        LinearLayout post=view.findViewById(R.id.post);
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(getActivity(),PostActivity.class);
                startActivity(intent);
            }
        });
        TextView tvgoods=view.findViewById(R.id.tv_manager_goods);
        tvgoods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(getActivity(),ManagerGoodsActivity1.class);
                startActivity(intent);
            }
        });
        //更换显示内容
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}
