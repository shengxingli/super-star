package com.example.hehe.registershopdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FragmentTab3 extends Fragment {
    private LinearLayout lLDelivery;
    private LinearLayout lLPayment;
    private LinearLayout lLAppraise;
    private ImageView ivShopImage;
    private TextView tvShopName;
    private TextView tvDeliveryCount;
    private TextView tvPaymentCount;
    private TextView tvAppraiseCount;
    private LinearLayout order;
    private LinearLayout shop;
    private LinearLayout safe;
    private LinearLayout myMoney;
    private LinearLayout reviseShop;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_page3,
                container,
                false);
        lLDelivery = view.findViewById(R.id.ll_delivery);
        lLAppraise = view.findViewById(R.id.ll_appraise);
        lLPayment = view.findViewById(R.id.ll_payment);
        ivShopImage = view.findViewById(R.id.iv_shop_image);
        tvShopName = view.findViewById(R.id.tv_shop_name);
        tvDeliveryCount = view.findViewById(R.id.delivery_count);
        tvPaymentCount = view.findViewById(R.id.payment_count);
        tvAppraiseCount = view.findViewById(R.id.appraise_count);
        order = view.findViewById(R.id.orders);
        shop = view.findViewById(R.id.shop);
        safe = view.findViewById(R.id.l_safe);
        myMoney = view.findViewById(R.id.l_mymoney);
        reviseShop = view.findViewById(R.id.l_revise_shop);
        order.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), OrderActivity.class);
                    intent.putExtra("tab", "全部");
                    startActivity(intent);
                }
            }
        });
        shop.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), ShopActivity.class);
                    startActivity(intent);
                }
            }
        });
        safe.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), CountActivity.class);
                    startActivity(intent);
                }
            }
        });
        myMoney.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), MyMoneyActivity.class);
                    startActivity(intent);
                }
            }
        });
        reviseShop.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    Intent intent = new Intent();
                    intent.setClass(getActivity(),ReviseShopActivity.class);
                    startActivity(intent);
                }
            }
        });
        MimeTask mimeTask = new MimeTask();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        mimeTask.execute();
        ivShopImage.setImageResource(mimeTask.getShopImage());
        tvShopName.setText(mimeTask.getShopName());
        tvDeliveryCount.setText(mimeTask.getDeliveryCount());
        tvPaymentCount.setText(mimeTask.getPaymentCount());
        tvAppraiseCount.setText(mimeTask.getAppraiseCount());
        lLDelivery.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), OrderActivity.class);//实例
                    intent.putExtra("tab", "待发货");
                    startActivity(intent);
                }
            }
        });
        lLAppraise.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), OrderActivity.class);//实例
                    intent.putExtra("tab", "待评价");
                    startActivity(intent);
                }
            }
        });
        lLPayment.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), OrderActivity.class);//实例
                    intent.putExtra("tab", "待付款");
                    startActivity(intent);
                }
            }
        });
        return view;
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

}
