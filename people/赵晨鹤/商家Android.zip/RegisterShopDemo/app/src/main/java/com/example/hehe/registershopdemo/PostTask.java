package com.example.hehe.registershopdemo;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostTask extends AsyncTask{
    private int imageId;
    private String productName;
    private String productType;
    private String productNorms;
    private String productDescribe;
    private int num;
    private String res;

    @Override
    protected Object doInBackground(Object[] objects) {
        URL url = null;
        try {
            url = new URL("http://10.7.88.213:8080/shop/PostServlet?shopId=1&imageId="+imageId+
                    "&productName="+productName+"&productType="+productType+"&projectNorms"+productNorms+
                    "&productDescribe="+productDescribe+"&num="+num);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //设置请求参数
            connection.setRequestProperty("contentType", "utf-8");
            InputStream is = connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(is);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);//字符流
            res = bufferedReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return objects;
    }

    public String getRes() {
        return res;
    }

    public void setRes(String res) {
        this.res = res;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductNorms() {
        return productNorms;
    }

    public void setProductNorms(String productNorms) {
        this.productNorms = productNorms;
    }

    public String getProductDescribe() {
        return productDescribe;
    }

    public void setProductDescribe(String productDescribe) {
        this.productDescribe = productDescribe;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
