package com.example.hehe.registershopdemo;

public class MsgDetail {
    private int msgDetailId;
    private int msgId;
    private String msgContent;
    private String msgTime;
    private int emsg;
    public MsgDetail() {
    }

    public int getEmsg() {
        return emsg;
    }

    public void setEmsg(int emsg) {
        this.emsg = emsg;
    }

    public MsgDetail(int msgDetailId, int msgId, String msgContent, String msgTime) {
        this.msgDetailId = msgDetailId;
        this.msgId = msgId;
        this.msgContent = msgContent;
        this.msgTime = msgTime;
    }

    public int getMsgDetailId() {
        return msgDetailId;
    }

    public void setMsgDetailId(int msgDetailId) {
        this.msgDetailId = msgDetailId;
    }

    public int getMsgId() {
        return msgId;
    }

    public void setMsgId(int msgId) {
        this.msgId = msgId;
    }

    public String getMsgContent() {
        return msgContent;
    }

    public void setMsgContent(String msgContent) {
        this.msgContent = msgContent;
    }

    public String getMsgTime() {
        return msgTime;
    }

    public void setMsgTime(String msgTime) {
        this.msgTime = msgTime;
    }

    @Override
    public String toString() {
        return "MsgDetail{" +
                "msgDetailId=" + msgDetailId +
                ", msgId=" + msgId +
                ", msgContent='" + msgContent + '\'' +
                ", msgTime='" + msgTime + '\'' +
                ", emsg=" + emsg +
                '}';
    }
}
