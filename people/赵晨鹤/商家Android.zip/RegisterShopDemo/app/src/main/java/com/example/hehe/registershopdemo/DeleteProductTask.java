package com.example.hehe.registershopdemo;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DeleteProductTask extends AsyncTask {
    private int productId;
    private String res;
    @Override
    protected Object doInBackground(Object[] objects) {
        URL url = null;
        try {
            url = new URL("http://10.7.88.213:8080/shop/DeleteProductServlet?productId="+productId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //设置请求参数
            connection.setRequestProperty("contentType", "utf-8");
            InputStream is = connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(is);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);//字符流
            res = bufferedReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return objects;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getRes() {
        return res;
    }

    public void setRes(String res) {
        this.res = res;
    }
}
