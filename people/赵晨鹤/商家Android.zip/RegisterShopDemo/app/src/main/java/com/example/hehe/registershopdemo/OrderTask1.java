package com.example.hehe.registershopdemo;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class OrderTask1 extends AsyncTask {
    private List<OrderWhole> orderWholes = null;
    private int shopId = 1;
    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            URL url = new URL("http://10.7.88.215:8080/project1/SeeShopOrderServlet?remark1=seeorder&orderState=待付款&shopId="+shopId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType","UTF-8");
            InputStream in = connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String message = reader.readLine();
            Log.e("test",message);
            JSONArray jsonArray = new JSONArray(message);
            Log.e("test",jsonArray.get(1).toString());
            orderWholes = new ArrayList<>();
            for(int i = 0;i<jsonArray.length();++i){
                JSONObject object = jsonArray.getJSONObject(i);
                OrderWhole orderWhole = new OrderWhole();
                orderWhole.setOrderDetailId(object.getInt("orderDetiailId"));
                orderWhole.setUserName(object.getString("userName"));
                orderWhole.setOrderPrice(object.getDouble("orderPrice"));
                orderWhole.setOrderTime(object.getString("orderTime"));
                orderWhole.setProductImage(object.getInt("productImage"));
                orderWhole.setProductCount(object.getInt("productCount"));
                orderWhole.setSpecificationContent(object.getString("specificationContent"));
                orderWhole.setProductName(object.getString("productName"));
                orderWhole.setMessage(object.getString("message"));
                orderWholes.add(orderWhole);
            }
            setOrderWholes(orderWholes);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public OrderTask1() {
    }

    public OrderTask1(List<OrderWhole> orderWholes, int shopId) {
        this.orderWholes = orderWholes;
        this.shopId = shopId;
    }

    public List<OrderWhole> getOrderWholes() {
        return orderWholes;
    }

    public void setOrderWholes(List<OrderWhole> orderWholes) {
        this.orderWholes = orderWholes;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }
}
