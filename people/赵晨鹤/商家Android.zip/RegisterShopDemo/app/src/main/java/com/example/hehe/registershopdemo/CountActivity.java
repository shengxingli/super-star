package com.example.hehe.registershopdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class CountActivity extends AppCompatActivity {
    private Button btnCancelShop;
    private TextView tvShopName;
    private TextView tvUserName;
    private TextView tvUserTel;
    private ImageView ivRevisePhone;
    @Override
    protected void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.safe);
        btnCancelShop = findViewById(R.id.btn_cancel_shop);
        tvShopName = findViewById(R.id.shop_name);
        tvUserName = findViewById(R.id.user_name);
        tvUserTel = findViewById(R.id.user_tel);
        ivRevisePhone = findViewById(R.id.iv_phone);
        final CountTask countTask = new CountTask();
        countTask.execute();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        tvUserName.setText(countTask.getUserName());
        tvShopName.setText(countTask.getShopName());
        tvUserTel.setText(countTask.getUserTel());

        btnCancelShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CancelShopTask cancelShopTask = new CancelShopTask();
                cancelShopTask.execute();
                Intent intent = new Intent();
                intent.setClass(CountActivity.this,CountActivity.class);//例子
                startActivity(intent);
            }
        });
        ivRevisePhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(CountActivity.this,PhoneActivity.class);
                startActivity(intent);
            }
        });
    }
}
