package com.example.hehe.registershopdemo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;

public class ReviseShopActivity extends AppCompatActivity {

    private EditText etShopName;
    private EditText etShopAddress;
    private EditText etShopDescriprion;
    private Button btnPhoto;
    private Button btnSelect;
    private Button btnCancel;
    private ImageView ivShopImage;
    private PopupWindow popupWindow;
    private Listener listener;//icon
    private File cameraSavePath;//拍照照片路径
    private Uri uri;
    private String[] permissions={Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private int userId = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reviseshop);
        ivShopImage = findViewById(R.id.iv_shop_image);
        listener = new Listener();
        ivShopImage.setOnClickListener(listener);
        cameraSavePath = new File(Environment.getExternalStorageDirectory().getPath()
                + "/" + System.currentTimeMillis() + ".jpg");
        etShopName = findViewById(R.id.et_shop_name);
        etShopAddress = findViewById(R.id.et_shop_address);
        etShopDescriprion = findViewById(R.id.et_shop_description);
        ShopTask shopTask = new ShopTask();
        shopTask.setUserId(userId);
        shopTask.execute();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ivShopImage.setImageResource(shopTask.getShop().getShopImage());
        etShopName.setText(shopTask.getShop().getShopName());
        etShopAddress.setText(shopTask.getShop().getShopAddress());
        etShopDescriprion.setText(shopTask.getShop().getShopDescription());
        //点击修改店铺信息
        Button btnReviseShop = findViewById(R.id.btn_ok);
        btnReviseShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
//                int userId = Integer.parseInt(intent.getStringExtra("userId"));
                int rShopImage = ivShopImage.getId();
                String rShopName = etShopName.getText().toString();
                String rShopAddress = etShopAddress.getText().toString();
                String rShopDescription = etShopDescriprion.getText().toString();
                ReviseShopTask reviseShopTask = new ReviseShopTask();
                reviseShopTask.setUserId(userId);
                reviseShopTask.setrShopAddress(rShopAddress);
                reviseShopTask.setrShopDescription(rShopDescription);
                reviseShopTask.setrShopImage(rShopImage);
                reviseShopTask.setrShopName(rShopName);
                reviseShopTask.execute();
            }
        });
    }
    private class Listener implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.iv_shop_image:{
                    showPopupWindow();
                }
                break;
                case R.id.btn_photo:
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    uri= FileProvider.getUriForFile(ReviseShopActivity.this,"com.example.hehe.reviseshopinformation.fileprovider",cameraSavePath);
                    intent.addFlags( Intent.FLAG_GRANT_READ_URI_PERMISSION );
                    intent.putExtra( MediaStore.EXTRA_OUTPUT,uri );
                    ReviseShopActivity.this.startActivityForResult(intent, 2);
                }
                break;
                case R.id.btn_select:
                {
                    Intent intent=new Intent( Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI );
                    startActivityForResult( intent,1 );
                }
                break;
                case R.id.btn_cancel:
                {
                    popupWindow.dismiss();
                }
                break;
            }
        }
    }
    private void showPopupWindow() {
        View view=getLayoutInflater().inflate( R.layout.popupwindow,null );

        popupWindow=new PopupWindow( this );
        popupWindow.setContentView( view );
        popupWindow.setWidth( ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight( ViewGroup.LayoutParams.WRAP_CONTENT );

        btnPhoto=view.findViewById( R.id.btn_photo );
        btnSelect=view.findViewById( R.id.btn_select );
        btnCancel=view.findViewById( R.id.btn_cancel );

        btnPhoto.setOnClickListener( listener );
        btnSelect.setOnClickListener( listener );
        btnCancel.setOnClickListener( listener );

        //后期加弹出效果
        //popupWindow.setAnimationStyle(  );
        popupWindow.showAsDropDown(ivShopImage);
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1: {
                if (requestCode == 1 && resultCode == Activity.RESULT_OK && data != null) {

                    Uri selectedImage = data.getData();
                    String[] filePathColumns = {MediaStore.Images.Media.DATA};

                    Cursor c = getContentResolver().query(selectedImage, filePathColumns, null, null, null);
                    c.moveToFirst();

                    int columnIndex = c.getColumnIndex(filePathColumns[0]);
                    String imagePath = c.getString(columnIndex);

                    Bitmap bm = BitmapFactory.decodeFile(imagePath);
                    ivShopImage.setImageBitmap(bm);
                    c.close();
                    popupWindow.dismiss();
                }

            }
            break;

            case 2: {
                getPermission();
                String photoPath = null;
                /*Log.d("拍照返回图片路径:", photoPath);*/
                /*if (requestCode==CAMERA_RESULT_CODE&&requestCode==Activity.RESULT_OK){*/
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    photoPath = String.valueOf(cameraSavePath);
                    //裁剪显示特点部位
                    /*photoClip( data.getData() );*/
                } else {
                    photoPath = uri.getEncodedPath();
                }

                //可能是因为拍下的照片 保存不下来 有路径 没有图 可能是权限问题
                Glide.with(this).load(photoPath).into(ivShopImage);
                popupWindow.dismiss();
                /*  }*/

            }
            break;
        }
    }
    private void getPermission(){
        if (EasyPermissions.hasPermissions( this,permissions )){
            Toast.makeText( this, "已经申请相关权限", Toast.LENGTH_SHORT ).show();
        }else {
            EasyPermissions.requestPermissions( this,"需要获取您的相册、照相机使用权限",1,permissions );
        }
    }
    //框架权限
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult( requestCode, permissions, grantResults );
        EasyPermissions.onRequestPermissionsResult( requestCode,permissions,grantResults,this );
    }
    //打开权限
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {

        Toast.makeText(this, "相关权限获取成功", Toast.LENGTH_SHORT).show();
    }
    //用户未同意权限
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        Toast.makeText(this, "请同意相关权限，否则功能无法使用", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        popupWindow.dismiss();
    }
}
