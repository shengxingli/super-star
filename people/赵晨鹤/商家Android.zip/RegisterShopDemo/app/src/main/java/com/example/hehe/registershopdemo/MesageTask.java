package com.example.hehe.registershopdemo;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MesageTask extends AsyncTask{
    private List<Admin> admins=null;
    private List<Msg> msgs=null;
    private List<User> users=null;
    private List<MsgDetail> msgDetails=null;
    @Override
    protected Object doInBackground(Object[] objects) {
        URL url = null;
        try {
            url=new URL("http://10.7.88.213:8080/shop/MessageServlet?shopName=flower");
            HttpURLConnection connection=(HttpURLConnection) url.openConnection();
            //设置请求参数
            connection.setRequestProperty("contentType","utf-8");
            InputStream is=connection.getInputStream();
            InputStreamReader inputStreamReader=new InputStreamReader(is);
            BufferedReader bufferedReader=new BufferedReader(inputStreamReader);//字符流
            String res=bufferedReader.readLine();
            JSONArray array=new JSONArray(res);
            msgs=new ArrayList<>();
            msgDetails=new ArrayList<>();
            users=new ArrayList<>();
            for (int i=0;i<array.length();i++){
                JSONObject object=array.getJSONObject(i);
                Msg msg=new Msg();
                msg.setMsgId(object.getInt("msgId"));
                msg.setUserId(object.getInt("userId"));
                msg.setShopId(object.getInt("shopId"));
                msg.setSender(object.getString("sender"));
                msgs.add(msg);
                if(msg.getSender().equals("user")){
                    User user=new User();
                    user.setUserId(object.getInt("userId"));
                    user.setUserName(object.getString("userName"));
                    user.setUserImage(object.getInt("userImage"));
                    user.setShopId(object.getInt("ushopId"));
                    users.add(user);
                }else{
                    Admin admin=new Admin();
                    admin.setAdminId(object.getInt("adminId"));
                    admin.setAdminName(object.getString("adminName"));
                    admin.setAdminImage(object.getInt("adminImage"));
                    admins.add(admin);
                }

                MsgDetail msgDetail=new MsgDetail();
                msgDetail.setMsgDetailId(object.getInt("msgDetailId"));
                msgDetail.setMsgContent(object.getString("msgContent"));
                msgDetail.setMsgTime(object.getString("msgTime"));
                msgDetail.setMsgId(object.getInt("msgId"));
                msgDetail.setEmsg(object.getInt("emsg"));
                msgDetails.add(msgDetail);
            }
            setMsgs(msgs);
            setUsers(users);
            setAdmins(admins);
            setMsgDetails(msgDetails);
            Log.e(" msg1",users.toString());


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return objects;
    }

    public List<Msg> getMsgs() {
        return msgs;
    }

    public void setMsgs(List<Msg> msgs) {
        Log.e(" msg",msgs.toString());
        this.msgs = msgs;
    }

    public List<Admin> getAdmins() {
        return admins;
    }

    public void setAdmins(List<Admin> admins) {
        this.admins = admins;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<MsgDetail> getMsgDetails() {
        return msgDetails;
    }

    public void setMsgDetails(List<MsgDetail> msgDetails) {
        this.msgDetails = msgDetails;
    }
}
