package com.example.hehe.registershopdemo;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderActivity extends AppCompatActivity {
    private List<OrderWhole> orderWholes;
    private ListView listView;

    private LinearLayout lLAll;
    private LinearLayout lLAppraise;
    private LinearLayout lLPayment;
    private LinearLayout lLDelivery;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order);
        Intent intent = new Intent();
        String tab = intent.getStringExtra("tab");
        if(tab.equals("全部")){
            OrderTask orderTask = new OrderTask();
            orderTask.execute();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            orderWholes = orderTask.getOrderWholes();
        }else if(tab.equals("待付款")){
            OrderTask1 orderTask1 = new OrderTask1();
            orderTask1.execute();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            orderWholes = orderTask1.getOrderWholes();
        }else if(tab.equals("待评价")){
            OrderTask3 orderTask3 = new OrderTask3();
            orderTask3.execute();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            orderWholes = orderTask3.getOrderWholes();
        }else if(tab.equals("待发货")){
            OrderTask2 orderTask2 = new OrderTask2();
            orderTask2.execute();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            orderWholes = orderTask2.getOrderWholes();
        }
        lLAll =(LinearLayout)findViewById(R.id.ll_all);
        lLAppraise =(LinearLayout) findViewById(R.id.ll_appraise);
        lLDelivery =(LinearLayout) findViewById(R.id.ll_delivery);
        lLPayment = (LinearLayout)findViewById(R.id.ll_payment);
        lLAll.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    OrderTask orderTask = new OrderTask();
                    orderTask.execute();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    orderWholes = orderTask.getOrderWholes();
                    initListView2();
                    ListView listView = findViewById(R.id.lv_orderview);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, final int position, final long id) {
                            Button button = findViewById(R.id.btn_revise_order);
                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent();
                                    intent.setClass(OrderActivity.this,RegisterShopActivity.class);
                                    String userName = orderWholes.get(position).getUserName();
                                    int orderDetailId = orderWholes.get(position).getOrderDetailId();
                                    String productName = orderWholes.get(position).getProductName();
                                    int productImage = orderWholes.get(position).getProductImage();
                                    String message = orderWholes.get(position).getMessage();
                                    intent.putExtra("userName",userName);
                                    intent.putExtra("orderDetailId",orderDetailId);
                                    intent.putExtra("productName",productName);
                                    intent.putExtra("productImage",productImage);
                                    intent.putExtra("message",message);
                                    startActivity(intent);
                                }
                            });
                        }
                    });
                }
            }
        });
        lLPayment.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    OrderTask1 orderTask1 = new OrderTask1();
                    orderTask1.execute();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    orderWholes = orderTask1.getOrderWholes();
                    initListView2();
                    ListView listView = findViewById(R.id.lv_orderview);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, final int position, final long id) {
                            Button button = findViewById(R.id.btn_revise_order);
                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent();
                                    intent.setClass(OrderActivity.this,RegisterShopActivity.class);
                                    String userName = orderWholes.get(position).getUserName();
                                    int orderDetailId = orderWholes.get(position).getOrderDetailId();
                                    String productName = orderWholes.get(position).getProductName();
                                    int productImage = orderWholes.get(position).getProductImage();
                                    String message = orderWholes.get(position).getMessage();
                                    intent.putExtra("userName",userName);
                                    intent.putExtra("orderDetailId",orderDetailId);
                                    intent.putExtra("productName",productName);
                                    intent.putExtra("productImage",productImage);
                                    intent.putExtra("message",message);
                                    startActivity(intent);
                                }
                            });
                        }
                    });
                }
            }
        });
        lLDelivery.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    OrderTask2 orderTask2 = new OrderTask2();
                    orderTask2.execute();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    orderWholes = orderTask2.getOrderWholes();
                    initListView2();
                    ListView listView = findViewById(R.id.lv_orderview);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, final int position, final long id) {
                            Button button = findViewById(R.id.btn_revise_order);
                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent();
                                    intent.setClass(OrderActivity.this,RegisterShopActivity.class);
                                    String userName = orderWholes.get(position).getUserName();
                                    int orderDetailId = orderWholes.get(position).getOrderDetailId();
                                    String productName = orderWholes.get(position).getProductName();
                                    int productImage = orderWholes.get(position).getProductImage();
                                    String message = orderWholes.get(position).getMessage();
                                    intent.putExtra("userName",userName);
                                    intent.putExtra("orderDetailId",orderDetailId);
                                    intent.putExtra("productName",productName);
                                    intent.putExtra("productImage",productImage);
                                    intent.putExtra("message",message);
                                    startActivity(intent);
                                }
                            });
                        }
                    });
                }
            }
        });
        lLAppraise.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    OrderTask3 orderTask3 = new OrderTask3();
                    orderTask3.execute();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    orderWholes = orderTask3.getOrderWholes();
                    initListView2();
                    ListView listView = findViewById(R.id.lv_orderview);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, final int position, final long id) {
                            Button button = findViewById(R.id.btn_revise_order);
                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent();
                                    intent.setClass(OrderActivity.this,RegisterShopActivity.class);
                                    String userName = orderWholes.get(position).getUserName();
                                    int orderDetailId = orderWholes.get(position).getOrderDetailId();
                                    String productName = orderWholes.get(position).getProductName();
                                    int productImage = orderWholes.get(position).getProductImage();
                                    String message = orderWholes.get(position).getMessage();
                                    intent.putExtra("userName",userName);
                                    intent.putExtra("orderDetailId",orderDetailId);
                                    intent.putExtra("productName",productName);
                                    intent.putExtra("productImage",productImage);
                                    intent.putExtra("message",message);
                                    startActivity(intent);
                                }
                            });
                        }
                    });
                }
            }
        });
//        OrderTask orderTask = new OrderTask();
//        orderTask.execute();
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        orderWholes = orderTask.getOrderWholes();
        initListView2();
        ListView listView = findViewById(R.id.lv_orderview);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, final long id) {
                Button button = findViewById(R.id.btn_revise_order);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent();
                        intent.setClass(OrderActivity.this,RegisterShopActivity.class);
                        String userName = orderWholes.get(position).getUserName();
                        int orderDetailId = orderWholes.get(position).getOrderDetailId();
                        String productName = orderWholes.get(position).getProductName();
                        int productImage = orderWholes.get(position).getProductImage();
                        String message = orderWholes.get(position).getMessage();
                        intent.putExtra("userName",userName);
                        intent.putExtra("orderDetailId",orderDetailId);
                        intent.putExtra("productName",productName);
                        intent.putExtra("productImage",productImage);
                        intent.putExtra("message",message);
                        startActivity(intent);
                    }
                });
            }
        });

    }
    private List<Map<String,Object>> getDataList() {
        List<Map<String,Object>> list=new ArrayList<>();
        for(int i = 0;i<orderWholes.size();++i){
            String userName = orderWholes.get(i).getUserName();
            String productName = orderWholes.get(i).getProductName();
            int productImage = orderWholes.get(i).getProductImage();
            int productCount = orderWholes.get(i).getProductCount();
            double orderPrice = orderWholes.get(i).getOrderPrice();
            String message = orderWholes.get(i).getSpecificationContent();
            int orderDetailId = orderWholes.get(i).getOrderDetailId();
            Map<String,Object> map=new HashMap<>();
            map.put("userName",userName);
            map.put("productName",productName);
            map.put("productCount",productCount);
            map.put("orderPrice",orderPrice);
            map.put("message",message);
            map.put("productImage",productImage);
            list.add(map);
        }
        return list;
    }
    private void initListView2() {
        //1.获取数据
        List<Map<String,Object>> listData =getDataList();
        listView = findViewById(R.id.lv_orderview);
        //2.创建Adapter
        CustomAdapter adapter=new CustomAdapter(this,R.layout.listvieworder,listData);
        //3.给ListView设置Adapter

        listView.setAdapter(adapter);
        //4.绑定监听器
    }
    private class CustomAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutId;
        private List<Map<String,Object>> data;

        public CustomAdapter(Context context, //上下文环境
                             int itemLayoutId, //Item的View模板布局
                             List<Map<String,Object>>data){  //数据
            this.context=context;
            this.itemLayoutId=itemLayoutId;
            this.data=data;
        }

        //返回数据个数
        @Override
        public int getCount() {
            return data.size();
        }

        //根据ListView中Item位置返回Item对应数据
        @Override
        public Object getItem(int position) {//从零开始的下标
            return data.get(position);
        }

        //根据ListView中Item位置返回Item对应数据Id
        @Override
        public long getItemId(int position) {
            return position;
        }

        //核心函数，ListView根据位置,返回对应位置的Item的显示View
        @Override
        public View getView(int position,  //位置
                            View convertView,  //转换视图View
                            ViewGroup parent) { //新生成的View的父容器
            //布局填充器，根据布局文件来创建相应布局对象
            LayoutInflater inflater=LayoutInflater.from(context);
            //使用布局填充器，根据构造函数中接受到的布局文件ID创建对应对象
            View viewNew=inflater.inflate(itemLayoutId,null);
            //从viewNew(根据布局文件的跟元素类型LinearLayout)中获取对应控件
            TextView userName= viewNew.findViewById(R.id.tv_user_name);
            TextView productName= viewNew.findViewById(R.id.tv_product_name);
            TextView productCount= viewNew.findViewById(R.id.tv_product_count);
            TextView orderPrice= viewNew.findViewById(R.id.tv_order_price);
            TextView message= viewNew.findViewById(R.id.tv_message);
            TextView specification = viewNew.findViewById(R.id.tv_specification);
            ImageView productImage= viewNew.findViewById(R.id.iv_product_image);
            Button btnReviseOrder = viewNew.findViewById(R.id.btn_revise_order);
            Map<String,Object> map=data.get(position);
            //从map中根据键值的键对找到对应的值，并设置相应控件
            userName.setText((String)map.get("userName"));
            productName.setText((String)map.get("productName"));
            productCount.setText(map.get("productCount")+"");
            orderPrice.setText(map.get("orderPrice")+"");
            message.setText((String)map.get("message"));
            specification.setText((String)map.get("specification"));
            productImage.setImageResource((int)map.get("productImage"));
            return viewNew;
        }
    }

}
