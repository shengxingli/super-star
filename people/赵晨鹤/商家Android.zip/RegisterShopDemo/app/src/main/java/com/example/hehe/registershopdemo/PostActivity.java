package com.example.hehe.registershopdemo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;

public class PostActivity extends AppCompatActivity {
    private static final int IMAGE=1;
    private static final int CAMERA_RESULT_CODE=2;
    private static final int IMAGE_CLIP=3;
    private CircleImageView icon;
    private Button btn_photo;
    private Button btn_select;
    private Button btn_cancel;
    private PopupWindow popupWindow;
    private Listener listener;
    private File cameraSavePath;//拍照照片路径
    private Uri uri;//照片资源
    private String[] permissions={Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
        final Intent intent=new Intent();
        LinearLayout back=findViewById(R.id.iv_goods_back);
        icon=findViewById(R.id.iv_goods_image);
        Button post=findViewById(R.id.btn_fabu);
        listener=new Listener();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView image=findViewById(R.id.iv_goods_image);
                EditText etgoodsName=findViewById(R.id.et_goods_name);
                EditText etgoodsType=findViewById(R.id.et_goods_type);
                EditText etgoodsNorms=findViewById(R.id.et_goods_norms);
                EditText etgoodsnum=findViewById(R.id.et_goods_number);
                EditText etgoodsDescribe=findViewById(R.id.et_goods_describe);
                int imageId=image.getId();
                String goodsName=etgoodsName.getText().toString();
                String type=etgoodsType.getText().toString();
                String norms=etgoodsNorms.getText().toString();
                int num=Integer.parseInt(etgoodsnum.getText().toString());
                String desctibe=etgoodsDescribe.getText().toString();
                PostTask postTask=new PostTask();
                postTask.setImageId(imageId);
                postTask.setProductName(goodsName);
                postTask.setProductType(type);
                postTask.setProductNorms(norms);
                postTask.setProductDescribe(desctibe);
                postTask.setNum(num);
                postTask.execute();
                Toast.makeText(PostActivity.this,"商品发布成功",Toast.LENGTH_LONG).show();
            }
        });
        icon.setOnClickListener( listener );

        cameraSavePath =new File( Environment.getExternalStorageDirectory().getPath()
                +"/"+System.currentTimeMillis()+".jpg");

    }

    //自定义监听器类
    private class Listener implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            //v就是你点击的控件
            switch (v.getId()){
                case R.id.iv_goods_image:{

                    showPopupWindow();
                }
                break;
                case R.id.btn_photo:
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                    uri= FileProvider.getUriForFile( PostActivity.this ,"com.example.hehe.registershopdemo.fileprovider",cameraSavePath);
                    intent.addFlags( Intent.FLAG_GRANT_READ_URI_PERMISSION );

                    intent.putExtra( MediaStore.EXTRA_OUTPUT,uri );
                    PostActivity.this.startActivityForResult(intent, CAMERA_RESULT_CODE);

                }
                break;
                case R.id.btn_select:
                {
                    Intent intent=new Intent( Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI );
                    startActivityForResult( intent,IMAGE );
                }
                break;
                case R.id.btn_cancel:
                {
                    popupWindow.dismiss();
                }
                break;


            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult( requestCode, resultCode, data );
        switch (requestCode)
        {
            case IMAGE:
            {
                if (requestCode==IMAGE&&resultCode== Activity.RESULT_OK&&data!=null){

                    Uri selectedImage = data.getData();
                    String[] filePathColumns = {MediaStore.Images.Media.DATA};

                    Cursor c = getContentResolver().query(selectedImage, filePathColumns, null, null, null);
                    c.moveToFirst();

                    int columnIndex = c.getColumnIndex(filePathColumns[0]);
                    String imagePath = c.getString(columnIndex);

                    Bitmap bm = BitmapFactory.decodeFile(imagePath);
                    icon.setImageBitmap(bm);

                    c.close();
                    popupWindow.dismiss();
                }

            }
            break;

            case CAMERA_RESULT_CODE:
            {
                getPermission();

                String photoPath=null;
                /*Log.d("拍照返回图片路径:", photoPath);*/
                /*if (requestCode==CAMERA_RESULT_CODE&&requestCode==Activity.RESULT_OK){*/
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    photoPath = String.valueOf(cameraSavePath);
                    //裁剪显示特点部位
                    /*photoClip( data.getData() );*/


                } else {
                    photoPath = uri.getEncodedPath();
                }

                //可能是因为拍下的照片 保存不下来 有路径 没有图 可能是权限问题

                Glide.with(this  ).load( photoPath ).into( icon);
                popupWindow.dismiss();
                /*  }*/

            }
            break;

       /*     case IMAGE_CLIP:
            {
                Bundle bundle=data.getExtras();

                if (bundle!=null){
                    Bitmap image=bundle.getParcelable( "data" );

                  *//*  icon.setImageBitmap( image );
                    String path=saveImage("头像",image);*//*
                }

            }
            break;*/
        }

    }
    private void showPopupWindow() {
        View view=getLayoutInflater().inflate( R.layout.popupwindow,null );

        popupWindow=new PopupWindow( this );
        popupWindow.setContentView( view );
        popupWindow.setWidth( ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight( ViewGroup.LayoutParams.WRAP_CONTENT );

        btn_photo=view.findViewById( R.id.btn_photo );
        btn_select=view.findViewById( R.id.btn_select );
        btn_cancel=view.findViewById( R.id.btn_cancel );

        btn_photo.setOnClickListener( listener );
        btn_select.setOnClickListener( listener );
        btn_cancel.setOnClickListener( listener );

        //后期加弹出效果
        //popupWindow.setAnimationStyle(  );
        popupWindow.showAsDropDown( icon,0,750 );

    }
/*

    private void photoClip(Uri uri){
    //调用系统图片裁剪

        Intent intent=new Intent( "com.android.camera.action.CROP" );
        intent.setDataAndType( uri,"image/*" );

        intent.putExtra( "crop","true" );
        intent.putExtra( "aspectX",1 );
        intent.putExtra( "aspectY",1 );
        intent.putExtra( "outputX",70 );
        intent.putExtra( "outputY",70 );
        intent.putExtra( "return-data",true);
        startActivityForResult( intent,IMAGE_CLIP );
    }*/

    //获取权限
    private void getPermission(){
        if (EasyPermissions.hasPermissions( this,permissions )){
            Toast.makeText( this, "已经申请相关权限", Toast.LENGTH_SHORT ).show();
        }else {
            EasyPermissions.requestPermissions( this,"需要获取您的相册、照相机使用权限",1,permissions );
        }
    }

    //框架权限
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult( requestCode, permissions, grantResults );
        EasyPermissions.onRequestPermissionsResult( requestCode,permissions,grantResults,this );
    }
    //打开权限
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {

        Toast.makeText(this, "相关权限获取成功", Toast.LENGTH_SHORT).show();
    }
    //用户未同意权限
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        Toast.makeText(this, "请同意相关权限，否则功能无法使用", Toast.LENGTH_SHORT).show();
    }

}
