package com.example.hehe.registershopdemo;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MoneyActivity extends Activity{
    int money=0;
    private List<Order> orderList;
    private ListView listView;
    private MoneyAdapter adapter;
    private List<Map<String,Object>> listDate;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money);
        listView=findViewById(R.id.lv_moneylist);
        MoneyTask moneyTask=new MoneyTask();
        moneyTask.execute();
        SystemClock.sleep(1000);
        orderList=new ArrayList<>();
        for(int i=0;i<moneyTask.getAllorderList().size();i++){
            Order order=new Order();
            order.setOrderId(moneyTask.getAllorderList().get(i).getOrderId());
            order.setOrderTime(moneyTask.getAllorderList().get(i).getOrderTime());
            order.setOrderPrice(moneyTask.getAllorderList().get(i).getOrderPrice());
            orderList.add(order);
        }
        initListView();
        TextView allmoney=findViewById(R.id.tv_all_money);
        for(int i=0;i<listDate.size();i++){
            money+=(int)listDate.get(i).get("price");
        }
        allmoney.setText("￥"+money);
        TextView thisMonth=findViewById(R.id.tv_this_month);
        TextView lastMonth=findViewById(R.id.tv_last_month);
        TextView year=findViewById(R.id.tv_year);
        TextView alllist=findViewById(R.id.tv_all);

        thisMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MoneyTask moneyTask=new MoneyTask();
                moneyTask.execute();
                SystemClock.sleep(1000);
                orderList=new ArrayList<>();
                for(int i=0;i<moneyTask.getMorderList().size();i++){
                    Order order=new Order();
                    order.setOrderId(moneyTask.getMorderList().get(i).getOrderId());
                    order.setOrderTime(moneyTask.getMorderList().get(i).getOrderTime());
                    order.setOrderPrice(moneyTask.getMorderList().get(i).getOrderPrice());
                    orderList.add(order);
                }
                initListView();
                TextView allmoney=findViewById(R.id.tv_all_money);
                money=0;
                for(int i=0;i<listDate.size();i++){
                    money+=(int)listDate.get(i).get("price");
                }
                allmoney.setText("￥"+money);
            }
        });
        lastMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MoneyTask moneyTask=new MoneyTask();
                moneyTask.execute();
                SystemClock.sleep(1000);
                orderList=new ArrayList<>();
                for(int i=0;i<moneyTask.getLmorderList().size();i++){
                    Order order=new Order();
                    order.setOrderId(moneyTask.getLmorderList().get(i).getOrderId());
                    order.setOrderTime(moneyTask.getLmorderList().get(i).getOrderTime());
                    order.setOrderPrice(moneyTask.getLmorderList().get(i).getOrderPrice());
                    orderList.add(order);
                }
                initListView();
                TextView allmoney=findViewById(R.id.tv_all_money);
                money=0;
                for(int i=0;i<listDate.size();i++){
                    money+=(int)listDate.get(i).get("price");
                }
                allmoney.setText("￥"+money);
            }
        });
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MoneyTask moneyTask=new MoneyTask();
                moneyTask.execute();
                SystemClock.sleep(1000);
                orderList=new ArrayList<>();
                for(int i=0;i<moneyTask.getYorderList().size();i++){
                    Order order=new Order();
                    order.setOrderId(moneyTask.getYorderList().get(i).getOrderId());
                    order.setOrderTime(moneyTask.getYorderList().get(i).getOrderTime());
                    order.setOrderPrice(moneyTask.getYorderList().get(i).getOrderPrice());
                    orderList.add(order);
                }
                initListView();
                TextView allmoney=findViewById(R.id.tv_all_money);
                money=0;
                for(int i=0;i<listDate.size();i++){
                    money+=(int)listDate.get(i).get("price");
                }
                allmoney.setText("￥"+money);
            }
        });
        alllist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MoneyTask moneyTask=new MoneyTask();
                moneyTask.execute();
                SystemClock.sleep(1000);
                orderList=new ArrayList<>();
                for(int i=0;i<moneyTask.getAllorderList().size();i++){
                    Order order=new Order();
                    order.setOrderId(moneyTask.getAllorderList().get(i).getOrderId());
                    order.setOrderTime(moneyTask.getAllorderList().get(i).getOrderTime());
                    order.setOrderPrice(moneyTask.getAllorderList().get(i).getOrderPrice());
                    orderList.add(order);
                }
                initListView();
                TextView allmoney=findViewById(R.id.tv_all_money);
                money=0;
                for(int i=0;i<listDate.size();i++){
                    money+=(int)listDate.get(i).get("price");
                }
                allmoney.setText("￥"+money);
            }
        });
    }

    private void initListView() {
        listDate=getDataList();
        adapter=new MoneyAdapter(this,R.layout.moneylist_item,listDate);
        listView.setAdapter(adapter);
    }

    private class MoneyAdapter extends BaseAdapter{
        private MoneyActivity context;
        private int itemLayoutId;
        public List<Map<String, Object>> data;

        public MoneyAdapter(MoneyActivity context, int itemLayoutId, List<Map<String, Object>> data) {
            this.context = context;
            this.itemLayoutId = itemLayoutId;
            this.data = data;
        }

        @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View viewNew=inflater.inflate(itemLayoutId,null);
        TextView time=viewNew.findViewById(R.id.tv_time);
        TextView orderId=viewNew.findViewById(R.id.tv_orderId);
        TextView orderPrice=viewNew.findViewById(R.id.tv_money);
        Map<String,Object>map=data.get(position);
        time.setText((String)map.get("time"));
        orderId.setText((Integer) map.get("orderId")+" ");
        orderPrice.setText("￥"+(Integer)map.get("price"));
        return viewNew;
    }
}
    public List<Map<String,Object>> getDataList() {
        List<Map<String,Object>> list =new ArrayList<>();
        for(int i=0;i<orderList.size();i++){
            Map<String,Object>map1=new HashMap<>();
            map1.put("time",orderList.get(i).getOrderTime());
            map1.put("orderId",orderList.get(i).getOrderId());
            map1.put("price",orderList.get(i).getOrderPrice());
            list.add(map1);
        }
//        Map<String,Object>map1=new HashMap<>();
//        map1.put("time","2018.12.1");
//        map1.put("orderId",1);
//        map1.put("price",200);
//        Map<String,Object>map2=new HashMap<>();
//        map2.put("time","2018.11.1");
//        map2.put("orderId",2);
//        map2.put("price",200);
//        Map<String,Object>map3=new HashMap<>();
//        map3.put("time","2017.11.1");
//        map3.put("orderId",3);
//        map3.put("price",200);
//        list.add(map1);
//        list.add(map2);
//        list.add(map3);
        return list;
    }
}
