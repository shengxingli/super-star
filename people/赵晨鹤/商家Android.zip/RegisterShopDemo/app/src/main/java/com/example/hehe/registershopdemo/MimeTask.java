package com.example.hehe.registershopdemo;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MimeTask extends AsyncTask {
    private int shopImage;
    private int userId = 1;
    private String shopName;
    private int deliveryCount;
    private int paymentCount;
    private int appraiseCount;
    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            URL url = new URL("http://10.7.88.215:8080/project1/RegisterShopServlet?remark=mimeImage&userId="+userId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType","UTF-8");
            InputStream in = connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String message = reader.readLine();
            Log.e("test",message);
            JSONObject object = new JSONObject(message);
            setShopImage(object.getInt("shopImage"));
            setShopName(object.getString("shopName"));
            setDeliveryCount(object.getInt("deliveryCount"));
            setAppraiseCount(object.getInt("appraiseCount"));
            setPaymentCount(object.getInt("paymentCount"));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getDeliveryCount() {
        return deliveryCount;
    }

    public void setDeliveryCount(int deliveryCount) {
        this.deliveryCount = deliveryCount;
    }

    public int getPaymentCount() {
        return paymentCount;
    }

    public void setPaymentCount(int paymentCount) {
        this.paymentCount = paymentCount;
    }

    public int getAppraiseCount() {
        return appraiseCount;
    }

    public void setAppraiseCount(int appraiseCount) {
        this.appraiseCount = appraiseCount;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public MimeTask() {
    }

    public int getShopImage() {
        return shopImage;
    }

    public int getUserId() {
        return userId;
    }

    public void setShopImage(int shopImage) {
        this.shopImage = shopImage;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
