package com.example.hehe.registershopdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class ReviseOrderActivity extends AppCompatActivity {

    private TextView tvUserName;
    private TextView tvProductName;
    private ImageView ivProductImage;
    private TextView tvMessage;

    private EditText etUserTel;
    private EditText etUserAddress;
    private EditText etProductCount;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registershop);
        etUserTel = findViewById(R.id.et_user_tel);
        etProductCount = findViewById(R.id.et_product_count);
        etUserAddress = findViewById(R.id.et_user_address);
        tvUserName = findViewById(R.id.tv_user_name);
        tvMessage = findViewById(R.id.tv_message);
        tvProductName = findViewById(R.id.tv_product_count);
        ivProductImage = findViewById(R.id.iv_product_image);
        button = findViewById(R.id.btn_fabu);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userTel = etUserTel.getText().toString();
                String userAddress = etUserAddress.getText().toString();
                int productCount = Integer.parseInt(etProductCount.getText().toString());
                Intent intent = new Intent();
                String  userName = intent.getStringExtra("userName");
                int orderDetailId = Integer.parseInt(intent.getStringExtra("orderDetailId"));
                String productName = intent.getStringExtra("productName");
                int productImage = Integer.parseInt(intent.getStringExtra("productImage"));
                String message = intent.getStringExtra("message");
                tvUserName.setText(userName);
                tvProductName.setText(productName);
                ivProductImage.setImageResource(productImage);
                tvMessage.setText(message);
                ReviseOrderTask orderTask = new ReviseOrderTask();
                orderTask.setUserTel(userTel);
                orderTask.setUserAddress(userAddress);
                orderTask.setProductCount(productCount);
                orderTask.setOrderDetailId(orderDetailId);
                orderTask.setUserName(userName);
                orderTask.execute();
            }
        });
    }
}

