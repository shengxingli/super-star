package com.example.hehe.registershopdemo;

public class Order {
    private int orderId;
    private int userId;
    private String orderState;
    private String orderTime;
    private double orderPrice;
    private int shopId;

    public Order() {
    }

    public Order(int orderId, int userId, String orderState, String orderTime, double orderPrice, int shopId) {
        this.orderId = orderId;
        this.userId = userId;
        this.orderState = orderState;
        this.orderTime = orderTime;
        this.orderPrice = orderPrice;
        this.shopId = shopId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getOrderState() {
        return orderState;
    }

    public void setOrderState(String orderState) {
        this.orderState = orderState;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public double getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", userId=" + userId +
                ", orderState='" + orderState + '\'' +
                ", orderTime='" + orderTime + '\'' +
                ", orderPrice=" + orderPrice +
                ", shopId=" + shopId +
                '}';
    }
}
