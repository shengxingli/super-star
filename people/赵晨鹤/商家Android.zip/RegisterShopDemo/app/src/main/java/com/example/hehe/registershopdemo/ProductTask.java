package com.example.hehe.registershopdemo;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ProductTask extends AsyncTask {
    private List<Products> productList;
    private int allNum=0;
    private int allSaleNum=0;
    @Override
    protected Object doInBackground(Object[] objects) {
        URL url = null;
        try {
            url = new URL("http://10.7.88.213:8080/shop/ProductServlet?shopId=1");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //设置请求参数
            connection.setRequestProperty("contentType", "utf-8");
            InputStream is = connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(is);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);//字符流
            String res = bufferedReader.readLine();
            JSONArray array = new JSONArray(res);
            Log.e("test","aa");
            productList=new ArrayList<Products>();
            for(int i=0;i<array.length();i++){
                JSONObject obj=array.getJSONObject(i);
                Products product=new Products();
                int productId=obj.getInt("productId");
                int shopId=obj.getInt("shopId");
                int image=obj.getInt("image");
                String productName=obj.getString("productName");
                String productType=obj.getString("productType");
                int productNum=obj.getInt("num");
                int saleNum=obj.getInt("saleNum");
                String productDescribe=obj.getString("productDescribe");
                String specification=obj.getString("specification");
                product.setProductId(productId);
                product.setShopId(shopId);
                product.setProductImage(image);
                product.setProductName(productName);
                product.setProductType(productType);
                product.setProductNum(productNum);
                product.setProductSaleNum(saleNum);
                product.setProductDescription(productDescribe);
                product.setSpecification(specification);
                productList.add(product);
                allNum+=productNum;
                allSaleNum+=saleNum;
            }
            Log.e("test",allNum+"aa");
            setAllNum(60);
            setAllSaleNum(40);
            setProductList(productList);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Products> getProductList() {
        return productList;
    }

    public void setProductList(List<Products> productList) {
        this.productList = productList;
    }

    public int getAllNum() {
        return allNum;
    }

    public void setAllNum(int allNum) {
        this.allNum = allNum;
    }

    public int getAllSaleNum() {
        return allSaleNum;
    }

    public void setAllSaleNum(int allSaleNum) {
        this.allSaleNum = allSaleNum;
    }
}
