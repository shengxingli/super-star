package com.example.hehe.registershopdemo;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ShopTask1 extends AsyncTask {
    private int shopId;
    private Shop shop;
    private int userId;
    @Override
    protected Object doInBackground(Object[] objects) {
        try{
            URL url = new URL("http://10.7.88.215:8080/project1/RegisterShopServlet?remark=register&userId="+userId+"shopName="+shop.getShopName()+"" +
                    "shopImage="+shop.getShopImage()+"shopIdentityImage="+shop.getShopIdentityImage()+"shopAddress="+shop.getShopAddress()+"shopDescription="+shop.getShopDescription());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType","UTF-8");
            InputStream in = connection.getInputStream();
            Log.e("test","haqdjqod454");
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            Log.e("test","haqdjqod234");
            BufferedReader reader = new BufferedReader(inputStreamReader);
            Log.e("test","haqdjqod2436");
            String message = reader.readLine();
            JSONObject object = new JSONObject(message);
            shopId = object.getInt("shopId");
    } catch (MalformedURLException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    } catch (JSONException e) {
        e.printStackTrace();
    }
        return null;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
