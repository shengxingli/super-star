package com.example.hehe.registershopdemo;

public class Products {
    private int productId;
    private int shopId;
    private String productName;
    private int productImage;
    private String productType;
    private int productNum;
    private int specificationId;
    private String productDescription;
    private int productSaleNum;
    private String specification;
    public Products() {
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public Products(int productId, int shopId, String productName, int productImage, String productType, int productNum, int specificationId, String productDescription, int productSaleNum) {
        this.productId = productId;
        this.shopId = shopId;
        this.productName = productName;
        this.productImage = productImage;
        this.productType = productType;
        this.productNum = productNum;
        this.specificationId = specificationId;
        this.productDescription = productDescription;
        this.productSaleNum = productSaleNum;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductImage() {
        return productImage;
    }

    public void setProductImage(int productImage) {
        this.productImage = productImage;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int getProductNum() {
        return productNum;
    }

    public void setProductNum(int productNum) {
        this.productNum = productNum;
    }

    public int getSpecificationId() {
        return specificationId;
    }

    public void setSpecificationId(int specificationId) {
        this.specificationId = specificationId;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public int getProductSaleNum() {
        return productSaleNum;
    }

    public void setProductSaleNum(int productSaleNum) {
        this.productSaleNum = productSaleNum;
    }

    @Override
    public String toString() {
        return "Products{" +
                "productId=" + productId +
                ", shopId=" + shopId +
                ", productName='" + productName + '\'' +
                ", productImage=" + productImage +
                ", productType='" + productType + '\'' +
                ", productNum=" + productNum +
                ", specificationId=" + specificationId +
                ", productDescription='" + productDescription + '\'' +
                ", productSaleNum=" + productSaleNum +
                '}';
    }
}
