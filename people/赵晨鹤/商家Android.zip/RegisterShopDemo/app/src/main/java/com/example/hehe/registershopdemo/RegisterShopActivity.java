package com.example.hehe.registershopdemo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;

public class RegisterShopActivity extends AppCompatActivity {
    private CircleImageView icon;//shopImage
    private ImageView icon1;//shopIdentityImage
    private Button btn_photo;
    private Button btn_select;
    private Button btn_cancel;
    private PopupWindow popupWindow;
    private Listener listener;//icon
    private Listener1 listener1;//icon1
    private File cameraSavePath;//拍照照片路径
    private Uri uri;//照片资源
    //动态权限
    private String[] permissions={Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};

    @Override
    protected void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registershop);
        //点击返回按钮返回
        final ImageView imageReturn = findViewById(R.id.image_return7);
        imageReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(RegisterShopActivity.this, RegisterShopActivity.class);//例子
                startActivity(intent);
            }
        });
        //点击图片可以上传图片
        icon = findViewById(R.id.shop_image);
        icon1 = findViewById(R.id.shop_identity_image);
        listener = new Listener();
        icon.setOnClickListener(listener);
        listener1 = new Listener1();
        icon1.setOnClickListener(listener1);
        cameraSavePath = new File(Environment.getExternalStorageDirectory().getPath()
                + "/" + System.currentTimeMillis() + ".jpg");

        //点击立即开通注册
        Button btnRegister = findViewById(R.id.btn_register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView sShopImage = findViewById(R.id.shop_image);
                EditText sShopName = findViewById(R.id.shop_name);
                EditText sShopDescription = findViewById(R.id.shop_description);
                EditText sShopAddress = findViewById(R.id.shop_address);
                ImageView sshopIdentityImage = findViewById(R.id.shop_identity_image);
                String shopName = sShopName.getText().toString();
                int shopImage = sShopImage.getId();
                int shopIdentityImage = sshopIdentityImage.getId();
                String shopDescription = sShopDescription.getText().toString();
                String shopAddress = sShopAddress.getText().toString();
                Intent intent = new Intent();
                // int userId = Integer.parseInt(intent.getStringExtra("userId"));
                int userId = 1;
                ShopTask1 shopTask = new ShopTask1();
                Shop shop = new Shop();
                shop.setShopImage(shopImage);
                shop.setShopAddress(shopAddress);
                shop.setShopDescription(shopDescription);
                shop.setShopName(shopName);
                shop.setShopIdentityImage(shopIdentityImage);
                shopTask.setUserId(userId);
                shopTask.setShop(shop);
                shopTask.execute();
                int shopId = shopTask.getShopId();
                if(shopId == 0){
                    Log.e("test","注册待审核中");
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Intent intent1 = new Intent();
                    intent1.setClass(RegisterShopActivity.this,RegisterShopActivity.class);//例子
                    intent1.putExtra("userId",userId);
                    startActivity(intent1);
                }else{
                    Log.e("test","注册成功");
                    Intent intent1 = new Intent();
                    intent1.setClass(RegisterShopActivity.this,MimeActivity.class);
                    intent1.putExtra("userId",userId);
                    startActivity(intent1);
                }
            }
        });
    }
    private class Listener1 implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.shop_identity_image:{
                    showPopupWindow1();
                }
                break;
                case R.id.btn_photo:
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    uri= FileProvider.getUriForFile(RegisterShopActivity.this,"com.example.hehe.registershopdemo.fileprovider",cameraSavePath);
                    intent.addFlags( Intent.FLAG_GRANT_READ_URI_PERMISSION );
                    intent.putExtra( MediaStore.EXTRA_OUTPUT,uri );
                    RegisterShopActivity.this.startActivityForResult(intent, 4);
                }
                break;
                case R.id.btn_select:
                {
                    Intent intent=new Intent( Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI );
                    startActivityForResult( intent,3 );
                }
                break;
                case R.id.btn_cancel:
                {
                    popupWindow.dismiss();
                }
                break;
            }
        }
    }
    //自定义监听器类
    private class Listener implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.shop_image:{
                    showPopupWindow();
                }
                break;
                case R.id.btn_photo:
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    uri= FileProvider.getUriForFile(RegisterShopActivity.this,"com.example.hehe.registershopdemo.fileprovider",cameraSavePath);
                    intent.addFlags( Intent.FLAG_GRANT_READ_URI_PERMISSION );
                    intent.putExtra( MediaStore.EXTRA_OUTPUT,uri );
                    RegisterShopActivity.this.startActivityForResult(intent, 2);
                }
                break;
                case R.id.btn_select:
                {
                    Intent intent=new Intent( Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI );
                    startActivityForResult( intent,1 );
                }
                break;
                case R.id.btn_cancel:
                {
                    popupWindow.dismiss();
                }
                break;
            }
        }
    }

    private void showPopupWindow1() {
        View view=getLayoutInflater().inflate( R.layout.popupwindow,null );

        popupWindow=new PopupWindow( this );
        popupWindow.setContentView( view );
        popupWindow.setWidth( ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight( ViewGroup.LayoutParams.WRAP_CONTENT );

        btn_photo=view.findViewById( R.id.btn_photo );
        btn_select=view.findViewById( R.id.btn_select );
        btn_cancel=view.findViewById( R.id.btn_cancel );

        btn_photo.setOnClickListener( listener1 );
        btn_select.setOnClickListener( listener1 );
        btn_cancel.setOnClickListener( listener1 );
        popupWindow.showAsDropDown(icon1);
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult( requestCode, resultCode, data );
        switch (requestCode)
        {
            case 1:
            {
                if (requestCode==1 && resultCode== Activity.RESULT_OK && data!=null){

                    Uri selectedImage = data.getData();
                    String[] filePathColumns = {MediaStore.Images.Media.DATA};

                    Cursor c = getContentResolver().query(selectedImage, filePathColumns, null, null, null);
                    c.moveToFirst();

                    int columnIndex = c.getColumnIndex(filePathColumns[0]);
                    String imagePath = c.getString(columnIndex);

                    Bitmap bm = BitmapFactory.decodeFile(imagePath);
                    icon.setImageBitmap(bm);
                    c.close();
                    popupWindow.dismiss();
                }

            }
            break;

            case 2:
            {
                getPermission();
                String photoPath=null;
                /*Log.d("拍照返回图片路径:", photoPath);*/
                /*if (requestCode==CAMERA_RESULT_CODE&&requestCode==Activity.RESULT_OK){*/
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    photoPath = String.valueOf(cameraSavePath);
                    //裁剪显示特点部位
                    /*photoClip( data.getData() );*/
                } else {
                    photoPath = uri.getEncodedPath();
                }

                //可能是因为拍下的照片 保存不下来 有路径 没有图 可能是权限问题
                Glide.with(this  ).load( photoPath ).into(icon);
                popupWindow.dismiss();
                /*  }*/

            }
            break;
            case 3:
            {
                if (requestCode==3 && resultCode== Activity.RESULT_OK && data!=null){

                    Uri selectedImage = data.getData();
                    String[] filePathColumns = {MediaStore.Images.Media.DATA};

                    Cursor c = getContentResolver().query(selectedImage, filePathColumns, null, null, null);
                    c.moveToFirst();

                    int columnIndex = c.getColumnIndex(filePathColumns[0]);
                    String imagePath = c.getString(columnIndex);

                    Bitmap bm = BitmapFactory.decodeFile(imagePath);
                    icon1.setImageBitmap(bm);
                    c.close();
                    popupWindow.dismiss();
                }

            }
            break;

            case 4:
            {
                getPermission();
                String photoPath=null;
                /*Log.d("拍照返回图片路径:", photoPath);*/
                /*if (requestCode==CAMERA_RESULT_CODE&&requestCode==Activity.RESULT_OK){*/
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    photoPath = String.valueOf(cameraSavePath);
                    //裁剪显示特点部位
                    /*photoClip( data.getData() );*/
                } else {
                    photoPath = uri.getEncodedPath();
                }

                //可能是因为拍下的照片 保存不下来 有路径 没有图 可能是权限问题
                Glide.with(this  ).load( photoPath ).into(icon1);
                popupWindow.dismiss();
                /*  }*/

            }
            break;
        }

    }
    private void showPopupWindow() {
        View view=getLayoutInflater().inflate( R.layout.popupwindow,null );

        popupWindow=new PopupWindow( this );
        popupWindow.setContentView( view );
        popupWindow.setWidth( ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight( ViewGroup.LayoutParams.WRAP_CONTENT );

        btn_photo=view.findViewById( R.id.btn_photo );
        btn_select=view.findViewById( R.id.btn_select );
        btn_cancel=view.findViewById( R.id.btn_cancel );

        btn_photo.setOnClickListener( listener );
        btn_select.setOnClickListener( listener );
        btn_cancel.setOnClickListener( listener );

        //后期加弹出效果
        //popupWindow.setAnimationStyle(  );
        popupWindow.showAsDropDown(icon,0,750 );
    }
    private void getPermission(){
        if (EasyPermissions.hasPermissions( this,permissions )){
            Toast.makeText( this, "已经申请相关权限", Toast.LENGTH_SHORT ).show();
        }else {
            EasyPermissions.requestPermissions( this,"需要获取您的相册、照相机使用权限",1,permissions );
        }
    }
    //框架权限
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult( requestCode, permissions, grantResults );
        EasyPermissions.onRequestPermissionsResult( requestCode,permissions,grantResults,this );
    }
    //打开权限
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {

        Toast.makeText(this, "相关权限获取成功", Toast.LENGTH_SHORT).show();
    }
    //用户未同意权限
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        Toast.makeText(this, "请同意相关权限，否则功能无法使用", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        popupWindow.dismiss();
    }
}
