package com.example.hehe.registershopdemo;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ReviseShopTask extends AsyncTask{
    private int rShopImage;
    private String rShopName;
    private String rShopAddress;
    private String rShopDescription;

    private int userId;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public ReviseShopTask() {
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            URL url = new URL("http://10.7.88.215:8080/project1/RegisterShopServlet?remark=reviseShop&shopName="+rShopName+
                    "&shopImage="+rShopImage+"&shopAddress="+rShopAddress+"&shopDescription=" +
                    ""+rShopDescription+"&userId="+userId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType","UTF-8");
            InputStream in = connection.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String message = reader.readLine();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ReviseShopTask(int rShopImage, String rShopName, String rShopAddress, String rShopDescription) {
        this.rShopImage = rShopImage;
        this.rShopName = rShopName;
        this.rShopAddress = rShopAddress;
        this.rShopDescription = rShopDescription;
    }

    public int getrShopImage() {
        return rShopImage;
    }

    public void setrShopImage(int rShopImage) {
        this.rShopImage = rShopImage;
    }

    public String getrShopName() {
        return rShopName;
    }

    public void setrShopName(String rShopName) {
        this.rShopName = rShopName;
    }

    public String getrShopAddress() {
        return rShopAddress;
    }

    public void setrShopAddress(String rShopAddress) {
        this.rShopAddress = rShopAddress;
    }

    public String getrShopDescription() {
        return rShopDescription;
    }

    public void setrShopDescription(String rShopDescription) {
        this.rShopDescription = rShopDescription;
    }
}
