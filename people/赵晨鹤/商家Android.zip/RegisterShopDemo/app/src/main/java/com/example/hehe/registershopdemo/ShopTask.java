package com.example.hehe.registershopdemo;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ShopTask extends AsyncTask {
    private int userId;
    private Shop shop;
    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            URL url = new URL("http://10.7.88.215:8080/project1/RegisterShopServlet?remark=seeShop&userId="+userId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType","UTF-8");
            InputStream in = connection.getInputStream();
            Log.e("test","haqdjqod454");
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            Log.e("test","haqdjqod234");
            BufferedReader reader = new BufferedReader(inputStreamReader);
            Log.e("test","haqdjqod2436");
            String message = reader.readLine();
            JSONObject object = new JSONObject(message);
            shop = new Shop();
            shop.setShopName(object.getString("shopName"));
            shop.setShopImage(object.getInt("shopImage"));
            shop.setShopAddress(object.getString("shopAddress"));
            shop.setShopDescription(object.getString("shopDescription"));
            setShop(shop);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

}
