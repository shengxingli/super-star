package com.example.hehe.registershopdemo;

public class Admin {
    private int adminId;
    private int adminImage;
    private String adminName;
    private String adminPassword;
    private String adminEmail;

    public Admin() {
    }

    public Admin(int adminId, int adminImage, String adminName, String adminPassword, String adminEmail) {
        this.adminId = adminId;
        this.adminImage = adminImage;
        this.adminName = adminName;
        this.adminPassword = adminPassword;
        this.adminEmail = adminEmail;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public int getAdminImage() {
        return adminImage;
    }

    public void setAdminImage(int adminImage) {
        this.adminImage = adminImage;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }
}
