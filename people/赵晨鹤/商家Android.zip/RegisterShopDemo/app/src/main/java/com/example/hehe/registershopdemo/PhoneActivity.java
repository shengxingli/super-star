package com.example.hehe.registershopdemo;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneActivity extends Activity{
    Button sendnumber,send;
    EditText phone,pwd,number;
     String temp="";
     String phonenum="";
     TextView timecount;
    TimeCount timeco;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone);
        final Intent intent=getIntent();
        ImageView back=findViewById(R.id.iv_back);
        sendnumber=(Button) findViewById(R.id.sendnumber);
        send=(Button) findViewById(R.id.btn_ok);
        phone=(EditText) findViewById(R.id.phone);
        number=(EditText) findViewById(R.id.number);//激活码
        timecount=(TextView) findViewById(R.id.counttime);
        timeco = new TimeCount(120000, 1000);//时间为120秒
        sendnumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0;i<5;i++){
                    int k=(int)(Math.random()*10);
                    temp+=k;
                }
                phonenum=phone.getText().toString().trim();
                SmsManager smsManager=SmsManager.getDefault();
                if(isPhoneNumberValid(phonenum)){
                    PendingIntent mPI=PendingIntent.getBroadcast(PhoneActivity.this,0,new Intent(),0);
                    smsManager.sendTextMessage(phonenum,null,"您的验证码是："+temp,mPI,null);
                    Toast.makeText(PhoneActivity.this,"验证码发送成功",Toast.LENGTH_LONG).show();
                    timeco.start();
                }else{
                    Toast.makeText(PhoneActivity.this,"手机号格式不正确！",Toast.LENGTH_LONG).show();

                }
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phonenum=phone.getText().toString().trim();
                if(!isPhoneNumberValid(phonenum)){
                    Toast.makeText(PhoneActivity.this,"电话格式不正确",Toast.LENGTH_LONG).show();
                }else if(phonenum.length()==0){
                    Toast.makeText(PhoneActivity.this,
                            "请输入电话号",
                            Toast.LENGTH_LONG).show();
                }else if(number.getText().toString().length()==0){
                    Toast.makeText(PhoneActivity.this,
                            "请输入验证码",
                            Toast.LENGTH_LONG).show();
                }else if(!number.getText().toString().equals(temp)){
                    Toast.makeText(PhoneActivity.this,
                            "验证码不正确",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               finish();
           }
       });

    }
    public static boolean isPhoneNumberValid(String mobiles){
        Matcher m=null;
        if(mobiles.trim().length()>0){
            Pattern p=Pattern.compile("^((13[0-9])|(15[0-3])|(15[7-9])|(18[0,5-9]))\\d{8}$");
            m=p.matcher(mobiles);
        }else{
            return false;
        }
        return m.matches();
    }
    public class TimeCount extends CountDownTimer{
        public TimeCount(long millisInFuture,long countDownInterval){
            super(millisInFuture,countDownInterval);
        }
        @Override
        public void onTick(long millisUntilFinished) {
            timecount.setText(millisUntilFinished /1000+"秒");
        }

        @Override
        public void onFinish() {
            temp="";
            Toast.makeText(PhoneActivity.this,"超时，重新发送验证码!",Toast.LENGTH_LONG).show();
        }
    }
}
