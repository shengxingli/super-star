package com.example.hehe.registershopdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManagerGoodsActivity1 extends Activity{
    private ListView listView;
    private MessageAdapter adapter;
    private List<Map<String,Object>> listDate;
    private Intent intent=new Intent();
    private List<Products> productList=null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_managergoods);
        ProductTask productTask=new ProductTask();
        productTask.execute();
        SystemClock.sleep(1000);
        for(int i=0;i<productTask.getProductList().size();i++){
            Products product=new Products();
            product.setProductName(productTask.getProductList().get(i).getProductName());
            product.setProductImage(productTask.getProductList().get(i).getProductImage());
            product.setSpecification(productTask.getProductList().get(i).getSpecification());
            product.setProductDescription(productTask.getProductList().get(i).getProductDescription());
            product.setProductSaleNum(productTask.getProductList().get(i).getProductSaleNum());
            product.setProductNum(productTask.getProductList().get(i).getProductNum());
            product.setProductType(productTask.getProductList().get(i).getProductType());
            product.setShopId(productTask.getProductList().get(i).getShopId());
            product.setProductId(productTask.getProductList().get(i).getProductId());
            productList.add(product);
        }

        listView=findViewById(R.id.lv_goodslist);
        initListView();

    }
    private void initListView() {
        listDate=getDataList();
        adapter=new MessageAdapter(this,
                R.layout.list_goodsitem,listDate);
        listView.setAdapter(adapter);
    }
    private class MessageAdapter extends BaseAdapter{
        private ManagerGoodsActivity1 context;
        private int itemLayoutId;
        public List<Map<String, Object>> data;
        public MessageAdapter(ManagerGoodsActivity1 context, int itemLayoutId, List<Map<String, Object>> data){
            this.context = context;
            this.itemLayoutId = itemLayoutId;
            this.data = data;
        }
        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater=LayoutInflater.from(context);
            View viewNew=inflater.inflate(itemLayoutId,null);
            TextView tvName=viewNew.findViewById(R.id.tv_goodsname);
            TextView tvprice=viewNew.findViewById(R.id.tv_goodsprice);
            ImageView imageView=viewNew.findViewById(R.id.iv_goodsimage);
            final Map<String,Object>map=data.get(position);
            tvName.setText((String)map.get("name"));
            tvprice.setText((String)map.get("specification"));
            imageView.setImageResource((int)map.get("image"));
            Button cancal=viewNew.findViewById(R.id.btn_delete);
            cancal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int productId=(int)map.get("productId");
                    DeleteProductTask deleteProductTask=new DeleteProductTask();
                    deleteProductTask.setProductId(productId);
                    deleteProductTask.execute();

                }
            });
            return viewNew;
        }
    }
    public List<Map<String,Object>> getDataList() {
        List<Map<String,Object>> list =new ArrayList<>();
        for(int i=0;i<productList.size();i++){
            Map<String,Object>map1=new HashMap<>();
            map1.put("productId",productList.get(i).getProductId());
            map1.put("shopId",productList.get(i).getShopId());
            map1.put("name",productList.get(i).getProductName());
            map1.put("specification",productList.get(i).getSpecification());
            map1.put("image",productList.get(i).getProductImage());
            list.add(map1);
        }
        return list;
    }
}
