package com.example.hehe.registershopdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageActivity1 extends Activity{
    private List<Msg> msgs=null;
    private List<User> users=null;
    private List<MsgDetail> msgDetails=null;
    private ListView listView;
    private MessageAdapter adapter;
    private List<Map<String,Object>> listDate;
    private Intent intent=new Intent();
    private int ACTIVITY1 = 1;
    private int USERNAME = 2;
    private Shop shop;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message1);
        shop=new Shop();
        shop.setShopName("flower");
        MesageTask msgTask=new MesageTask();
        msgTask.execute();
        SystemClock.sleep(1000);
        msgs=new ArrayList<>();
        msgDetails=new ArrayList<>();
        users=new ArrayList<>();
        for(int i=0;i<msgTask.getUsers().size();i++){
            User user=new User();
            user.setUserImage(msgTask.getUsers().get(i).getUserImage());
            user.setUserName(msgTask.getUsers().get(i).getUserName());
            user.setUserId(msgTask.getUsers().get(i).getUserId());
            user.setShopId(msgTask.getUsers().get(i).getShopId());
            users.add(user);
        }
        for(int i=0;i<msgTask.getMsgs().size();i++){
            Msg msg=new Msg();
            msg.setMsgId(msgTask.getMsgs().get(i).getMsgId());
            msg.setUserId(msgTask.getMsgs().get(i).getUserId());
            msg.setShopId(msgTask.getMsgs().get(i).getShopId());
            msgs.add(msg);
        }
        for (int i=0;i<msgTask.getMsgDetails().size();i++){
            MsgDetail msgDetail=new MsgDetail();
            msgDetail.setMsgDetailId(msgTask.getMsgDetails().get(i).getMsgDetailId());
            msgDetail.setMsgId(msgTask.getMsgDetails().get(i).getMsgId());
            msgDetail.setEmsg(msgTask.getMsgDetails().get(i).getEmsg());
            msgDetail.setMsgContent(msgTask.getMsgDetails().get(i).getMsgContent());
            msgDetail.setMsgTime(msgTask.getMsgDetails().get(i).getMsgTime());
            msgDetails.add(msgDetail);
        }
       listView=findViewById(R.id.lv_yujing);
        ImageView back=findViewById(R.id.iv_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initListView();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                intent.putExtra("position",position);
                intent.putExtra("image", listDate.get(position).get("image").toString());
                TextView tvName=view.findViewById(R.id.tv_ms_name);
                String name=tvName.getText().toString();
                intent.putExtra("name",name);
                intent.setClass(MessageActivity1.this, MessageActivity.class);
                startActivityForResult(intent,ACTIVITY1);

            }
        });
    }
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == ACTIVITY1){
            if(resultCode == USERNAME){
                String name = data.getStringExtra("name");
                Log.e("name",name);
                int position=data.getIntExtra("position",0);
                Log.e("position",position+"");
                listDate.get(position).put("text1",name);
                Log.e("list",listDate+"");
                adapter.notifyDataSetChanged();
            }
        }
        super.onActivityResult(requestCode,resultCode, data);
    }
    private void initListView() {
        listDate=getDataList();
        adapter=new MessageAdapter(this,
                R.layout.list_item,listDate);
        listView.setAdapter(adapter);
    }
    private class MessageAdapter extends BaseAdapter{
        private MessageActivity1 context;
        private int itemLayoutId;
        public List<Map<String, Object>> data;
        public MessageAdapter(MessageActivity1 context, int itemLayoutId, List<Map<String, Object>> data){
            this.context = context;
            this.itemLayoutId = itemLayoutId;
            this.data = data;
        }
        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater=LayoutInflater.from(context);
            View viewNew=inflater.inflate(itemLayoutId,null);
            TextView tvName=viewNew.findViewById(R.id.tv_ms_name);
            TextView tvMessage=viewNew.findViewById(R.id.tv_message);
            TextView tvTime=viewNew.findViewById(R.id.tv_ms_time);
            ImageView imageView=viewNew.findViewById(R.id.iv_ms_image);
            Map<String,Object>map=data.get(position);
            tvName.setText((String)map.get("name"));
            tvMessage.setText((String)map.get("message"));
            tvTime.setText((String)map.get("time"));
            imageView.setImageResource((int)map.get("image"));
            return viewNew;
        }
    }
    public List<Map<String,Object>> getDataList() {
        List<Map<String,Object>> list =new ArrayList<>();
        Log.e("user1",users.toString());
            for(int j=0;j<msgs.size();j++){
                if(msgs.get(j).getSender().equals("admin")){
                    Map<String,Object>map1=new HashMap<>();
                    User user=new User();
                    for(int i=0;i<users.size();i++){
                        if(msgs.get(j).getUserId()==users.get(i).getUserId()){
                            int userId=users.get(i).getUserId();
                            user.setUserId(userId);
                            user.setUserName(users.get(i).getUserName());
                            user.setUserImage(users.get(i).getUserImage());
                            map1.put("name",user.getUserName());
                            map1.put("image",user.getUserImage());
                            break;
                        }
                    }
                    for(int k=0;k<msgDetails.size();k++){
                        if(msgDetails.get(k).getMsgId()==msgs.get(j).getMsgId()){
                            String msgTime=msgDetails.get(k).getMsgTime();
                            String msgContent=msgDetails.get(k).getMsgContent();
                            int emsg=msgDetails.get(k).getEmsg();
                            if(emsg==1){
                                map1.put("message",user.getUserName()+":"+msgContent);
                                map1.put("time",msgTime);
                            }
                            if(emsg==0){
                                map1.put("message",shop.getShopName()+":"+msgContent);
                                map1.put("time",msgTime);
                            }
                        }
                    }
                    list.add(map1);
                }
            }
        return list;
    }
}
