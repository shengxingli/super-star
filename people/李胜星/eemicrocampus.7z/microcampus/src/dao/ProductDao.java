package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import bean.ProductBean;
import bean.ShopBean;

public class ProductDao {

	/*
	 * 通过类别查询商品
	 */
	public List<ProductBean> getProductsByProductType(String type) {
		List<ProductBean> list = new ArrayList<ProductBean>();

		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if(type.equals("all")) {
			String sql = "select * from products";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					ProductBean productBean = new ProductBean();
					productBean.setProductId(rs.getInt(1));
					ShopBean shop = new ShopDao().getShopById(rs.getInt(2));
					productBean.setShop(shop);
					productBean.setProductName(rs.getString(3));
					productBean.setProductImage(rs.getInt(4));
					productBean.setProductType(rs.getString(5));
					productBean.setProductNum(rs.getInt(6));
					productBean.setProductDescription(rs.getString(7));
					productBean.setProductSaleNum(rs.getInt(8));
					list.add(productBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return list;
		}else {
			String sql = "select * from products where product_type=?";
			try {
				pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				pstmt.setString(1, type);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					ProductBean productBean = new ProductBean();
					productBean.setProductId(rs.getInt(1));
					ShopBean shop = new ShopDao().getShopById(rs.getInt(2));
					productBean.setShop(shop);
					productBean.setProductName(rs.getString(3));
					productBean.setProductImage(rs.getInt(4));
					productBean.setProductType(rs.getString(5));
					productBean.setProductNum(rs.getInt(6));
					productBean.setProductDescription(rs.getString(7));
					productBean.setProductSaleNum(rs.getInt(8));
					list.add(productBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return list;
		}
	}

	/*
	 * 通过productId获取product
	 */
	public ProductBean getProductById(int productId) {
		ProductBean product = new ProductBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from products where product_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, productId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				product.setProductId(rs.getInt(1));
				product.setShop(new ShopDao().getShopById(rs.getInt(2)));
				product.setProductName(rs.getString(3));
				product.setProductImage(rs.getInt(4));
				product.setProductType(rs.getString(5));
				product.setProductNum(rs.getInt(6));
				product.setProductDescription(rs.getString(7));
				product.setProductSaleNum(rs.getInt(8));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return product;
	}
}
