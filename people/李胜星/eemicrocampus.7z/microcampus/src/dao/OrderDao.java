package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.OrderBean;


public class OrderDao {

	/*
	 * 通过orderId获取Order
	 */
	public OrderBean getOrderById(int orderId) {
		OrderBean order = new OrderBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from order where order_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, orderId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				order.setOrderId(rs.getInt(1));
				order.setUser(new UserDao().getUserById(rs.getInt(2)));
				order.setOrderState(rs.getString(3));
				order.setOrderTime(rs.getDate(4));
				order.setOrderPrice(rs.getDouble(5));
				order.setShop(new ShopDao().getShopById(rs.getInt(6)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return order;
	}
}
