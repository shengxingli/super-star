package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.SpecificationBean;

public class SpecificationDao {
	
	/*
	 * 通过specificationId获取SpecificationBean
	 */
	public SpecificationBean getSecificationById(int specificationId) {
		SpecificationBean specification = new SpecificationBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from specification where specification_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, specificationId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				specification.setSpecificationId(rs.getInt(1));
				specification.setSpecificationContent(rs.getString(2));
				specification.setProductPrice(rs.getDouble(3));
				specification.setProductId(rs.getInt(4));
				specification.setSpecificationCount(rs.getInt(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return specification;
	}
	
	/*
	 * 通过productId获取Specification
	 */
	public List<SpecificationBean> getSpecificationByProductId (int productId){
		List<SpecificationBean> specificationList = new ArrayList<SpecificationBean>();
		SpecificationBean specification = null;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from specification where product_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, productId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				specification = new SpecificationBean();
				specification.setSpecificationId(rs.getInt(1));
				specification.setSpecificationContent(rs.getString(2));
				specification.setProductPrice(rs.getDouble(3));
				specification.setProductId(rs.getInt(4));
				specification.setSpecificationCount(rs.getInt(5));
				specificationList.add(specification);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return specificationList;
	}

}
