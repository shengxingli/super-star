package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.MsgBean;


public class MsgDao {
	
	/*
	 * 通过msgId获取Msg
	 */
	public MsgBean getMsgById(int msgId) {
		MsgBean msg = new MsgBean();
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from msg where msg_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, msgId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				msg.setMsgId(rs.getInt(1));
				msg.setUser(new UserDao().getUserById(rs.getInt(2)));
				msg.setShop(new ShopDao().getShopById(rs.getInt(3)));
				msg.setSender(rs.getInt(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}
	
	/*
	 * 通过userId获取MsgList
	 */
	public List<MsgBean> getMsgListByUserId(int userId) {
		List<MsgBean> msgList = new ArrayList<>();
		MsgBean msg = null;
		Connection conn = Database.getConnection();
		PreparedStatement pstmt = null;
		String sql = "select * from msg where user_id=?";
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				msg = new MsgBean();
				msg.setMsgId(rs.getInt(1));
				msg.setUser(new UserDao().getUserById(rs.getInt(2)));
				msg.setShop(new ShopDao().getShopById(rs.getInt(3)));
				msg.setSender(rs.getInt(4));
				msg.setMsgLastContent(rs.getString(5));
				msg.setMsgLastTime(rs.getDate(6));
				msgList.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msgList;
	}
}
