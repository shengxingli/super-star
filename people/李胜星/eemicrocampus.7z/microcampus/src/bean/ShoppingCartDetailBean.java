package bean;

/*
 * 购物车详情表
 */

public class ShoppingCartDetailBean {

	private int shoppingCartDetailId;
	private ProductBean product;
	private int productCount;
	private int userId;
	private SpecificationBean specification;

	public SpecificationBean getSpecification() {
		return specification;
	}

	public void setSpecification(SpecificationBean specification) {
		this.specification = specification;
	}

	public int getShoppingCartDetailId() {
		return shoppingCartDetailId;
	}

	public void setShoppingCartDetailId(int shoppingCartDetailId) {
		this.shoppingCartDetailId = shoppingCartDetailId;
	}

	public ProductBean getProduct() {
		return product;
	}

	public void setProduct(ProductBean product) {
		this.product = product;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return shoppingCartDetailId + "," + userId + "," + product.toString() + "," + productCount
				+ "," + specification.toString();
	}

}
