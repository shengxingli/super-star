package bean;

/*
 *用户表
 */

public class UserBean {

	private int userId;
	private String userName;
	private String userTel;
	private String userPassword;
	private String userAddress;
	private String userEmail;
	private ShopBean shop;
	private int userELogin;
	private int userImage;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserTel() {
		return userTel;
	}
	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public int getUserELogin() {
		return userELogin;
	}
	public void setUserELogin(int userELogin) {
		this.userELogin = userELogin;
	}
	public ShopBean getShop() {
		return shop;
	}
	public void setShop(ShopBean shop) {
		this.shop = shop;
	}
	public int getUserImage() {
		return userImage;
	}
	public void setUserImage(int userImage) {
		this.userImage = userImage;
	}
	@Override
	public String toString() {
		if(shop == null) {
			return userId + "," + userTel + "," + userImage + "," + userName 
					 + "," + userPassword + "," + userAddress + "," + userEmail
					 + "," + null + "," + 0;
		}else {
			return userId + "," + userTel + "," + userImage + "," + userName 
					 + "," + userPassword + "," + userAddress + "," + userEmail
					 + "," + shop.toString() + "," + 0;
		}
	}
	
}
