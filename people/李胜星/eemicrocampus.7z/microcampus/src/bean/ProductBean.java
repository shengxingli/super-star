package bean;

/*
 *商品表 
 */

public class ProductBean {

	private int productId;//商品的id
	private ShopBean shop;//商品所属的商店
	private String productName;//商品的名字
	private String productType;//商品的种类
	private int productImage;//商品的图片
	private int productNum;//商品的库存
	private int productSaleNum;//商品的销量
	private String productDescription;//商品的描述
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public ShopBean getShop() {
		return shop;
	}
	public void setShop(ShopBean shop) {
		this.shop = shop;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public int getProductImage() {
		return productImage;
	}
	public void setProductImage(int productImage) {
		this.productImage = productImage;
	}
	public int getProductNum() {
		return productNum;
	}
	public void setProductNum(int productNum) {
		this.productNum = productNum;
	}
	public int getProductSaleNum() {
		return productSaleNum;
	}
	public void setProductSaleNum(int productSaleNum) {
		this.productSaleNum = productSaleNum;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	
	@Override
	public String toString() {
		return productId + "," + shop.toString() + "," + productName + "," + productImage 
				+ "," + productType + "," + productNum + "," + productDescription
				+ "," + productSaleNum ;
	}	
	
}
