package bean;

import java.util.Date;

/*
 *信息详情表
 */

public class MsgDetailBean {

	private int msgDetailId;
	private MsgBean msg;
	private String msgContent;
	private Date msgTime;
	private int Sender;//发送人，用户1，商家2，管理员3
	
	public int getMsgDetailId() {
		return msgDetailId;
	}
	public void setMsgDetailId(int msgDetailId) {
		this.msgDetailId = msgDetailId;
	}
	public MsgBean getMsg() {
		return msg;
	}
	public void setMsg(MsgBean msg) {
		this.msg = msg;
	}
	public String getMsgContent() {
		return msgContent;
	}
	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}
	public Date getMsgTime() {
		return msgTime;
	}
	public void setMsgTime(Date msgTime) {
		this.msgTime = msgTime;
	}
	public int getSender() {
		return Sender;
	}
	public void setSender(int sender) {
		Sender = sender;
	}
	
	@Override
	public String toString() {
		//消息不可能为空
		return msgDetailId + "," + msg.toString() + "," + msgContent
				+ "," + msgTime + "," + Sender;
	}
	
}
