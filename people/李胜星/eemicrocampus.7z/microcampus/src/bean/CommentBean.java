package bean;

import java.util.Date;

/*
 *评论表
 */

public class CommentBean {

	private int commentId;
	private EvaluationBean evaluation;
	private String commentContent;
	private Date commentTime;
	
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public EvaluationBean getEvaluation() {
		return evaluation;
	}
	public void setEvaluation(EvaluationBean evaluation) {
		this.evaluation = evaluation;
	}
	public String getCommentContent() {
		return commentContent;
	}
	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}
	public Date getCommentTime() {
		return commentTime;
	}
	public void setCommentTime(Date commentTime) {
		this.commentTime = commentTime;
	}
	
	@Override
	public String toString() {
		if(evaluation == null) {
			return commentId + "," + null + ","+ commentContent + "," + commentTime;
		}else {
			return commentId + "," + evaluation.toString() + ","
					+ commentContent + "," + commentTime;
		}
	}
	
}
