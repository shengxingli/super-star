package cn.edu.hebtu.software.microcampus;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductDetailActivity extends AppCompatActivity {

    private View view[];
    private ListView listView;
    private ListView listView1;
    private List<Map<String, Object>> datalist;
    private List<Map<String, Object>> datalist1;
    private List<Map<String, Object>> specificationList;
    private TextView productNum;
    private Button addProduct;
    private Button deleteProduct;
    private Button num;
    private Product product;
    private Intent intent;
    private Map<String, Object> map;
    private int specificationId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        intent = getIntent();
        String msg = intent.getStringExtra("product");
        Log.e("msg", msg);
        product = new ReadProducts().readProduct(msg);
        TextView productPrice = findViewById(R.id.product_price);
        TextView productName = findViewById(R.id.product_name);
        TextView salesNum = findViewById(R.id.sales_num);
        TextView shopAddress = findViewById(R.id.shop_address);
        ImageView shopImage = findViewById(R.id.shop_image);
        ImageView productImage = findViewById(R.id.product_image);
        TextView shoName = findViewById(R.id.shop_name);
        shoName.setText(product.getShop().getShopName());
        productImage.setImageResource(product.getProductImage());
        shopImage.setImageResource(product.getShop().getShopImage());
        shopAddress.setText(product.getShop().getShopAddress());
        salesNum.setText(product.getProductSaleNum() + "");
        productName.setText(product.getProductName());
        productPrice.setText("￥" + intent.getStringExtra("price"));

        Button btnAddShoppingCart = findViewById(R.id.add_shopping_cart);
        btnAddShoppingCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupWindowMenu(v);
            }
        });
        LinearLayout llChooseCategory = findViewById(R.id.ll_choose_category);
        llChooseCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupWindowMenu(v);
            }
        });
        LinearLayout llViewParameter = findViewById(R.id.ll_view_parameter);
        llViewParameter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showParameterPopupWindowMenu(v);
            }
        });
        Button buyNow = findViewById(R.id.buy_now);
        buyNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupWindowMenu(v);
            }
        });

        initListView();

    }

    private void initListView() {
        // 1. 获取数据
        initData();
        // 2. 创建Adapter
        ListViewAdapter adapter = new ListViewAdapter(ProductDetailActivity.this,
                R.layout.layout_product_item, datalist, datalist1);
        // 3. 给ListView设置Adapter
        listView = findViewById(R.id.product_list);
        listView.setAdapter(adapter);
        setListViewHeightBasedOnChildren(listView);

    }

    //创建Adapter
    private class ListViewAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;
        private List<Map<String, Object>> datalist1;

        public ListViewAdapter(Context context,
                               int itemLayoutID,
                               List<Map<String, Object>> datalist,
                               List<Map<String, Object>> datalist1) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
            this.datalist1 = datalist1;
        }

        @Override
        public int getCount() {
            return datalist.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            LinearLayout llProduct1 = convertView.findViewById(R.id.ll_product1);
            llProduct1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(ProductDetailActivity.this, ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            LinearLayout llProduct2 = convertView.findViewById(R.id.ll_product2);
            llProduct2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(ProductDetailActivity.this, ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            ImageView imageView = convertView.findViewById(R.id.iv_product_image1);
            TextView textView1 = convertView.findViewById(R.id.tv_product_name1);
            TextView textView2 = convertView.findViewById(R.id.product_price1);
            ImageView imageView1 = convertView.findViewById(R.id.iv_product_image2);
            TextView tvProductName2 = convertView.findViewById(R.id.tv_product_name2);
            TextView tvProductPrice = convertView.findViewById(R.id.product_price2);
            Map<String, Object> map = datalist.get(position);
            imageView.setImageResource((int) map.get("image"));
            textView1.setText((String) map.get("title"));
            textView2.setText((String) map.get("text"));
            Map<String, Object> map1 = datalist1.get(position);
            imageView1.setImageResource((int) map1.get("image"));
            tvProductName2.setText((String) map1.get("title"));
            tvProductPrice.setText((String) map1.get("text"));
            return convertView;
        }
    }

    //创建数据
    private void initData() {
        int icon[] = {R.drawable.avatar, R.drawable.avatar2, R.drawable.avatar, R.drawable.avatar2, R.drawable.avatar,
                R.drawable.avatar2, R.drawable.avatar, R.drawable.avatar2, R.drawable.avatar, R.drawable.avatar2};
        String title[] = {"ACM算法日常", "高校教师网络培训中心", "程序员那些事", "InfoQ", "阿里技术",
                "码农有道", "人人都是产品经理", "程序员精选", "河北师范大学软件学院", "河北师大共青团"};
        String price[] = {"￥138", "￥138", "￥138", "￥138", "￥138", "￥138", "￥138", "￥138",
                "￥138", "￥138"};
        datalist = new ArrayList<>();
        datalist1 = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            Map<String, Object> map1 = new HashMap<String, Object>();
            if (i % 2 == 0) {
                map1.put("image", icon[i]);
                map1.put("title", title[i]);
                map1.put("text", price[i]);
                datalist1.add(map1);
            } else {
                map.put("image", icon[i]);
                map.put("title", title[i]);
                map.put("text", price[i]);
                datalist.add(map);
            }
        }

    }

    public void setListViewHeightBasedOnChildren(ListView listView) {
        // 获取ListView对应的Adapter
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            Log.e("msg", listAdapter.getCount() + "");
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }

    //弹出PopupWindow
    private void showPopupWindowMenu(View v) {
        //1.根据资源文件，使用布局填充器创建显示的View
        final View popupWindowView = getLayoutInflater()
                .inflate(R.layout.layout_add_shopping_cart_menu, null);
        //2.创建PopupWindow对象
        initSpecificationListView(popupWindowView);
        ImageView productImageAdd = popupWindowView.findViewById(R.id.product_image_add);
        TextView productPriceAdd = popupWindowView.findViewById(R.id.product_price_add);
        productNum = popupWindowView.findViewById(R.id.product_num);

        productNum.setText("库存" + product.getProductNum() + "件");
        productPriceAdd.setText("￥" + intent.getStringExtra("price"));
        productImageAdd.setImageResource(product.getProductImage());
        final PopupWindow popupWindow = new PopupWindow(popupWindowView,
                dip2px(getApplicationContext(), 410),
                dip2px(getApplicationContext(), 500),
                true);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        popupWindow.showAtLocation(v, Gravity.NO_GRAVITY,
                location[0], popupWindow.getHeight());
        //3.绑定监听器

        Button btnAddCart = popupWindowView.findViewById(R.id.btn_add_cart);
        btnAddCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add shoppingCartDetail
                Button btn = popupWindowView.findViewById(R.id.btn_num);
                AddShoppingCartDetailTask addShoppingCartDetailTask
                        = new AddShoppingCartDetailTask();
                addShoppingCartDetailTask.setProductId(product.getProductId());
                addShoppingCartDetailTask.setProductCount(btn.getText().toString());
                addShoppingCartDetailTask.setSpecificationId(specificationId);
                addShoppingCartDetailTask.execute();
                finish();
            }
        });
        addProduct = popupWindowView.findViewById(R.id.btn_add_product);
        deleteProduct = popupWindowView.findViewById(R.id.btn_delete_product);
        num = popupWindowView.findViewById(R.id.btn_num);
        addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = Integer.parseInt(num.getText().toString()) + 1;
                num.setText(i + "");
            }
        });
        deleteProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Integer.parseInt(num.getText().toString()) > 1) {
                    num.setText(Integer.parseInt(num.getText().toString()) - 1 + "");
                }
            }
        });

        popupWindow.showAsDropDown(v, (v.getWidth() - popupWindow.getWidth()) / 2, 0);
    }

    private void initSpecificationListView(View view) {
        // 1. 获取数据
        initSpecificationData();
        // 2. 创建Adapter
        SpecificationAdapter adapter = new SpecificationAdapter(ProductDetailActivity.this,
                R.layout.layout_specification_item, specificationList);
        // 3. 给ListView设置Adapter
        listView1 = view.findViewById(R.id.lv_specification);
        listView1.setDividerHeight(0);
        listView1.setDivider(null);
        listView1.setAdapter(adapter);
        setListViewHeightBasedOnChildren(listView1);
    }

    //创建Adapter
    private class SpecificationAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;

        public SpecificationAdapter(Context context,
                                    int itemLayoutID,
                                    List<Map<String, Object>> datalist) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
            view = new View[getCount()];
        }

        @Override
        public int getCount() {
            return datalist.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            final View v = convertView;
            map = datalist.get(position);
            final Button btnSpecification = convertView.findViewById(R.id.specification_item);
            btnSpecification.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (btnSpecification.getCurrentTextColor() == 0xffff4500) {
                        btnSpecification.setBackgroundColor(0xffd3D3D3);
                        btnSpecification.setTextColor(0xff050505);
                    } else {
                        view[position] = v;
                        btnSpecification.setTextColor(0xffff4500);
                        btnSpecification.setBackgroundColor(0xffffffff);
                        for (int i = 0; i < view.length; ++i) {
                            if (i != position) {
                                if (view[i] != null) {
                                    Button btn = view[i].findViewById(R.id.specification_item);
                                    btn.setBackgroundColor(0xffd3D3D3);
                                    btn.setTextColor(0xff050505);
                                }
                            }
                        }
                        map = datalist.get(position);
                        Log.e("msg","库存" + map.get("productNum") + "件");
                        productNum.setText("库存" + map.get("productNum") + "件");
                        specificationId = (int)map.get("specificationId");
                    }
                }
            });

            btnSpecification.setText((String) map.get("specification"));
            return convertView;
        }

    }

    //创建数据
    private void initSpecificationData() {
        String msg = intent.getStringExtra("specification");
        List<Specification> sList = new ReadSpecification().read(msg);
        specificationList = new ArrayList<>();
        for (Specification specification : sList) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("specification", specification.getSpecificationContent());
            Log.e("msg","库存" + specification.getSpecificationCount() + "件");
            map.put("productNum",specification.getSpecificationCount());
            map.put("specificationId",specification.getSpecificationId());
            specificationList.add(map);
        }

    }


    private void showParameterPopupWindowMenu(View v) {
        //1.根据资源文件，使用布局填充器创建显示的View
        View popupWindowView = getLayoutInflater()
                .inflate(R.layout.layout_parameter, null);
        //2.创建PopupWindow对象
        final PopupWindow popupWindow = new PopupWindow(popupWindowView,
                dip2px(getApplicationContext(), 410),
                dip2px(getApplicationContext(), 500),
                true);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        popupWindow.showAtLocation(v, Gravity.NO_GRAVITY,
                location[0], popupWindow.getHeight());
        Button btnFinish = popupWindowView.findViewById(R.id.btn_finish);
        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        popupWindow.showAsDropDown(v, (v.getWidth() - popupWindow.getWidth()) / 2, 0);
    }

    //dp物理像素转换成真实像素
    public static int dip2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
