package cn.edu.hebtu.software.microcampus;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CodeLoginActivity extends AppCompatActivity {
    private int recLen;
    private EditText etTel;
    private EditText etInputCode;
    private Button btnGetCode;
    private Button btnCodeLogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_login);

        getCode();
        codeLogin();

    }

    private void codeLogin() {
        etTel = findViewById(R.id.et_tel_login);
        btnCodeLogin = findViewById(R.id.btn_code_login);
        etInputCode = findViewById(R.id.et_input_code_login);
        btnCodeLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetCodeTask getCodeTask = new GetCodeTask();
                String code = getCodeTask.getCode();
                String inoutCode = etInputCode.getText().toString();
                if (code.equals(inoutCode)) {
                    //登陆一下，自动登录保持选择
                    CodeLoginTask codeLoginTask = new CodeLoginTask();
                    codeLoginTask.setTel(etTel.getText().toString());
                    codeLoginTask.execute();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    //跳转到首页
                } else {
                    Toast.makeText(CodeLoginActivity.this,
                            "验证码错误", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getCode() {
        btnGetCode = findViewById(R.id.btn_get_code_login);
        btnGetCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btnGetCode.getText().toString().equals("重新发送")
                        || btnGetCode.getText().toString().equals("获取验证码")) {
                    etTel = findViewById(R.id.et_tel_login);
                    String mobile = etTel.getText().toString();
                    if (mobile.equals("")) {
                        Toast.makeText(CodeLoginActivity.this,
                                "手机号不能为空", Toast.LENGTH_SHORT).show();
                    } else {
                        IsTelAccountTask isTelAccountTask = new IsTelAccountTask();
                        isTelAccountTask.setTel(mobile);
                        isTelAccountTask.execute();
                        if(isTelAccountTask.getMsg().equals("true")){
                            GetCodeTask getCodeTask = new GetCodeTask();
                            getCodeTask.setTel(mobile);
                            getCodeTask.execute();
                            recLen = 50;
                            handler.postDelayed(runnable, 1000);
                        }else{
                            Toast.makeText(CodeLoginActivity.this,
                                    "该手机号没有注册过", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }

    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            recLen--;
            if (recLen == 0) {
                btnGetCode.setText("重新发送");
                return;
            }
            btnGetCode.setText("重新发送:" + recLen);
            handler.postDelayed(this, 1000);
        }
    };
}
