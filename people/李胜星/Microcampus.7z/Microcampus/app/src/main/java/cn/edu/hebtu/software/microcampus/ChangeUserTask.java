package cn.edu.hebtu.software.microcampus;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ChangeUserTask extends AsyncTask {

    private String msg;
    private int avator;
    private String userName;
    private String userEmail;
    private int userId;

    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            URL url = new URL("http://10.7.88.205:8080/microcampus/" +
                    "UserServlet?remark=changeUser&userImage=" + avator +
                    "&userName=" + userName + "&userEmail=" + userEmail +
                    "&userId=" + userId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //设置请求参数  防止传过去的中文  是乱码
            connection.setRequestProperty("contentType", "utf-8");
            InputStream inputStream = connection.getInputStream();
            //字节流和字符流的转换流
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            msg = reader.readLine();
            Log.e("msg", msg);
            new ReadUser().write(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public void setAvator(int avator) {
        this.avator = avator;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
