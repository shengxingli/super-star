package cn.edu.hebtu.software.microcampus;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ReadShoppingCartDetail {

    public List<ShoppingCartDetail> read (String msg){
        List<ShoppingCartDetail> shoppingCartDetailList
                = new ArrayList<>();
        ShoppingCartDetail shoppingCartDetail = null;
        String list[] = msg.split("。");
        Log.e("msg", list.length + "分割出来了几块");
        int i = 0;
        while(i < list.length){
            shoppingCartDetail = new ShoppingCartDetail();
            String s[] = list[i].split(",");
            Log.e("msg",list[i]);
            shoppingCartDetail.setShoppingCartDetailId(Integer.parseInt(s[0]));
            shoppingCartDetail.setUserId(Integer.parseInt(s[1]));
            Log.e("msg","s[2]"+s[2]);
            shoppingCartDetail.setProduct(new Product());
            shoppingCartDetail.getProduct().setProductId(Integer.parseInt(s[2]));
            shoppingCartDetail.getProduct().setShop(new Shop());
            shoppingCartDetail.getProduct().getShop().setShopId(Integer.parseInt(s[3]));
            shoppingCartDetail.getProduct().getShop().setShopName(s[4]);
            shoppingCartDetail.getProduct().getShop().setShopImage(Integer.parseInt(s[5]));
            shoppingCartDetail.getProduct().getShop().setShopDescription(s[6]);
            shoppingCartDetail.getProduct().getShop().setShopAddress(s[7]);
            shoppingCartDetail.getProduct().getShop().setIndentyImage(Integer.parseInt(s[8]));
            shoppingCartDetail.getProduct().setProductName(s[9]);
            shoppingCartDetail.getProduct().setProductImage(Integer.parseInt(s[10]));
            shoppingCartDetail.getProduct().setProductType(s[11]);
            shoppingCartDetail.getProduct().setProductNum(Integer.parseInt(s[12]));
            shoppingCartDetail.getProduct().setProductDescription(s[13]);
            shoppingCartDetail.getProduct().setProductSaleNum(Integer.parseInt(s[14]));
            shoppingCartDetail.setProductCount(Integer.parseInt(s[15]));
            shoppingCartDetail.setSpecification(new Specification());
            shoppingCartDetail.getSpecification().setSpecificationId(Integer.parseInt(s[16]));
            shoppingCartDetail.getSpecification().setSpecificationContent(s[17]);
            shoppingCartDetail.getSpecification().setProductPrice(s[18]);
            shoppingCartDetail.getSpecification().setProductId(Integer.parseInt(s[19]));
            shoppingCartDetail.getSpecification().setSpecificationCount(Integer.parseInt(s[20]));
            shoppingCartDetailList.add(shoppingCartDetail);
            Log.e("msg",shoppingCartDetail.toString()+i);
            ++i;
        }
        return shoppingCartDetailList;
    }

}
