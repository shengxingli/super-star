package cn.edu.hebtu.software.microcampus;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;

import java.io.IOException;

public class PersonalMessageActivity extends AppCompatActivity {

    private User user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_message);
        user = null;
        try {
            user = new ReadUser().read();
        } catch (IOException e) {
            e.printStackTrace();
        }
        final ImageView userImage = findViewById(R.id.iv_user_image);
        final TextView userName = findViewById(R.id.et_user_name);
        final TextView userEmail = findViewById(R.id.et_user_email);
        TableRow trAddress = findViewById(R.id.tr_address);
        Button btnSaveChange = findViewById(R.id.btn_save_change);
        btnSaveChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeUserTask changeUserTask = new ChangeUserTask();
                changeUserTask.setAvator(userImage.getId());
                changeUserTask.setUserEmail(userEmail.getText().toString());
                changeUserTask.setUserName(userName.getText().toString());
                changeUserTask.setUserId(user.getUserId());
                changeUserTask.execute();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                onResume();
            }
        });
        trAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        PersonalMessageActivity.this,MyAddressActivity.class);
                startActivity(intent);
            }
        });
        userEmail.setText(user.getUserEmail());
        userName.setText(user.getUserName());
        userImage.setImageResource(user.getUserImage());


    }
}
