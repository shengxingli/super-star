package cn.edu.hebtu.software.microcampus;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;

public class SettingActivity extends AppCompatActivity {

    private User user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        ImageView userImage = findViewById(R.id.user_image);
        TextView userName = findViewById(R.id.user_name);
        try {
            user = new ReadUser().read();
        } catch (IOException e) {
            e.printStackTrace();
        }
        userImage.setImageResource(user.getUserImage());
        userName.setText(user.getUserName());

        LinearLayout llMessage = findViewById(R.id.ll_person_message);
        llMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingActivity.this,PersonalMessageActivity.class);
                startActivity(intent);
            }
        });
        LinearLayout llAccountSafe = findViewById(R.id.ll_account_safety);
        llAccountSafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingActivity.this,AccountSafetyActivity.class);
                startActivity(intent);
            }
        });
        LinearLayout llAddress = findViewById(R.id.ll_address);
        llAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingActivity.this,MyAddressActivity.class);
                startActivity(intent);
            }
        });
        Button btnQuit = findViewById(R.id.btn_quit);
        btnQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
