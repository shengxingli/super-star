package cn.edu.hebtu.software.microcampus;

import android.accounts.Account;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class AccountActivity extends AppCompatActivity {
    private int recLen;
    private EditText etTel;
    private EditText etInputCode;
    private Button btnGetCode;
    private CheckBox cbAgree;
    private TextView tvProtocol;
    private Button btnAccount;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        getCode();
        account();

    }

    private void account() {
        btnAccount = findViewById(R.id.btn_account);
        etInputCode = findViewById(R.id.et_input_code);
        cbAgree = findViewById(R.id.cb_agree);
        btnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cbAgree.isChecked()) {
                    GetCodeTask getCodeTask = new GetCodeTask();
                    String code = getCodeTask.getCode();
                    Log.e("code",code);
                    String inoutCode = etInputCode.getText().toString();
                    if (code.equals(inoutCode)) {
                        AccountTask accountTask = new AccountTask();
                        accountTask.setTel(etTel.getText().toString());
                        accountTask.execute();
                        String JSESSIONID = accountTask.getMsg();
                        //跳转到首页
                    } else {
                        Toast.makeText(AccountActivity.this,
                                "验证码错误", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AccountActivity.this,
                            "请先阅读《微校园用户协议》", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getCode() {
        btnGetCode = findViewById(R.id.btn_get_code);
        btnGetCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btnGetCode.getText().toString().equals("重新发送")
                        || btnGetCode.getText().toString().equals("获取验证码")) {
                    etTel = findViewById(R.id.et_tel);
                    String mobile = etTel.getText().toString();
                    if (mobile.equals("")) {
                        Toast.makeText(AccountActivity.this,
                                "手机号不能为空", Toast.LENGTH_SHORT).show();
                    } else {
                        //判断手机号是否已经注册，已经注册就让用户登录
                        GetCodeTask getCodeTask = new GetCodeTask();
                        getCodeTask.setTel(mobile);
                        getCodeTask.execute();
                        recLen = 50;
                        handler.postDelayed(runnable, 1000);
                    }
                }
            }
        });
    }

    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            recLen--;
            if (recLen == 0) {
                btnGetCode.setText("重新发送");
                return;
            }
            btnGetCode.setText("重新发送:" + recLen);
            handler.postDelayed(this, 1000);
        }
    };
}
