package cn.edu.hebtu.software.microcampus;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductsActivity extends AppCompatActivity {

    private ListView listView;
    private List<Map<String, Object>> datalist;
    private List<Map<String, Object>> datalist1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        initListView();

    }

    private void initListView() {
        // 1. 获取数据
        initData();
        // 2. 创建Adapter
        ListViewAdapter adapter = new ListViewAdapter(ProductsActivity.this,
                R.layout.layout_product_item, datalist,datalist1);
        // 3. 给ListView设置Adapter
        listView = findViewById(R.id.lv_products_list);
        listView.setAdapter(adapter);

    }

    //创建Adapter
    private class ListViewAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;
        private List<Map<String, Object>> datalist1;

        public ListViewAdapter(Context context,
                               int itemLayoutID,
                               List<Map<String, Object>> datalist,
                               List<Map<String, Object>> datalist1) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
            this.datalist1 = datalist1;
        }

        @Override
        public int getCount() {
            return datalist.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            LinearLayout llProduct1 = convertView.findViewById(R.id.ll_product1);
            llProduct1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(ProductsActivity.this, ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            LinearLayout llProduct2 = convertView.findViewById(R.id.ll_product2);
            llProduct2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(ProductsActivity.this, ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            ImageView imageView = convertView.findViewById(R.id.iv_product_image1);
            TextView textView1 = convertView.findViewById(R.id.tv_product_name1);
            TextView textView2 = convertView.findViewById(R.id.product_price1);
            ImageView imageView1 = convertView.findViewById(R.id.iv_product_image2);
            TextView tvProductName2 = convertView.findViewById(R.id.tv_product_name2);
            TextView tvProductPrice = convertView.findViewById(R.id.product_price2);
            Map<String, Object> map = datalist.get(position);
            imageView.setImageResource((int) map.get("image"));
            textView1.setText((String) map.get("title"));
            textView2.setText((String) map.get("text"));
            Map<String, Object> map1 = datalist1.get(position);
            imageView1.setImageResource((int) map1.get("image"));
            tvProductName2.setText((String) map1.get("title"));
            tvProductPrice.setText((String) map1.get("text"));
            return convertView;
        }
    }

    //创建数据
    private void initData() {
        int icon[] = {R.drawable.avatar, R.drawable.avatar2, R.drawable.avatar, R.drawable.avatar2, R.drawable.avatar,
                R.drawable.avatar2, R.drawable.avatar, R.drawable.avatar2, R.drawable.avatar, R.drawable.avatar2};
        String title[] = {"ACM算法日常", "高校教师网络培训中心", "程序员那些事", "InfoQ", "阿里技术",
                "码农有道", "人人都是产品经理", "程序员精选", "河北师范大学软件学院", "河北师大共青团"};
        String price[] = {"￥138", "￥138", "￥138", "￥138", "￥138", "￥138", "￥138", "￥138",
                "￥138", "￥138"};
        datalist = new ArrayList<>();
        datalist1 = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            Map<String, Object> map1 = new HashMap<String, Object>();
            if (i%2==0){
                map1.put("image", icon[i]);
                map1.put("title", title[i]);
                map1.put("text", price[i]);
                datalist1.add(map1);
            }else{
                map.put("image", icon[i]);
                map.put("title", title[i]);
                map.put("text", price[i]);
                datalist.add(map);
            }
        }

    }

}
