package cn.edu.hebtu.software.microcampus;

public class Shop {
    private int shopId;
    private String shopName;
    private String shopDescription;
    private int shopImage;
    private String shopAddress;
    private int identyImage;

    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }

    public int getIndentyImage() {
        return identyImage;
    }

    public void setIndentyImage(int indentyImage) {
        this.identyImage = indentyImage;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getShopDescription() {
        return shopDescription;
    }

    public void setShopDescription(String shopDescription) {
        this.shopDescription = shopDescription;
    }

    public int getShopImage() {
        return shopImage;
    }

    public void setShopImage(int shopImage) {
        this.shopImage = shopImage;
    }

    public String toString() {
        return shopId + "," + shopName + "," + shopImage + "," + shopDescription
                + "," + shopAddress + "," + identyImage;
    }

}

