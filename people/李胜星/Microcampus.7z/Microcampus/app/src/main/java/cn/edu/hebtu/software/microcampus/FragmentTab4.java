package cn.edu.hebtu.software.microcampus;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class FragmentTab4 extends Fragment {

    private User user;

    //创建view的时候调用
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        //true  创建出来的view放到第二个参数中  ； false  放到第二个参数中
        //创建的view  会根据第二个参数参照创建出来view的大小
        View view = inflater.inflate(R.layout.activity_personal_center,
                container,
                false);
        ImageView imageView = view.findViewById(R.id.iv_personal_message);
        TextView nickName = view.findViewById(R.id.text_nickname);
        /*
        获取session中User的数据
         */
        try {
            user = new ReadUser().read();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(user != null){
            imageView.setImageResource(user.getUserImage());
            nickName.setText(user.getUserName());
        }

        //更换显示内容
        return view;
    }
    //当view创建完成
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ImageView ivSetting = view.findViewById(R.id.iv_setting);
        ivSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),SettingActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        ImageView ivPersonalMessage = view.findViewById(R.id.iv_personal_message);
        ivPersonalMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),PersonalMessageActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        TextView textNickName = view.findViewById(R.id.text_nickname);
        textNickName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),PersonalMessageActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        LinearLayout llMyOrder = view.findViewById(R.id.ll_my_order);
        llMyOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),OrderActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        LinearLayout llPendingPayment = view.findViewById(R.id.ll_pending_payment);
        llPendingPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),OrderActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        LinearLayout llDelivered = view.findViewById(R.id.ll_delivered);
        llDelivered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),OrderActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        LinearLayout llCart = view.findViewById(R.id.ll_cart);
        llCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),OrderActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        LinearLayout llEvaluation = view.findViewById(R.id.ll_evaluation);
        llEvaluation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user != null){
                    Intent intent = new Intent(getActivity(),OrderActivity.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}
