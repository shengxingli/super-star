package cn.edu.hebtu.software.microcampus;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class AddShoppingCartDetailTask extends AsyncTask {

    private String msg;
    private int userId;
    private int productId;
    private String productCount;
    private int specificationId;

    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            userId = new ReadUser().read().getUserId();
            URL url = new URL("http://10.7.88.205:8080/microcampus/" +
                    "ShoppingCartDetailServlet?remark=add&userId=" + userId
                    + "&productId=" + productId + "&productCount=" + productCount
                    + "&specificationId=" + specificationId);
            HttpURLConnection connection = null;
            connection = (HttpURLConnection) url.openConnection();
            //设置请求参数  防止传过去的中文  是乱码
            connection.setRequestProperty("contentType", "utf-8");
            InputStream inputStream = connection.getInputStream();
            //字节流和字符流的转换流
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            msg = reader.readLine();
            Log.e("msg", msg);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setProductCount(String productCount) {
        this.productCount = productCount;
    }

    public void setSpecificationId(int specificationId) {
        this.specificationId = specificationId;
    }

    public String getMsg() {
        return msg;
    }
}
