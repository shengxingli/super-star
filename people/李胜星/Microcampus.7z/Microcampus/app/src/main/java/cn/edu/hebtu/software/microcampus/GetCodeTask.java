package cn.edu.hebtu.software.microcampus;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;

public class GetCodeTask extends AsyncTask {
    private String tel;
    String code = "";
    String msg = "";
    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            Log.e("code","任务开启。");
            Random random = new Random();
            for (int i = 0; i < 4; i++) {
                code = code + random.nextInt(9);
            }
            URL url = new URL("http://10.7.88.48:8080/microcampus/" +
                    "MessageServlet?code="+code+"&tel="+tel);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //设置请求参数  防止传过去的中文  是乱码
            connection.setRequestProperty("contentType", "utf-8");
            InputStream inputStream = connection.getInputStream();
            //字节流和字符流的转换流
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            while(!reader.readLine().isEmpty()){
                msg = msg + reader.readLine();
            }
            Log.e("msg",msg);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setTel(String mobile){
        tel = mobile;
    }
    public String getCode(){
        return code;
    }
}
