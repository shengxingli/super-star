package cn.edu.hebtu.software.microcampus;


import java.io.File;
import java.io.RandomAccessFile;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

public class TabActivity extends AppCompatActivity {

    private FragmentTabHost tabHost;

    private int[] tabHostIconNormal = {R.drawable.ok7, R.drawable.home_normal,
            R.drawable.shoppingcart, R.drawable.category_normal};

    private String[] tabHostTest = {"首页", "消息", "购物车", "我的微校园"};

    private Class[] fragmentArr = {FragmentTab1.class,
            FragmentTab2.class, FragmentTab3.class, FragmentTab4.class};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);

        create();
        //初始化FragmentTabHost
        initTabHost();

    }

    /*
    创建存储User的文件
     */
    public void create() {
        try {
            Log.e("msg","创建目录");
            if (Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                // 获取SD卡的目录
                Log.e("msg","创建目录");
                File sdCardDir = Environment.getExternalStorageDirectory();
                Log.e("msg","创建文件");
                // 创建文件
                new File(sdCardDir.getCanonicalPath()+ "/test.txt");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initTabHost() {
        Log.e("msg","initYabHost");
        tabHost = findViewById(android.R.id.tabhost);
        tabHost.setup(this,
                getSupportFragmentManager(),
                android.R.id.tabhost);
        for (int i = 0; i < fragmentArr.length; i++) {
            TabHost.TabSpec tabSpec = tabHost.newTabSpec(tabHostTest[i])
                    .setIndicator(getTabHostView(i));
            tabHost.addTab(tabSpec, fragmentArr[i], null);
        }
    }

    private View getTabHostView(int index) {

        View view = getLayoutInflater().inflate(R.layout.fragment_tab, null);
        TextView textView = view.findViewById(R.id.tv_text);
        ImageView imageView = view.findViewById(R.id.iv_image);

        textView.setText(tabHostTest[index]);
        imageView.setImageResource(tabHostIconNormal[index]);
        return view;
    }

    public void setTab(int tab) {

        tabHost.setCurrentTab(tab);
    }

}
