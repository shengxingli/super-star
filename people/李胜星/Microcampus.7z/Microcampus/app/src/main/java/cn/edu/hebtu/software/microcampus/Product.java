package cn.edu.hebtu.software.microcampus;

public class Product {
    private int productId;
    private Shop shop;
    private String productName;
    private String productType;
    private int productImage;
    private int productNum;
    private int productSaleNum;
    private String productDescription;

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int getProductImage() {
        return productImage;
    }

    public void setProductImage(int productImage) {
        this.productImage = productImage;
    }

    public int getProductNum() {
        return productNum;
    }

    public void setProductNum(int productNum) {
        this.productNum = productNum;
    }

    public int getProductSaleNum() {
        return productSaleNum;
    }

    public void setProductSaleNum(int productSaleNum) {
        this.productSaleNum = productSaleNum;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    @Override
    public String toString() {
        return productId + "," + shop.toString() + "," + productName + ","
                + productImage + "," + productType + "," + productNum + ","
                + productDescription + "," + productSaleNum ;
    }
}
