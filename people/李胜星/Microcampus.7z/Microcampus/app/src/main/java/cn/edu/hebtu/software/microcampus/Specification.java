package cn.edu.hebtu.software.microcampus;

public class Specification {

    private int specificationId;
    private String specificationContent;
    private int productId;
    private String productPrice;
    private int specificationCount;

    public int getSpecificationCount() {
        return specificationCount;
    }
    public void setSpecificationCount(int specificationCount) {
        this.specificationCount = specificationCount;
    }
    public int getSpecificationId() {
        return specificationId;
    }
    public void setSpecificationId(int specificationId) {
        this.specificationId = specificationId;
    }
    public String getSpecificationContent() {
        return specificationContent;
    }
    public void setSpecificationContent(String specificationContent) {
        this.specificationContent = specificationContent;
    }
    public int getProductId() {
        return productId;
    }
    public void setProductId(int productId) {
        this.productId = productId;
    }
    public String getProductPrice() {
        return productPrice;
    }
    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    @Override
    public String toString() {
        return specificationId + "," + specificationContent + "," + productPrice
                + "," + productId + "," + specificationCount;
    }

}
