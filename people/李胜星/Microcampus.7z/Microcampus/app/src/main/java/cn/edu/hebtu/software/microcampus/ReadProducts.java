package cn.edu.hebtu.software.microcampus;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ReadProducts {

    public List<Product> read(String msg) {
        List<Product> productList = new ArrayList<>();
        Product product = null;
        Log.e("msg", msg + "分割前");
        String list[] = msg.split("。");
        Log.e("msg", list.length + "分割出来了几块");
        Log.e("msg", list[0] + "第一块");
        int i = 0;
        while (i < list.length) {
            product = new Product();
            String p[] = list[i].split(",");
            product.setProductId(Integer.parseInt(p[0]));
            product.setShop(new Shop());
            product.getShop().setShopId(Integer.parseInt(p[1]));
            product.getShop().setShopName(p[2]);
            product.getShop().setShopImage(Integer.parseInt(p[3]));
            product.getShop().setShopDescription(p[4]);
            product.getShop().setShopAddress(p[5]);
            product.getShop().setIndentyImage(Integer.parseInt(p[6]));
            product.setProductName(p[7]);
            product.setProductImage(Integer.parseInt(p[8]));
            product.setProductType(p[9]);
            product.setProductNum(Integer.parseInt(p[10]));
            product.setProductDescription(p[11]);
            product.setProductSaleNum(Integer.parseInt(p[12]));
            productList.add(product);
            i++;
        }
        return productList;
    }

    public Product readProduct(String msg) {
        Product product = new Product();
        String p[] = msg.split(",");
        product.setProductId(Integer.parseInt(p[0]));
        product.setShop(new Shop());
        product.getShop().setShopId(Integer.parseInt(p[1]));
        product.getShop().setShopName(p[2]);
        product.getShop().setShopImage(Integer.parseInt(p[3]));
        product.getShop().setShopDescription(p[4]);
        product.getShop().setShopAddress(p[5]);
        product.getShop().setIndentyImage(Integer.parseInt(p[6]));
        product.setProductName(p[7]);
        product.setProductImage(Integer.parseInt(p[8]));
        product.setProductType(p[9]);
        product.setProductNum(Integer.parseInt(p[10]));
        product.setProductDescription(p[11]);
        product.setProductSaleNum(Integer.parseInt(p[12]));
        return product;
    }

}
