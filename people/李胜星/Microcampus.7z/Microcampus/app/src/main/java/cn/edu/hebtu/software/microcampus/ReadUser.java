package cn.edu.hebtu.software.microcampus;

import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadUser {

    /*
    读取User
     */
    public User read() throws IOException {
        User user = null;
        Log.e("msg", "读取User");
        if (Environment.getExternalStorageState()
                .equals(Environment.MEDIA_MOUNTED)) ;
        {
            Log.e("msg", "打开目录");
            //打开SD卡下面的a.txt文件
            Log.e("msg", "读取User");
            File file = new File(Environment.getExternalStorageDirectory()
                    .getCanonicalPath() + "/test.txt");
            Log.e("msg", "找到文件");
            if (file.exists()) {
                // 打开文件输入流
                FileInputStream fileR = new FileInputStream(file);
                BufferedReader reads = new BufferedReader(
                        new InputStreamReader(fileR));
                String msg = "";
                msg = reads.readLine();
                fileR.close();
                if (!"".equals(msg) && msg!= null) {
                    Log.e("msg",msg);
                    user = new User();
                    String m[] = msg.split(",");
                    user.setUserId(Integer.parseInt(m[0]));
                    user.setUserTel(m[1]);
                    user.setUserImage(Integer.parseInt(m[2]));
                    user.setUserName(m[3]);
                    user.setUserPassword(m[4]);
                    user.setUserAddress(m[5]);
                    user.setUserEmail(m[6]);
                    if (m[7].equals(null)) {
                        user.setShop(null);
                        user.setUserELogin(Integer.parseInt(m[8]));
                    } else {
                        user.setShop(new Shop());
                        user.getShop().setShopId(Integer.parseInt(m[7]));
                        user.getShop().setShopName(m[8]);
                        user.getShop().setShopImage(Integer.parseInt(m[9]));
                        user.getShop().setShopDescription(m[10]);
                        user.getShop().setShopAddress(m[11]);
                        user.getShop().setIndentyImage(Integer.parseInt(m[12]));
                        user.setUserELogin(Integer.parseInt(m[13]));
                    }
                }
            }
        }
        return user;
    }

    /*
    写入User+Shop+ShoppingCart
     */
    public void write(String msg) {
        try {
            // 判断是否存在SD卡
            if (Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                // 获取SD卡的目录
                File sdDire = Environment.getExternalStorageDirectory();
                FileOutputStream outFileStream = new FileOutputStream(
                        sdDire.getCanonicalPath() + "/test.txt");
                outFileStream.write(msg.getBytes());
                outFileStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
