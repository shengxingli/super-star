package cn.edu.hebtu.software.microcampus;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FragmentTab3 extends Fragment {

    FragmentTab3.CartListViewAdapter adapter;
    private List<ShoppingCartDetail> shoppingCartDetailList;
    private int[] selectedDetail;
    private Boolean checked;
    private CheckBox cbSelectAll;
    private ListView cartListView;
    private List<Map<String, Object>> cartDatalist;
    private ListView listView;
    private List<Map<String, Object>> datalist;
    private List<Map<String, Object>> datalist1;
    private Map<String, Object> map;
    private Map<String, Object> map1;
    private User user;
    private int shoppingCartNum;
    private TextView shoppingCart;

    //创建view的时候调用
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        //true  创建出来的view放到第二个参数中  ； false  放到第二个参数中
        //创建的view  会根据第二个参数参照创建出来view的大小
        View view = inflater.inflate(R.layout.activity_shopping_cart,
                container,
                false);

        shoppingCart = view.findViewById(R.id.shopping_cart_num);
        cbSelectAll = view.findViewById(R.id.cb_select_all);
        checked = false;
        cbSelectAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checked = true;
                    adapter.notifyDataSetChanged();
                } else {
                    checked = false;
                    adapter.notifyDataSetChanged();
                }
            }
        });
        Button btnCart = view.findViewById(R.id.btn_cart);
        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), FillOrderActivity.class);
                String msg = "";
                for (int i = 0; i < shoppingCartDetailList.size(); ++i) {
                    if (selectedDetail[i] == 1) {
                        if (shoppingCartDetailList.get(i).getProductCount()
                                > shoppingCartDetailList.get(i).getSpecification().getSpecificationCount()) {
                            msg = "null";
                            break;
                        } else {
                            msg = msg + shoppingCartDetailList.get(i).toString();
                        }
                    }
                }
                if (msg.equals("")) {
                    Toast.makeText(getActivity(), "请先选中商品", Toast.LENGTH_LONG).show();
                } else if (msg.equals("null")) {
                    Toast.makeText(getActivity(), "库存不足", Toast.LENGTH_LONG).show();
                } else {
                    intent.putExtra("detail", msg);
                    startActivity(intent);
                }
            }
        });
        try {
            user = new ReadUser().read();
            if (user != null) {
                initCartListView(view);
                initListView(view);
                Log.e("msg", "一共有件宝贝" + shoppingCart.getText().toString());
                selectedDetail = new int[Integer.parseInt(shoppingCart.getText().toString())];
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //更换显示内容
        return view;
    }

    private void initListView(View view) throws InterruptedException {
        // 1. 获取数据
        initData();
        // 2. 创建Adapter
        FragmentTab3.ListViewAdapter adapter = new FragmentTab3.ListViewAdapter(getContext(),
                R.layout.layout_product_item, datalist, datalist1);
        // 3. 给ListView设置Adapter
        listView = view.findViewById(R.id.product_list);
        listView.setAdapter(adapter);

    }

    //创建Adapter
    private class ListViewAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;
        private List<Map<String, Object>> datalist1;

        public ListViewAdapter(Context context,
                               int itemLayoutID,
                               List<Map<String, Object>> datalist,
                               List<Map<String, Object>> datalist1) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
            this.datalist1 = datalist1;
        }

        @Override
        public int getCount() {
            return datalist1.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            LinearLayout llProduct1 = convertView.findViewById(R.id.ll_product1);
            llProduct1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            LinearLayout llProduct2 = convertView.findViewById(R.id.ll_product2);
            llProduct2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            ImageView imageView = convertView.findViewById(R.id.iv_product_image1);
            TextView textView1 = convertView.findViewById(R.id.tv_product_name1);
            TextView textView2 = convertView.findViewById(R.id.product_price1);
            ImageView imageView1 = convertView.findViewById(R.id.iv_product_image2);
            TextView tvProductName2 = convertView.findViewById(R.id.tv_product_name2);
            TextView tvProductPrice = convertView.findViewById(R.id.product_price2);
            if (datalist != null) {
                map = datalist.get(position);
                imageView1.setImageResource((int) map.get("image"));
                tvProductName2.setText((String) map.get("title"));
                tvProductPrice.setText((String) map.get("text"));
            }
            if (datalist1 != null) {
                map1 = datalist1.get(position);
                imageView.setImageResource((int) map1.get("image"));
                textView1.setText((String) map1.get("title"));
                textView2.setText((String) map1.get("text"));

            }
            return convertView;
        }
    }

    //创建数据
    private void initData() throws InterruptedException {

        GetProductsByTypeTask getProductsByTypeTask
                = new GetProductsByTypeTask();
        getProductsByTypeTask.setType("all");
        getProductsByTypeTask.execute();
        Thread.sleep(500);
        Log.e("msg", getProductsByTypeTask.getMsg());
        if ("".equals(getProductsByTypeTask.getMsg()) || getProductsByTypeTask.getMsg() == null) {
            datalist = null;
            datalist1 = null;
        } else {
            Log.e("msg", "商品列表存在");
            List<Product> productList
                    = new ReadProducts().read(getProductsByTypeTask.getMsg());
            Log.e("msg", productList.size() + "商品列表的长度");
            for (int i = 0; i < productList.size(); i++) {
                for (Product p : productList) {
                    if (i % 2 == 0) {
                        datalist1 = new ArrayList<>();
                        map1 = new HashMap<>();
                        map1.put("image", p.getProductImage());
                        map1.put("title", p.getProductName());
                        map1.put("id", p.getProductId());
                        GetSpecificationByProductIdTask getSpecificationByProductIdTask
                                = new GetSpecificationByProductIdTask();
                        getSpecificationByProductIdTask.setProductId(p.getProductId());
                        getSpecificationByProductIdTask.execute();
                        Thread.sleep(1000);
                        String msg = getSpecificationByProductIdTask.getMsg();
                        List<Specification> specificationList = new ReadSpecification().read(msg);
                        map1.put("text", new ReadSpecification()
                                .getLowerPrice(specificationList));
                        datalist1.add(map1);
                    } else {
                        datalist = new ArrayList<>();
                        map = new HashMap<>();
                        map.put("image", p.getProductImage());
                        map.put("title", p.getProductName());
                        map.put("id", p.getProductId());
                        GetSpecificationByProductIdTask getSpecificationByProductIdTask
                                = new GetSpecificationByProductIdTask();
                        getSpecificationByProductIdTask.setProductId(p.getProductId());
                        getSpecificationByProductIdTask.execute();
                        Thread.sleep(500);
                        String msg = getSpecificationByProductIdTask.getMsg();
                        List<Specification> specificationList = new ReadSpecification().read(msg);
                        map.put("text", new ReadSpecification()
                                .getLowerPrice(specificationList));
                        datalist.add(map);
                    }
                }
            }
        }

    }

    private void initCartListView(View view) throws IOException, InterruptedException {
        // 1. 获取数据
        initCartData();
        shoppingCartNum = cartDatalist.size();
        shoppingCart.setText(shoppingCartNum + "");
        // 2. 创建Adapter
        if (cartDatalist != null) {
            adapter = new FragmentTab3.CartListViewAdapter(getContext(),
                    R.layout.layout_shopping_cart_item, cartDatalist);
            // 3. 给ListView设置Adapter
            cartListView = view.findViewById(R.id.lv_cart_list);
            cartListView.setAdapter(adapter);
            setListViewHeightBasedOnChildren(cartListView);
        }
    }

    public void setListViewHeightBasedOnChildren(ListView listView) {
        // 获取ListView对应的Adapter
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            Log.e("msg", listAdapter.getCount() + "");
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }

    //创建CartAdapter
    private class CartListViewAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;

        public CartListViewAdapter(Context context,
                                   int itemLayoutID,
                                   List<Map<String, Object>> datalist) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
        }

        @Override
        public int getCount() {
            return datalist.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            final View finalConvertView = convertView;
            CheckBox cbItem = finalConvertView.findViewById(R.id.cb_shop_item);
            cbItem.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        selectedDetail[position] = 1;
                    } else {
                        selectedDetail[position] = 0;
                    }
                }
            });
            if (checked) {
                cbItem.setChecked(true);
                onCreate(null);
            } else {
                cbItem.setChecked(false);
                onCreate(null);
            }
            Button addProduct = convertView.findViewById(R.id.btn_add_product);
            Button deleteProduct = convertView.findViewById(R.id.btn_delete_product);
            final Button num = convertView.findViewById(R.id.btn_cart_product_num);
            addProduct.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int i = Integer.parseInt(num.getText().toString()) + 1;
                    num.setText(i + "");
                }
            });
            deleteProduct.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Integer.parseInt(num.getText().toString()) > 1) {
                        num.setText(Integer.parseInt(num.getText().toString()) - 1 + "");
                    }
                }
            });
            ImageView shopImage = convertView.findViewById(R.id.shop_image);
            TextView shopName = convertView.findViewById(R.id.tv_shop_name);
            ImageView productImage = convertView.findViewById(R.id.iv_product_image);
            TextView productName = convertView.findViewById(R.id.tv_product_name);
            TextView productSpecification = convertView.findViewById(R.id.tv_specification);
            TextView productPrice = convertView.findViewById(R.id.tv_product_price);
            Button btnNum = convertView.findViewById(R.id.btn_cart_product_num);
            productSpecification.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showPopupWindowMenu(v);
                }
            });

            productImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("msg", "点击了图片");
                    Intent intent = new Intent();
                    intent.putExtra("product",
                            shoppingCartDetailList.get(position).getProduct().toString());
                    intent.setClass(getActivity(), ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            productName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.putExtra("product",
                            shoppingCartDetailList.get(position).getProduct().toString());
                    intent.setClass(getActivity(), ProductDetailActivity.class);
                    startActivity(intent);
                }
            });

            Map<String, Object> map = cartDatalist.get(position);
            shopImage.setImageResource((int) map.get("shopImage"));
            productImage.setImageResource((int) map.get("productImage"));
            shopName.setText((String) map.get("shopName"));
            productName.setText((String) map.get("productName"));
            productSpecification.setText((String) map.get("productSpecification"));
            productPrice.setText((String) map.get("productPrice"));
            Log.e("msg", (int) map.get("btnNum") + "");
            btnNum.setText((int) map.get("btnNum") + "");
            return convertView;
        }
    }


    //创建数据
    private void initCartData() throws IOException, InterruptedException {
        Log.e("msg", "准备异步任务");
        GetShoppingCartDetailByUserIdTask getShoppingCartDetailByUserIdTask
                = new GetShoppingCartDetailByUserIdTask();
        getShoppingCartDetailByUserIdTask.setUserId(user.getUserId());
        getShoppingCartDetailByUserIdTask.execute();
        Thread.sleep(1000);
        String msg = getShoppingCartDetailByUserIdTask.getMsg();
        Log.e("msg", msg);
        shoppingCartDetailList
                = new ReadShoppingCartDetail().read(msg);
        if (shoppingCartDetailList != null) {
            cartDatalist = new ArrayList<>();
            for (ShoppingCartDetail shoppingCartDetail : shoppingCartDetailList) {
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("shopImage", shoppingCartDetail.getProduct().getShop().getShopImage());
                map.put("shopName", shoppingCartDetail.getProduct().getShop().getShopName());
                map.put("productImage", shoppingCartDetail.getProduct().getProductImage());
                map.put("productName", shoppingCartDetail.getProduct().getProductName());
                map.put("productSpecification", shoppingCartDetail.getSpecification().getSpecificationContent());
                map.put("productPrice", shoppingCartDetail.getSpecification().getProductPrice());
                map.put("btnNum", shoppingCartDetail.getProductCount());
                cartDatalist.add(map);
            }
        } else {
            cartDatalist = null;
        }
    }

    //当view创建完成
    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final TextView management = view.findViewById(R.id.management);
        final Button btnCart = view.findViewById(R.id.btn_cart);
        management.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (management.getText().toString().equals("管理")) {
                    btnCart.setText("删除");
                    management.setText("完成");
                } else {
                    btnCart.setText("结算(0)");
                    management.setText("管理");
                }
            }
        });

    }

    //弹出PopupWindow
    private void showPopupWindowMenu(View v) {
        //1.根据资源文件，使用布局填充器创建显示的View
        View popupWindowView = getLayoutInflater()
                .inflate(R.layout.layout_add_shopping_cart_menu, null);
        //2.创建PopupWindow对象
        final PopupWindow popupWindow = new PopupWindow(popupWindowView,
                dip2px(getContext().getApplicationContext(), 410),
                dip2px(getContext().getApplicationContext(), 500),
                true);
        int[] location = new int[2];
        v.getLocationOnScreen(location);
        popupWindow.showAtLocation(v, Gravity.NO_GRAVITY,
                location[0], popupWindow.getHeight());
        //3.绑定监听器
        popupWindow.showAsDropDown(v, (v.getWidth() - popupWindow.getWidth()) / 2, 0);
    }

    //dp物理像素转换成真实像素
    public static int dip2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
