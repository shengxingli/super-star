package cn.edu.hebtu.software.microcampus;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FragmentTab2 extends Fragment {

    private ListView listView;
    private List<Map<String, Object>> datalist;

    //创建view的时候调用
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        //true  创建出来的view放到第二个参数中  ； false  放到第二个参数中
        //创建的view  会根据第二个参数参照创建出来view的大小
        View view = inflater.inflate(R.layout.activity_message,
                container,
                false);

        try {
            if(new ReadUser().read() != null){
                initListView(view);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        //更换显示内容
        return view;
    }

    private void initListView(View view) throws IOException {
        // 1. 获取数据
        initData();
        // 2. 创建Adapter
        if(datalist != null){
            FragmentTab2.ListViewAdapter adapter = new FragmentTab2.ListViewAdapter(getContext(),
                    R.layout.message_list_item, datalist);
            // 3. 给ListView设置Adapter
            listView = view.findViewById(R.id.lv_message_list);
            listView.setAdapter(adapter);
            // 4. 绑定监听器
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
                @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                    //做具体响应的函数
                    Intent intent = new Intent();
                    intent.setClass(getActivity(), MessageDetailActivity.class);
                    startActivity(intent);
                }
            });
        }
    }

    //当view创建完成
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    //创建Adapter
    private class ListViewAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;

        public ListViewAdapter(Context context,
                               int itemLayoutID,
                               List<Map<String, Object>> datalist) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
        }

        @Override
        public int getCount() {
            return datalist.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            ImageView imageView = convertView.findViewById(R.id.iv_shop_image);
            TextView textView1 = convertView.findViewById(R.id.tv_shop_name);
            TextView textView2 = convertView.findViewById(R.id.tv_last_message_content);
            TextView textView3 = convertView.findViewById(R.id.tv_last_message_time);
            Map<String, Object> map = datalist.get(position);
            imageView.setImageResource((int) map.get("image"));
            textView1.setText((String) map.get("title"));
            textView2.setText((String) map.get("text"));
            textView3.setText((String) map.get("date"));
            return convertView;
        }
    }

    //创建数据
    private void initData() throws IOException {

        GetMsgByUserIdTask getMsgByUserIdTask = new GetMsgByUserIdTask();
        getMsgByUserIdTask.execute();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if("".equals(getMsgByUserIdTask.getMsg()) || getMsgByUserIdTask.getMsg() ==null){
            datalist = null;
        }else{
            List<Msg> msgList = new ReadMsg().read(getMsgByUserIdTask.getMsg());
            datalist = new ArrayList<>();
            for (Msg m:msgList) {
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("image", m.getShop().getShopImage());
                map.put("title", m.getShop().getShopName());
                map.put("text", m.getMsgLastContent());
                map.put("date", m.getMsgLastTime());
                datalist.add(map);
            }
        }
    }
}
