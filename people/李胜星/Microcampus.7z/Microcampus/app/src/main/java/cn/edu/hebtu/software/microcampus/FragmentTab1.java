package cn.edu.hebtu.software.microcampus;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FragmentTab1 extends Fragment {

    private ListView listView;
    private List<Map<String, Object>> datalist;
    private List<Map<String, Object>> datalist1;
    private Map<String, Object> map = null;
    private Map<String, Object> map1 = null;

    //创建view的时候调用
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        //true  创建出来的view放到第二个参数中  ； false  放到第二个参数中
        //创建的view  会根据第二个参数参照创建出来view的大小
        View view = inflater.inflate(R.layout.activity_index,
                container,
                false);
        try {
            initListView(view);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //更换显示内容
        return view;
    }

    private void initListView(View view) throws InterruptedException {
        // 1. 获取数据
        initData();
        if (datalist != null || datalist1 != null) {
            // 2. 创建Adapter
            Log.e("msg", "创建Adapter");
            FragmentTab1.ListViewAdapter adapter = new FragmentTab1.ListViewAdapter(getContext(),
                    R.layout.layout_product_item, datalist, datalist1);
            Log.e("msg", datalist1.toString());
            Log.e("msg", "创建Adapter成功");
            // 3. 给ListView设置Adapter
            listView = view.findViewById(R.id.lv_product_list);
            listView.setAdapter(adapter);
            setListViewHeightBasedOnChildren(listView);
        }
    }

    //创建Adapter
    private class ListViewAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;
        private List<Map<String, Object>> datalist1;

        public ListViewAdapter(Context context,
                               int itemLayoutID,
                               List<Map<String, Object>> datalist,
                               List<Map<String, Object>> datalist1) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
            this.datalist1 = datalist1;
        }

        @Override
        public int getCount() {
            return datalist1.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            ImageView imageView = convertView.findViewById(R.id.iv_product_image1);
            TextView textView1 = convertView.findViewById(R.id.tv_product_name1);
            TextView textView2 = convertView.findViewById(R.id.product_price1);
            ImageView imageView1 = convertView.findViewById(R.id.iv_product_image2);
            TextView tvProductName2 = convertView.findViewById(R.id.tv_product_name2);
            TextView tvProductPrice = convertView.findViewById(R.id.product_price2);
            if (datalist1 != null) {
                map1 = datalist1.get(position);
                imageView.setImageResource((int) map1.get("image"));
                textView1.setText((String) map1.get("title"));
                textView2.setText("￥" + map1.get("text"));
            }
            if (datalist != null) {
                map = datalist.get(position);
                imageView1.setImageResource((int) map.get("image"));
                tvProductName2.setText((String) map.get("title"));
                tvProductPrice.setText("￥" + map.get("text"));
            }
            LinearLayout llProduct1 = convertView.findViewById(R.id.ll_product1);
            llProduct1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.putExtra("product", (String) map1.get("product"));
                    intent.putExtra("price", (String) map1.get("text"));
                    intent.putExtra("specification",(String) map1.get("specification"));
                    intent.setClass(getActivity(), ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            LinearLayout llProduct2 = convertView.findViewById(R.id.ll_product2);
            llProduct2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.putExtra("product", (int) map.get("product"));
                    intent.putExtra("price", (String) map.get("text"));
                    intent.putExtra("specification",(String) map.get("specification"));
                    intent.setClass(getActivity(), ProductDetailActivity.class);
                    startActivity(intent);
                }
            });
            return convertView;
        }
    }

    //创建数据
    private void initData() throws InterruptedException {
        GetProductsByTypeTask getProductsByTypeTask
                = new GetProductsByTypeTask();
        getProductsByTypeTask.setType("all");
        getProductsByTypeTask.execute();
        Thread.sleep(1000);
        Log.e("msg", getProductsByTypeTask.getMsg());
        if ("".equals(getProductsByTypeTask.getMsg()) || getProductsByTypeTask.getMsg() == null) {
            datalist = null;
            datalist1 = null;
        } else {
            Log.e("msg", "商品列表存在");
            List<Product> productList
                    = new ReadProducts().read(getProductsByTypeTask.getMsg());
            Log.e("msg", productList.size() + "商品列表的长度");
            for (int i = 0; i < productList.size(); i++) {
                for (Product p : productList) {
                    if (i % 2 == 0) {
                        datalist1 = new ArrayList<>();
                        map1 = new HashMap<>();
                        map1.put("image", p.getProductImage());
                        map1.put("title", p.getProductName());
                        map1.put("product", p.toString());
                        GetSpecificationByProductIdTask getSpecificationByProductIdTask
                                = new GetSpecificationByProductIdTask();
                        getSpecificationByProductIdTask.setProductId(p.getProductId());
                        getSpecificationByProductIdTask.execute();
                        Thread.sleep(1000);
                        List<Specification> specificationList
                                = new ReadSpecification().read(getSpecificationByProductIdTask.getMsg());
                        map1.put("text", new ReadSpecification()
                                .getLowerPrice(specificationList));
                        map1.put("specification",getSpecificationByProductIdTask.getMsg());
                        datalist1.add(map1);
                    } else {
                        datalist = new ArrayList<>();
                        map = new HashMap<>();
                        map.put("image", p.getProductImage());
                        map.put("title", p.getProductName());
                        map.put("product", p.toString());
                        GetSpecificationByProductIdTask getSpecificationByProductIdTask
                                = new GetSpecificationByProductIdTask();
                        getSpecificationByProductIdTask.setProductId(p.getProductId());
                        getSpecificationByProductIdTask.execute();
                        Thread.sleep(500);
                        List<Specification> specificationList
                                = new ReadSpecification().read(getSpecificationByProductIdTask.getMsg());
                        map.put("text", new ReadSpecification()
                                .getLowerPrice(specificationList));
                        map.put("specification",getSpecificationByProductIdTask.getMsg());
                        datalist.add(map);
                    }
                }
            }
        }
    }

    //当view创建完成
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageView ivMessage = view.findViewById(R.id.iv_message);
        ivMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TabActivity tabActivity = (TabActivity) getActivity();
                tabActivity.setTab(1);
            }
        });
        Button btnSearch = view.findViewById(R.id.btn_search);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProductsActivity.class);
                startActivity(intent);
            }
        });

    }

    public void setListViewHeightBasedOnChildren(ListView listView) {
        // 获取ListView对应的Adapter
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            Log.e("msg", listAdapter.getCount() + "");
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }
}
