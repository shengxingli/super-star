package cn.edu.hebtu.software.microcampus;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class LoginActivity extends AppCompatActivity {
    private Button btnLogin;
    private ImageView ivAvatar;
    private EditText etUserName;
    private EditText etPassword;
    private CheckBox cbAutomaticLogin;
    private TextView tvFindPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnLogin = findViewById(R.id.btn_login);
        ivAvatar = findViewById(R.id.iv_avatar);
        etUserName = findViewById(R.id.et_user_name);
        etPassword = findViewById(R.id.et_password);
        cbAutomaticLogin = findViewById(R.id.cb_automatic_login);
        tvFindPassword = findViewById(R.id.tv_find_password);

        tvFindPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到忘记密码页面
            }
        });

        etUserName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!etUserName.getText().toString().equals("")) {
                    //根据用户名获取图片地址
                    GetImageByUserNameTask getImageByUserNameTask
                            = new GetImageByUserNameTask();
                    getImageByUserNameTask.setUserName(etUserName.getText().toString());
                    getImageByUserNameTask.execute();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    String msg = getImageByUserNameTask.getMsg();
                    if (("用户名错误").equals(msg)) {
                        Toast.makeText(LoginActivity.this,
                                "用户名错误或者未注册过", Toast.LENGTH_SHORT).show();
                    } else {
                        ivAvatar.setImageResource(Integer.parseInt(msg));
                    }
                }
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etUserName.getText().toString();
                String password = etPassword.getText().toString();
                if (name.equals("") || password.equals("")) {
                    Toast.makeText(LoginActivity.this,
                            "用户名密码不能为空", Toast.LENGTH_SHORT).show();
                } else {
                    //向后台传参
                    boolean autoLogin = cbAutomaticLogin.isChecked();
                    LoginTask loginTask = new LoginTask();
                    loginTask.setUserName(name);
                    loginTask.setPassword(password);
                    loginTask.setAutoLogin(autoLogin);
                    loginTask.execute();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if (("用户名或密码错误").equals(loginTask.getMsg())) {
                        Toast.makeText(LoginActivity.this,
                                "用户名或密码错误", Toast.LENGTH_SHORT).show();
                    } else {
                        new ReadUser().write(loginTask.getMsg());
                        Intent intent = new Intent(
                                LoginActivity.this, TabActivity.class);
                        startActivity(intent);
                    }
                }
            }
        });
        ImageView ivOthers = findViewById(R.id.iv_others);
        ivOthers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu(v);
            }
        });
    }

    //弹出PopupMenu
    private void showPopupMenu(View v) {
        //创建一个popupMenu
        PopupMenu popupMenu = new PopupMenu(getApplicationContext(), v);
        //通过XML文件对popupMenu进行填充
        popupMenu.getMenuInflater().inflate(R.menu.option_menu, popupMenu.getMenu());
        //绑定点击监听器
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.account:
                        Intent intent = new Intent(LoginActivity.this,
                                AccountActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.code_login:
                        Intent intent2 = new Intent(LoginActivity.this,
                                CodeLoginActivity.class);
                        startActivity(intent2);
                        break;
                }
                return true;
            }
        });
        //4.显示popupMenu
        popupMenu.show();
    }

    /*
    写入User+Shop+ShoppingCart
     */
    private void write(String msg) {
        try {
            // 判断是否存在SD卡
            if (Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                // 获取SD卡的目录
                File sdDire = Environment.getExternalStorageDirectory();
                FileOutputStream outFileStream = new FileOutputStream(
                        sdDire.getCanonicalPath() + "/test.txt");
                outFileStream.write(msg.getBytes());
                outFileStream.close();
                Toast.makeText(this, "数据保存到test.txt文件了", Toast.LENGTH_LONG)
                        .show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
