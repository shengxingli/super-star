package cn.edu.hebtu.software.microcampus;

import java.util.Date;

public class Msg {

    private int msgId;
    private Shop shop;
    private User user;
    private int sender;
    private String msgLastContent;
    private String msgLastTime;

    public String getMsgLastContent() {
        return msgLastContent;
    }

    public void setMsgLastContent(String msgLastContent) {
        this.msgLastContent = msgLastContent;
    }

    public String getMsgLastTime() {
        return msgLastTime;
    }

    public void setMsgLastTime(String msgLastTime) {
        this.msgLastTime = msgLastTime;
    }

    public int getMsgId() {
        return msgId;
    }

    public void setMsgId(int msgId) {
        this.msgId = msgId;
    }

    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getSender() {
        return sender;
    }

    public void setSender(int sender) {
        this.sender = sender;
    }

    @Override
    public String toString() {
        // 用户商家不可能为空
        return msgId + "," + "user" + "," + shop.toString() + "," + sender
                + "," + msgLastContent + "," + msgLastTime;
    }

}
