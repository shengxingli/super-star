package cn.edu.hebtu.software.microcampus;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadMsg {

    public List<Msg> read(String msg) throws IOException {
        List<Msg> msgList = new ArrayList<>();
        Msg message = null;
        String list[] = msg.split("。");
        int i = 0;
        while(!list[i].equals("")){
            message = new Msg();
            String m[] = list[i].split(",");
            message.setMsgId(Integer.parseInt(m[0]));
            message.setUser(new ReadUser().read());
            message.setShop(new Shop());
            message.getShop().setShopId(Integer.parseInt(m[2]));
            message.getShop().setShopName(m[3]);
            message.getShop().setShopImage(Integer.parseInt(m[4]));
            message.getShop().setShopDescription(m[5]);
            message.getShop().setShopAddress(m[6]);
            message.getShop().setIndentyImage(Integer.parseInt(m[7]));
            message.setSender(Integer.parseInt(m[8]));
            message.setMsgLastContent(m[9]);
            message.setMsgLastTime(m[10]);
            msgList.add(message);
            i++;
        }
        return msgList;
    }
}
