package cn.edu.hebtu.software.microcampus;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ReadSpecification {

    public List<Specification> read (String msg){
        Log.e("msg", msg);
        List<Specification> specificationList
                = new ArrayList<>();
        Specification specification = null;
        String list[] = msg.split("。");
        Log.e("msg", list.length + "分割出来了几块");
        int i = 0;
        while(i < list.length){
            specification = new Specification();
            String s[] = list[i].split(",");
            specification.setSpecificationId(Integer.parseInt(s[0]));
            specification.setSpecificationContent(s[1]);
            specification.setProductPrice(s[2]);
            specification.setProductId(Integer.parseInt(s[3]));
            specification.setSpecificationCount(Integer.parseInt(s[4]));
            specificationList.add(specification);
            Log.e("msg",specification.toString()+i);
            ++i;
        }
        return specificationList;
    }

    public String getLowerPrice(List<Specification> specificationList){
        String price = "0";
        for (Specification specification:specificationList){
            if(price.equals("0") || Double.parseDouble(price)>Double.parseDouble(specification.getProductPrice())){
                price = specification.getProductPrice();
            }
        }
        Log.e("msg",price+"最低价格");
        return price;
    }

}
