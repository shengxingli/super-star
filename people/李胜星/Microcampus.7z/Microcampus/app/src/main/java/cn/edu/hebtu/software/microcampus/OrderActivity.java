package cn.edu.hebtu.software.microcampus;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderActivity extends AppCompatActivity {

    private ListView listView;
    private List<Map<String, Object>> datalist;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        initListView();

    }

    private void initListView() {
        // 1. 获取数据
        initData();
        // 2. 创建Adapter
        ListViewAdapter adapter = new ListViewAdapter(OrderActivity.this,
                R.layout.layout_order_item, datalist);
        // 3. 给ListView设置Adapter
        listView = findViewById(R.id.order_list);
        listView.setAdapter(adapter);
        // 4. 绑定监听器
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                //做具体响应的函数

            }
        });

    }

    //创建Adapter
    private class ListViewAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutID;
        private List<Map<String, Object>> datalist;

        public ListViewAdapter(Context context,
                               int itemLayoutID,
                               List<Map<String, Object>> datalist) {
            this.context = context;
            this.itemLayoutID = itemLayoutID;
            this.datalist = datalist;
        }

        @Override
        public int getCount() {
            return datalist.size();
        }

        @Override
        public Object getItem(int position) {
            return datalist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemLayoutID, null);
            }
            ImageView shopImage = convertView.findViewById(R.id.shop_image);
            TextView shopName = convertView.findViewById(R.id.shop_name);
            ImageView productImage = convertView.findViewById(R.id.iv_product_image);
            TextView productName = convertView.findViewById(R.id.tv_product_name);
            TextView productPrice = convertView.findViewById(R.id.tv_product_price);
            TextView num = convertView.findViewById(R.id.tv_num);
            TextView totalPrice = convertView.findViewById(R.id.tv_total_price);
            Map<String, Object> map = datalist.get(position);
            shopImage.setImageResource((int) map.get("image"));
            shopName.setText((String) map.get("title"));
            productImage.setImageResource((int) map.get("productImage"));
            productName.setText((String) map.get("productName"));
            productPrice.setText((String) map.get("productPrice"));
            num.setText((String) map.get("num"));
            totalPrice.setText((String) map.get("totalPrice"));
            return convertView;
        }
    }

    //创建数据
    private void initData() {
        int icon[] = {R.drawable.avatar, R.drawable.avatar2};
        String title[] = {"ACM算法日常", "高校教师网络培训中心"};
        int productImage[] = {R.drawable.avatar, R.drawable.avatar2};
        String productName[] = {"ACM算法日常", "高校教师网络培训中心"};
        String price[] = {"￥138", "￥138"};
        String num[] = {"*1", "*2"};
        String totalPrice[] = {"￥199", "￥41.70"};
        datalist = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("image", icon[i]);
            map.put("title", title[i]);
            map.put("productImage", productImage[i]);
            map.put("productName", productName[i]);
            map.put("productPrice", price[i]);
            map.put("num", num[i]);
            map.put("totalPrice", totalPrice[i]);
            datalist.add(map);
        }

    }

}
