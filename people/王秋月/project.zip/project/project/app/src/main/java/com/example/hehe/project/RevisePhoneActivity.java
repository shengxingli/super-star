package com.example.hehe.project;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

public class RevisePhoneActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.revisephone);
        ImageView imageReturn = findViewById(R.id.image_return3);
        imageReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView imagePsd = findViewById(R.id.image_skip_psd);
                imagePsd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent();
                        intent.setClass(RevisePhoneActivity.this,CountActivity.class);
                        startActivity(intent);
                    }
                });
            }
        });
    }
}